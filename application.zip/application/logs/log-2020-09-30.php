<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-30 00:15:19 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-09-30 06:22:45 --> Severity: Warning --> fopen(/opt/alt/php72/var/lib/php/session/ci_session8fc119cb95f067bcc3dbade7f54406fe3bef4080): failed to open stream: Disk quota exceeded /home/solvhong/kreb.solvertechug.com/system/libraries/Session/drivers/Session_files_driver.php 174
ERROR - 2020-09-30 06:22:45 --> Session: Unable to open file '/opt/alt/php72/var/lib/php/session/ci_session8fc119cb95f067bcc3dbade7f54406fe3bef4080'.
ERROR - 2020-09-30 06:22:45 --> Severity: Warning --> session_start(): Failed to read session data: user (path: /opt/alt/php72/var/lib/php/session) /home/solvhong/kreb.solvertechug.com/system/libraries/Session/Session.php 143
ERROR - 2020-09-30 06:24:00 --> Severity: Warning --> fopen(/opt/alt/php72/var/lib/php/session/ci_sessionda88bc35dafe9e2cc5580be2cf14e4e37377c2e7): failed to open stream: Disk quota exceeded /home/solvhong/kreb.solvertechug.com/system/libraries/Session/drivers/Session_files_driver.php 174
ERROR - 2020-09-30 06:24:00 --> Session: Unable to open file '/opt/alt/php72/var/lib/php/session/ci_sessionda88bc35dafe9e2cc5580be2cf14e4e37377c2e7'.
ERROR - 2020-09-30 06:24:00 --> Severity: Warning --> session_start(): Failed to read session data: user (path: /opt/alt/php72/var/lib/php/session) /home/solvhong/kreb.solvertechug.com/system/libraries/Session/Session.php 143
ERROR - 2020-09-30 06:24:01 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-09-30 14:49:44 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2020-09-30 14:57:39 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2020-09-30 15:04:36 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2020-09-30 15:57:49 --> 404 Page Not Found: Atomxml/index
ERROR - 2020-09-30 17:04:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-09-30 17:04:40 --> 404 Page Not Found: Apple_touch_icon_precomposedpng/index
ERROR - 2020-09-30 17:04:40 --> 404 Page Not Found: Apple_touch_iconpng/index
