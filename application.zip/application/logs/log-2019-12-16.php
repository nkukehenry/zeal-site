<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-16 12:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-12-16 19:34:19 --> 404 Page Not Found: Robotstxt/index
