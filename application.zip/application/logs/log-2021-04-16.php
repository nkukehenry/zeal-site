<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-16 09:38:35 --> 404 Page Not Found: Public/assets
ERROR - 2021-04-16 16:26:24 --> 404 Page Not Found: Env/index
ERROR - 2021-04-16 17:19:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-16 19:14:08 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-04-16 20:50:08 --> 404 Page Not Found: Components/com_jbusinessdirectory
