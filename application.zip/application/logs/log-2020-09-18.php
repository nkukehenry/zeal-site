<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-18 09:53:28 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-09-18 15:28:44 --> 404 Page Not Found: Wp/wp_content
ERROR - 2020-09-18 22:18:11 --> 404 Page Not Found: Wordpress/wp_admin
