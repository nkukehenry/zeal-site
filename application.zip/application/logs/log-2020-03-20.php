<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-20 07:37:08 --> 404 Page Not Found: Bitrix/admin
ERROR - 2020-03-20 10:20:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-20 18:17:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-20 20:49:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-20 22:57:17 --> 404 Page Not Found: Robotstxt/index
