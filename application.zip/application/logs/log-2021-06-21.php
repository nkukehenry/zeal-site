<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-21 01:02:28 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2021-06-21 01:02:38 --> 404 Page Not Found: Plugins/content
ERROR - 2021-06-21 01:03:03 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2021-06-21 01:03:15 --> 404 Page Not Found: Plugins/content
ERROR - 2021-06-21 09:18:18 --> 404 Page Not Found: Wp_admin/admin_ajax.php
