<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-06 00:27:16 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-08-06 19:45:56 --> 404 Page Not Found: Wordpress/wp_admin
