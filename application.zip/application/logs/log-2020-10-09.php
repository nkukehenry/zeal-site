<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-09 17:28:08 --> 404 Page Not Found: Faviconico/index
