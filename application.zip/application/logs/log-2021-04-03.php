<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-03 01:49:32 --> 404 Page Not Found: 403shtml/index
ERROR - 2021-04-03 03:20:57 --> 404 Page Not Found: Xxxss/index
ERROR - 2021-04-03 05:17:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-03 05:17:18 --> 404 Page Not Found: Assets/elfinder
ERROR - 2021-04-03 11:02:15 --> 404 Page Not Found: Env/index
ERROR - 2021-04-03 11:02:16 --> 404 Page Not Found: Vendor/.env
ERROR - 2021-04-03 11:02:16 --> 404 Page Not Found: Storage/.env
ERROR - 2021-04-03 11:02:17 --> 404 Page Not Found: Public/.env
ERROR - 2021-04-03 15:35:42 --> 404 Page Not Found: Theme/assets
ERROR - 2021-04-03 17:10:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-03 17:11:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-03 17:15:03 --> 404 Page Not Found: Faviconico/index
