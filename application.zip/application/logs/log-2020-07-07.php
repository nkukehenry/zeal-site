<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-07 16:54:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-07 16:54:15 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-07-07 16:54:15 --> 404 Page Not Found: Apple_touch_icon_precomposedpng/index
ERROR - 2020-07-07 16:54:15 --> 404 Page Not Found: Apple_touch_icon_precomposedpng/index
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-07 16:54:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-07 16:54:15 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-07-07 16:54:17 --> 404 Page Not Found: Apple_touch_icon_120x120_precomposedpng/index
ERROR - 2020-07-07 16:54:17 --> 404 Page Not Found: Apple_touch_icon_120x120png/index
ERROR - 2020-07-07 16:54:17 --> 404 Page Not Found: Apple_touch_icon_precomposedpng/index
ERROR - 2020-07-07 16:54:18 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-07-07 23:39:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-07 23:45:43 --> Query error: Table 'solvhong_kreb.tbl_subscriber' doesn't exist - Invalid query: SELECT * FROM tbl_subscriber WHERE subs_active=1
ERROR - 2020-07-07 23:55:55 --> 404 Page Not Found: Public/home
ERROR - 2020-07-07 23:58:22 --> 404 Page Not Found: Faviconico/index
