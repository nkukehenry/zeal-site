<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-30 03:35:07 --> 404 Page Not Found: Backup/wp_admin
ERROR - 2021-06-30 04:10:04 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-06-30 04:44:05 --> 404 Page Not Found: Wp/wp_admin
