<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-08 06:44:52 --> 404 Page Not Found: Public/assets
ERROR - 2021-05-08 06:44:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-05-08 06:44:52 --> 404 Page Not Found: Public/assets
ERROR - 2021-05-08 06:44:52 --> 404 Page Not Found: Assets/global
ERROR - 2021-05-08 06:44:52 --> 404 Page Not Found: Public/assets
ERROR - 2021-05-08 12:37:45 --> 404 Page Not Found: admin/Assets/global
ERROR - 2021-05-08 12:37:45 --> 404 Page Not Found: admin/Assets/fileupload
ERROR - 2021-05-08 12:37:46 --> 404 Page Not Found: Plugins/fileupload
ERROR - 2021-05-08 12:37:58 --> 404 Page Not Found: admin/Assets/plugins
ERROR - 2021-05-08 19:03:31 --> 404 Page Not Found: Assets/admin
ERROR - 2021-05-08 19:03:31 --> 404 Page Not Found: Theme/assets
ERROR - 2021-05-08 19:03:31 --> 404 Page Not Found: Theme/assets
ERROR - 2021-05-08 19:03:31 --> 404 Page Not Found: Theme/assets
ERROR - 2021-05-08 19:03:31 --> 404 Page Not Found: admin/Fileupload/index.php
ERROR - 2021-05-08 19:03:31 --> 404 Page Not Found: Assets/backend
ERROR - 2021-05-08 20:59:29 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-05-08 22:08:49 --> 404 Page Not Found: Wp_loginphp/index
