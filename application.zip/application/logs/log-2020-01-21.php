<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-21 05:55:02 --> 404 Page Not Found: Robotstxt/index
