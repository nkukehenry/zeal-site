<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-19 11:37:13 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-19 11:37:16 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-19 11:37:29 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-19 11:38:39 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-19 11:38:44 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-19 11:38:56 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
