<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-13 04:26:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-13 09:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-13 11:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-13 17:42:33 --> 404 Page Not Found: Robotstxt/index
