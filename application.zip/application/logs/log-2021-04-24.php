<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-24 17:10:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-24 22:19:20 --> 404 Page Not Found: Assets/admin
