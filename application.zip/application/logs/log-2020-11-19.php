<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-19 00:33:47 --> 404 Page Not Found: Images/gmapfp
ERROR - 2020-11-19 02:12:11 --> 404 Page Not Found: Data/admin
ERROR - 2020-11-19 03:29:21 --> 404 Page Not Found: Env/index
ERROR - 2020-11-19 06:17:24 --> 404 Page Not Found: Env/index
ERROR - 2020-11-19 13:16:03 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-11-19 13:35:49 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2020-11-19 13:35:50 --> 404 Page Not Found: Components/index
ERROR - 2020-11-19 16:45:16 --> 404 Page Not Found: Env/index
