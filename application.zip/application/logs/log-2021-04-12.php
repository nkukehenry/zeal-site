<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-12 01:52:01 --> 404 Page Not Found: Css/album.css
ERROR - 2021-04-12 09:58:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-12 17:42:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-12 17:48:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-12 18:08:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-12 20:54:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-12 21:57:04 --> 404 Page Not Found: admin/Assets/file_uploader
ERROR - 2021-04-12 21:57:04 --> 404 Page Not Found: Public/assets
