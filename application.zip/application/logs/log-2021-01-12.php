<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-12 07:52:02 --> 404 Page Not Found: Sites/all
ERROR - 2021-01-12 07:52:02 --> 404 Page Not Found: Sites/all
ERROR - 2021-01-12 20:26:58 --> 404 Page Not Found: 403shtml/index
ERROR - 2021-01-12 22:31:50 --> 404 Page Not Found: Env/index
ERROR - 2021-01-12 23:17:55 --> 404 Page Not Found: Env/index
