<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-16 02:49:00 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2020-11-16 02:49:35 --> 404 Page Not Found: Wp_admin/index
ERROR - 2020-11-16 02:55:49 --> 404 Page Not Found: Wp_includes/js
ERROR - 2020-11-16 02:55:50 --> 404 Page Not Found: Administrator/help
ERROR - 2020-11-16 02:55:51 --> 404 Page Not Found: Administrator/language
ERROR - 2020-11-16 02:55:52 --> 404 Page Not Found: Plugins/system
ERROR - 2020-11-16 02:55:53 --> 404 Page Not Found: Administrator/index
ERROR - 2020-11-16 02:55:57 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2020-11-16 02:56:00 --> 404 Page Not Found: admin/View/javascript
ERROR - 2020-11-16 02:56:01 --> 404 Page Not Found: admin/Includes/general.js
ERROR - 2020-11-16 02:56:02 --> 404 Page Not Found: Images/editor
ERROR - 2020-11-16 02:56:03 --> 404 Page Not Found: Js/header_rollup_554.js
ERROR - 2020-11-16 02:56:04 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-11-16 02:56:05 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2020-11-16 02:56:07 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-11-16 11:27:32 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-11-16 11:27:32 --> 404 Page Not Found: Sites/all
ERROR - 2020-11-16 11:27:33 --> 404 Page Not Found: admin/Vendor/phpunit
ERROR - 2020-11-16 11:27:33 --> 404 Page Not Found: Laravel/vendor
ERROR - 2020-11-16 11:27:34 --> 404 Page Not Found: App/vendor
ERROR - 2020-11-16 11:27:35 --> 404 Page Not Found: Core/vendor
ERROR - 2020-11-16 11:27:36 --> 404 Page Not Found: Modules/gamification
ERROR - 2020-11-16 11:27:36 --> 404 Page Not Found: Modules/autoupgrade
ERROR - 2020-11-16 19:54:50 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-11-16 20:26:45 --> 404 Page Not Found: Env/index
