<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-20 02:18:22 --> 404 Page Not Found: Images/gmapfp
ERROR - 2020-11-20 05:27:59 --> 404 Page Not Found: Images/gmapfp
