<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-10 13:01:17 --> 404 Page Not Found: Wp_content/plugins
