<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-01 10:07:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-01 14:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-01 15:43:23 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-04-01 22:34:36 --> 404 Page Not Found: Robotstxt/index
