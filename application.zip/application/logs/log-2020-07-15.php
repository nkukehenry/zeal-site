<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-15 08:10:23 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-15 08:10:25 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-15 08:12:40 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-15 08:12:42 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-15 10:16:10 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
