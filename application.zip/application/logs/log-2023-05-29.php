<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-29 09:16:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 09:16:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 09:16:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 09:16:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 09:16:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 09:16:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 09:48:18 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:48:19 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:49:35 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:49:37 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:52:16 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:52:17 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:53:32 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:53:32 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:53:36 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:53:36 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:53:36 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:56:42 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:56:42 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:56:44 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:56:48 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:57:41 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:57:41 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:57:42 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:57:42 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:57:43 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:58:12 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:58:12 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:58:13 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:58:13 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:58:14 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:59:47 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:59:47 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:59:47 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:59:48 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 09:59:48 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 10:00:49 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 10:00:49 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 10:00:49 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 10:00:50 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 10:00:50 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 10:01:20 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 10:01:20 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 10:01:21 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-29 12:40:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 12:40:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 12:40:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 12:40:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 12:40:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 12:40:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 13:25:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 13:25:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 13:25:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 13:25:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 13:25:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 13:25:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 13:26:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 13:26:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 13:26:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 13:26:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 13:48:51 --> Severity: Notice --> Undefined index: category_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 59
ERROR - 2023-05-29 13:48:51 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 60
ERROR - 2023-05-29 13:48:51 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 62
ERROR - 2023-05-29 13:48:51 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 63
ERROR - 2023-05-29 13:49:05 --> Severity: Notice --> Undefined index: currency_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 61
ERROR - 2023-05-29 13:49:05 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 62
ERROR - 2023-05-29 13:49:05 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 68
ERROR - 2023-05-29 13:49:05 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 69
ERROR - 2023-05-29 13:49:05 --> Severity: Notice --> Undefined index: currency_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 61
ERROR - 2023-05-29 13:49:05 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 62
ERROR - 2023-05-29 13:49:05 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 68
ERROR - 2023-05-29 13:49:05 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 69
ERROR - 2023-05-29 13:49:36 --> Severity: Notice --> Undefined index: category_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 59
ERROR - 2023-05-29 13:49:36 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 60
ERROR - 2023-05-29 13:49:36 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 62
ERROR - 2023-05-29 13:49:36 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 63
ERROR - 2023-05-29 13:50:29 --> Severity: Notice --> Undefined variable: remitted_currencies C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 55
ERROR - 2023-05-29 13:50:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 55
ERROR - 2023-05-29 13:51:17 --> Severity: Notice --> Undefined variable: remitted_currencies C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 55
ERROR - 2023-05-29 13:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 55
ERROR - 2023-05-29 13:51:23 --> Severity: Notice --> Undefined variable: remitted_currencies C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 55
ERROR - 2023-05-29 13:51:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 55
ERROR - 2023-05-29 13:51:50 --> Severity: Notice --> Undefined index: currency_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 61
ERROR - 2023-05-29 13:51:50 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 62
ERROR - 2023-05-29 13:51:50 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 68
ERROR - 2023-05-29 13:51:50 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 69
ERROR - 2023-05-29 13:51:50 --> Severity: Notice --> Undefined index: currency_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 61
ERROR - 2023-05-29 13:51:50 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 62
ERROR - 2023-05-29 13:51:50 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 68
ERROR - 2023-05-29 13:51:50 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 69
ERROR - 2023-05-29 13:52:27 --> Severity: Notice --> Undefined index: currency_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 61
ERROR - 2023-05-29 13:52:27 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 62
ERROR - 2023-05-29 13:52:27 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 68
ERROR - 2023-05-29 13:52:27 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 69
ERROR - 2023-05-29 13:52:27 --> Severity: Notice --> Undefined index: currency_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 61
ERROR - 2023-05-29 13:52:27 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 62
ERROR - 2023-05-29 13:52:27 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 68
ERROR - 2023-05-29 13:52:27 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 69
ERROR - 2023-05-29 13:52:29 --> Severity: Notice --> Undefined variable: forex_exchenge C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 55
ERROR - 2023-05-29 13:52:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 55
ERROR - 2023-05-29 13:52:42 --> Severity: Notice --> Undefined variable: forex_exchange C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 55
ERROR - 2023-05-29 13:52:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 55
ERROR - 2023-05-29 13:53:22 --> Severity: Notice --> Undefined index: currency_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 61
ERROR - 2023-05-29 13:53:22 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 62
ERROR - 2023-05-29 13:53:22 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 68
ERROR - 2023-05-29 13:53:22 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 69
ERROR - 2023-05-29 13:56:13 --> Query error: Unknown column 'tbl_currencies.country_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_currencies`
JOIN `tbl_countries` ON `tbl_countries`.`country_id` = `tbl_currencies`.`country_id`
WHERE `is_forex` = 1
ERROR - 2023-05-29 14:00:32 --> Query error: Unknown column 'tbl_currencies.country_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_currencies`
JOIN `tbl_countries` ON `tbl_countries`.`country_id` = `tbl_currencies`.`country_id`
WHERE `is_forex` = 1
ERROR - 2023-05-29 14:01:32 --> Query error: Unknown column 'tbl_currencies.country_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_currencies`
JOIN `tbl_countries` ON `tbl_countries`.`country_id` = `tbl_currencies`.`country_id`
WHERE `is_forex` = 1
ERROR - 2023-05-29 14:09:08 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 68
ERROR - 2023-05-29 14:09:08 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 69
ERROR - 2023-05-29 14:09:34 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 68
ERROR - 2023-05-29 14:09:34 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_forex_exchange.php 69
ERROR - 2023-05-29 14:17:30 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 68
ERROR - 2023-05-29 14:17:30 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 69
ERROR - 2023-05-29 14:18:51 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 68
ERROR - 2023-05-29 14:18:51 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 69
ERROR - 2023-05-29 14:19:01 --> Severity: Notice --> Undefined variable: forex_exchange C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 113
ERROR - 2023-05-29 14:19:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 113
ERROR - 2023-05-29 14:19:01 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 149
ERROR - 2023-05-29 14:19:01 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 150
ERROR - 2023-05-29 14:19:20 --> Severity: Notice --> Undefined variable: forex_exchange C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 113
ERROR - 2023-05-29 14:19:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 113
ERROR - 2023-05-29 14:19:20 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 149
ERROR - 2023-05-29 14:19:20 --> Severity: Notice --> Undefined index: category_id C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 150
ERROR - 2023-05-29 14:19:47 --> Severity: Notice --> Undefined variable: forex_exchange C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 55
ERROR - 2023-05-29 14:19:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_currencies_sending.php 55
ERROR - 2023-05-29 15:00:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:00:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:00:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:00:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:00:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:00:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:01:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:01:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:01:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:01:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:01:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:01:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:14 --> Severity: error --> Exception: syntax error, unexpected '>' C:\xampp\htdocs\zeal-site\application\controllers\Home.php 126
ERROR - 2023-05-29 15:02:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:02:57 --> 404 Page Not Found: Index_2html/index
ERROR - 2023-05-29 15:03:02 --> Severity: error --> Exception: syntax error, unexpected '>' C:\xampp\htdocs\zeal-site\application\controllers\Home.php 126
ERROR - 2023-05-29 15:03:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:03:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:03:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:03:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:03:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:03:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:05:01 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:07:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\zeal-site\application\controllers\Home.php 37
ERROR - 2023-05-29 15:07:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\view_header.php 47
ERROR - 2023-05-29 15:07:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\view_header.php 48
ERROR - 2023-05-29 15:07:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\view_header.php 49
ERROR - 2023-05-29 15:07:12 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\zeal-site\application\views\view_header.php 275
ERROR - 2023-05-29 15:07:12 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\zeal-site\application\views\view_header.php 276
ERROR - 2023-05-29 15:07:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\zeal-site\application\controllers\Home.php 38
ERROR - 2023-05-29 15:07:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\zeal-site\application\controllers\Home.php 39
ERROR - 2023-05-29 15:07:12 --> Severity: Notice --> Undefined variable: setting C:\xampp\htdocs\zeal-site\application\views\view_footer.php 91
ERROR - 2023-05-29 15:07:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:07:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:07:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:07:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:07:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:07:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:07:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:07:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:07:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:07:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:07:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:23:26 --> Query error: Unknown column 'countries.country_id' in 'on clause' - Invalid query: SELECT *
FROM `tbl_currencies`
JOIN `tbl_countries` ON `countries`.`country_id` = `tbl_currencies`.`country_id`
WHERE `is_forex` = 0
ERROR - 2023-05-29 15:23:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:23:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:23:51 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:23:51 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:23:51 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:23:51 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:24:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:24:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:24:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:24:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:24:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:24:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:25:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:25:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:25:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:25:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:26:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:26:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:26:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:26:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:26:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:26:49 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:26:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:26:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:26:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:26:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:27:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:27:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:27:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:27:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:29:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:29:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:29:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:29:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:30:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:35:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:35:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:35:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:35:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:35:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:35:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:35:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:35:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:37:11 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:37:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:37:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:37:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:37:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:37:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:37:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:38:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:38:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:38:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:38:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:38:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:38:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:39:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:39:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:39:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:39:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:39:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:39:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:40:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:40:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:40:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:40:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:40:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:40:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:41:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:41:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:41:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:41:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:42:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:42:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:42:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:42:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:44:31 --> Severity: error --> Exception: Too few arguments to function Portfolio_category::edit(), 0 passed in C:\xampp\htdocs\zeal-site\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\zeal-site\application\controllers\admin\Portfolio_category.php 71
ERROR - 2023-05-29 15:53:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:53:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:53:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:53:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:53:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:53:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:53:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:56:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:56:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:56:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:56:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:56:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:57:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:57:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:57:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:57:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:57:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:57:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:57:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:58:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:58:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:58:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:58:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:58:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:58:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:58:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:58:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:58:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:58:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:59:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:59:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:59:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:59:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:59:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:59:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:59:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:59:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:59:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 15:59:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:00:18 --> Severity: Error --> Out of memory (allocated 2097152) (tried to allocate 131072 bytes) C:\xampp\htdocs\zeal-site\system\libraries\Session\Session.php 136
ERROR - 2023-05-29 16:01:10 --> Severity: Error --> Out of memory (allocated 2097152) (tried to allocate 131072 bytes) C:\xampp\htdocs\zeal-site\system\libraries\Session\Session.php 136
ERROR - 2023-05-29 16:02:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:02:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:02:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:02:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:02:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:02:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:02:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:06:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:06:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:11:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:11:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:11:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:11:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:11:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:11:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:12:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:12:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:12:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:12:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:12:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:12:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:12:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:12:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:13:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:13:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:13:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:13:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:13:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:13:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:13:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:13:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:13:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:13:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:13:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:13:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:14:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:14:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:14:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:14:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:15:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:15:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:15:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:15:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:15:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:15:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:16:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:16:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:16:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:16:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:16:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:16:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:19:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:19:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:19:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:19:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:20:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:20:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:20:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:20:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:20:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:20:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:22:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:22:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:22:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:22:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:22:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:23:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:23:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:23:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:23:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:23:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:23:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:23:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:23:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:23:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:23:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:23:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:23:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:33:06 --> Severity: Notice --> Undefined variable: forex C:\xampp\htdocs\zeal-site\application\views\view_home.php 61
ERROR - 2023-05-29 16:33:06 --> Severity: Notice --> Undefined variable: forex C:\xampp\htdocs\zeal-site\application\views\view_home.php 61
ERROR - 2023-05-29 16:33:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:33:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:33:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:33:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:33:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:33:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:33:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:33:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:33:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:33:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:38:49 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:38:49 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:38:49 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:38:49 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:38:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:38:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:38:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:38:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:38:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:39:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:39:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:39:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:39:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:39:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:39:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:40:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:40:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:40:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:40:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:40:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:40:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:42:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:42:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:42:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:42:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:42:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:44:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:44:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:44:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:44:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:44:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:44:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:44:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:44:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:44:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:44:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:44:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:45:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:45:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:45:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:45:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:45:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:45:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:45:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:45:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:45:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:45:51 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:54:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:54:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:54:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:54:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:54:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:54:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:55:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:55:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:55:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:55:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:56:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:56:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:56:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:56:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:57:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:57:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:57:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:57:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:57:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:58:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:58:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:58:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:58:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:58:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:58:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:59:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:59:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:59:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:59:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:59:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:59:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:59:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:59:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:59:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:59:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:59:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 16:59:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:09:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:09:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:09:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:09:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:09:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:09:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:10:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:10:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:10:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:10:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:10:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:10:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:10:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:10:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:10:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:10:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:14:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:14:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:14:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:14:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:18:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:18:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:18:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:18:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:18:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:18:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:21:11 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:21:11 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:21:11 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:21:11 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:21:11 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:21:11 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:21:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:21:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:21:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:21:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:21:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:21:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:22:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:22:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:22:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:22:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:23:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:23:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:23:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:23:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:23:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:23:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:24:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:24:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:24:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:24:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:24:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:24:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:27:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:27:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:27:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:27:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:30:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:30:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:30:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:30:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:30:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:30:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:40:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:41:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:41:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:41:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:59:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:59:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:59:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:59:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:59:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 17:59:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:02:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:02:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:02:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:02:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:02:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:02:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:03:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:03:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:03:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:03:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:03:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:03:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:04:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:04:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:04:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:04:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:04:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:04:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:05:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:05:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:05:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:05:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:05:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 18:05:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:16:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:16:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:16:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:16:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:16:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:16:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:23:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:28:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:28:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:28:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:28:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:28:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:28:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:28:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:28:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:28:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:28:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:31:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-29 22:32:12 --> 404 Page Not Found: Send_moneyhtml/index
