<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-05 01:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-05 11:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-05 14:59:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-05 19:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-05 19:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-05 20:39:24 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-04-05 20:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-05 23:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-05 23:04:21 --> 404 Page Not Found: Robotstxt/index
