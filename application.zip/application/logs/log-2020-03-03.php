<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-03 02:27:46 --> 404 Page Not Found: Test/license.txt
ERROR - 2020-03-03 10:23:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-03-03 10:23:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-03-03 14:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-03 21:40:18 --> 404 Page Not Found: Robotstxt/index
