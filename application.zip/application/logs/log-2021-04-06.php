<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-06 02:06:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-06 02:24:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-06 02:29:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-06 11:00:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-06 13:50:55 --> 404 Page Not Found: Backup/wp_admin
ERROR - 2021-04-06 17:24:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-06 17:38:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-06 18:49:23 --> 404 Page Not Found: Assets/global
ERROR - 2021-04-06 22:12:00 --> 404 Page Not Found: Assets/backend
ERROR - 2021-04-06 23:36:47 --> 404 Page Not Found: Env/index
