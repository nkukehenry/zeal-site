<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-01 00:30:05 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-02-01 00:52:53 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-02-01 06:26:31 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-02-01 06:30:07 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-02-01 06:56:14 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-02-01 07:01:07 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-02-01 07:05:12 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-02-01 09:37:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-02-01 10:12:12 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-02-01 11:26:26 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-02-01 12:03:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-02-01 13:18:26 --> 404 Page Not Found: Test/wp_login.php
ERROR - 2020-02-01 16:41:43 --> 404 Page Not Found: Wp/wp_login.php
ERROR - 2020-02-01 17:34:02 --> 404 Page Not Found: Aws/credentials
ERROR - 2020-02-01 17:39:55 --> 404 Page Not Found: Aws/credentials
ERROR - 2020-02-01 19:20:42 --> 404 Page Not Found: Aws/credentials
ERROR - 2020-02-01 19:31:03 --> 404 Page Not Found: Wp1/wp_login.php
ERROR - 2020-02-01 21:42:22 --> 404 Page Not Found: Wp2/wp_login.php
ERROR - 2020-02-01 22:30:27 --> 404 Page Not Found: Aws/credentials
ERROR - 2020-02-01 23:53:16 --> 404 Page Not Found: 2020/wp_login.php
