<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-08 09:23:50 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2020-11-08 14:00:16 --> 404 Page Not Found: Wp_admin/index
