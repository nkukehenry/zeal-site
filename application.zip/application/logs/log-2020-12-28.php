<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-28 01:01:39 --> 404 Page Not Found: Wp_includes/css
ERROR - 2020-12-28 01:01:44 --> 404 Page Not Found: Media/system
ERROR - 2020-12-28 21:36:48 --> 404 Page Not Found: Wp_admin/index
