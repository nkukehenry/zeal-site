<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-28 02:36:27 --> 404 Page Not Found: Wp_includes/index
ERROR - 2021-06-28 02:52:15 --> 404 Page Not Found: Wp_includes/class_wp_page_cache.php
ERROR - 2021-06-28 02:52:28 --> 404 Page Not Found: Wp_includes/lfx.php
ERROR - 2021-06-28 06:11:21 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2021-06-28 06:12:16 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2021-06-28 23:40:52 --> 404 Page Not Found: Test/wp_admin
