<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-17 07:14:26 --> 404 Page Not Found: admin/Assets/jquery.filer
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-17 07:14:26 --> 404 Page Not Found: Assets/newweb
ERROR - 2021-05-17 07:14:26 --> 404 Page Not Found: Public/assets
ERROR - 2021-05-17 07:14:26 --> 404 Page Not Found: Assets/jquery.filer
ERROR - 2021-05-17 13:12:35 --> 404 Page Not Found: Public/assets
ERROR - 2021-05-17 13:12:35 --> 404 Page Not Found: admin/Assets/jquery_multiple_file_upload
ERROR - 2021-05-17 13:12:35 --> 404 Page Not Found: Assets/jquery_multiple_file_upload
ERROR - 2021-05-17 13:12:35 --> 404 Page Not Found: admin/Jquery_multiple_file_upload/multiplefileupload.html
ERROR - 2021-05-17 19:42:45 --> 404 Page Not Found: admin/Uploadify/uploadify.css
ERROR - 2021-05-17 19:42:45 --> 404 Page Not Found: Theme/assets
ERROR - 2021-05-17 19:42:45 --> 404 Page Not Found: admin/Assets/uploadify
ERROR - 2021-05-17 19:42:45 --> 404 Page Not Found: Assets/uploadify
ERROR - 2021-05-17 19:42:45 --> 404 Page Not Found: Public/assets
ERROR - 2021-05-17 21:23:16 --> 404 Page Not Found: Wp/wp_admin
