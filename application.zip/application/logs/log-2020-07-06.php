<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-06 10:25:34 --> 404 Page Not Found: Ad/index
ERROR - 2020-07-06 10:25:36 --> 404 Page Not Found: Adm/index
ERROR - 2020-07-06 10:25:36 --> 404 Page Not Found: Admi/index
ERROR - 2020-07-06 10:25:51 --> 404 Page Not Found: Faviconico/index
