<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-14 00:31:33 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-01-14 15:42:47 --> 404 Page Not Found: Env/index
ERROR - 2021-01-14 15:42:50 --> 404 Page Not Found: Wp_content/index
ERROR - 2021-01-14 20:57:35 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-01-14 20:58:26 --> 404 Page Not Found: Wp_includes/fonts
