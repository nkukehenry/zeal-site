<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-27 14:33:43 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-12-27 23:47:33 --> 404 Page Not Found: A/index
ERROR - 2020-12-27 23:47:33 --> 404 Page Not Found: Public/js
ERROR - 2020-12-27 23:47:38 --> 404 Page Not Found: Util/login.aspx
ERROR - 2020-12-27 23:47:38 --> 404 Page Not Found: Installphp/index
ERROR - 2020-12-27 23:47:38 --> 404 Page Not Found: Magento_version/index
