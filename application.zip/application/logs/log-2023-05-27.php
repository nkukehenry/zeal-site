<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-27 09:28:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 09:28:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 09:28:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 09:28:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 09:28:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 09:28:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 09:33:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 09:33:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 09:33:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 09:33:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:12:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:12:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:12:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:12:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:12:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:12:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:28:59 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 10:29:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:48:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:48:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:48:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:48:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:48:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:48:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:48:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:48:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:48:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:48:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:48:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:48:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:48:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:48:59 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:49:01 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:49:01 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:49:01 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:49:01 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:52:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:52:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:52:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:52:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:52:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 18:52:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 19:21:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 19:21:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 19:21:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 19:21:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 19:21:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 19:21:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 22:22:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 22:22:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 22:22:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 22:22:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 22:22:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 22:22:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-27 22:26:46 --> 404 Page Not Found: admin/Remitted_currencies/index
ERROR - 2023-05-27 22:26:48 --> 404 Page Not Found: admin/Forex_curryncies/index
ERROR - 2023-05-27 22:38:40 --> 404 Page Not Found: admin/Remitted_currencies/index
ERROR - 2023-05-27 22:44:14 --> 404 Page Not Found: admin/Remitted_currencies/index
ERROR - 2023-05-27 22:44:15 --> 404 Page Not Found: admin/Remitted_currencies/index
ERROR - 2023-05-27 22:44:15 --> 404 Page Not Found: admin/Remitted_currencies/index
ERROR - 2023-05-27 22:44:15 --> 404 Page Not Found: admin/Remitted_currencies/index
ERROR - 2023-05-27 22:44:16 --> 404 Page Not Found: admin/Remitted_currencies/index
ERROR - 2023-05-27 22:44:21 --> 404 Page Not Found: admin/Remitted_currencies/index
ERROR - 2023-05-27 22:47:47 --> 404 Page Not Found: admin/Remitted_currencies/index
ERROR - 2023-05-27 22:51:16 --> 404 Page Not Found: admin/Remitted_currencies/index
ERROR - 2023-05-27 22:51:19 --> 404 Page Not Found: admin/Remitted_currencies/index
ERROR - 2023-05-27 22:52:59 --> 404 Page Not Found: admin/Remitted_currencies/index
ERROR - 2023-05-27 22:53:08 --> 404 Page Not Found: admin/Remitted_currencies/index
ERROR - 2023-05-27 22:54:11 --> 404 Page Not Found: admin/Remitted_currencies/index
ERROR - 2023-05-27 22:54:15 --> 404 Page Not Found: Currencies/remitted_currencies
ERROR - 2023-05-27 22:54:44 --> 404 Page Not Found: Currencies/remitted_currencies
ERROR - 2023-05-27 22:54:45 --> 404 Page Not Found: Currencies/remitted_currencies
ERROR - 2023-05-27 22:54:45 --> 404 Page Not Found: Currencies/remitted_currencies
ERROR - 2023-05-27 22:54:48 --> Severity: error --> Exception: Unable to locate the model you have specified: Model_currencies C:\xampp\htdocs\zeal-site\system\core\Loader.php 348
ERROR - 2023-05-27 22:55:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Model_currencies C:\xampp\htdocs\zeal-site\system\core\Loader.php 348
ERROR - 2023-05-27 22:55:43 --> 404 Page Not Found: admin/Currencies/forex_curryncies
ERROR - 2023-05-27 23:03:47 --> 404 Page Not Found: admin/Currencies/forex_curryncies
ERROR - 2023-05-27 23:03:53 --> 404 Page Not Found: admin/Currencies/forex_curryncies
ERROR - 2023-05-27 23:04:15 --> 404 Page Not Found: admin/Currencies/forex_curryncies
ERROR - 2023-05-27 23:04:21 --> 404 Page Not Found: admin/Currencies/forex_curryncies
ERROR - 2023-05-27 23:04:23 --> 404 Page Not Found: admin/Currencies/forex_curryncies
ERROR - 2023-05-27 23:04:26 --> Severity: error --> Exception: Unable to locate the model you have specified: Model_currencies C:\xampp\htdocs\zeal-site\system\core\Loader.php 348
ERROR - 2023-05-27 23:04:28 --> 404 Page Not Found: admin/Currencies/forex_curryncies
ERROR - 2023-05-27 23:04:32 --> 404 Page Not Found: admin/Currencies/forex_curryncies
ERROR - 2023-05-27 23:04:35 --> 404 Page Not Found: admin/Currencies/forex_curryncies
ERROR - 2023-05-27 23:05:04 --> Severity: error --> Exception: Unable to locate the model you have specified: Model_currencies C:\xampp\htdocs\zeal-site\system\core\Loader.php 348
ERROR - 2023-05-27 23:07:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Model_currencies C:\xampp\htdocs\zeal-site\system\core\Loader.php 348
ERROR - 2023-05-27 23:08:12 --> Severity: error --> Exception: C:\xampp\htdocs\zeal-site\application\models/admin/Model_currencies.php exists, but doesn't declare class Model_currencies C:\xampp\htdocs\zeal-site\system\core\Loader.php 340
ERROR - 2023-05-27 23:09:14 --> Severity: Notice --> Undefined property: Currencies::$Model_common C:\xampp\htdocs\zeal-site\application\controllers\admin\Currencies.php 16
ERROR - 2023-05-27 23:09:14 --> Severity: error --> Exception: Call to a member function get_setting_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Currencies.php 16
ERROR - 2023-05-27 23:10:23 --> Severity: Notice --> Undefined property: Currencies::$Model_common C:\xampp\htdocs\zeal-site\application\controllers\admin\Currencies.php 27
ERROR - 2023-05-27 23:10:23 --> Severity: error --> Exception: Call to a member function get_setting_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Currencies.php 27
ERROR - 2023-05-27 23:10:27 --> Severity: Notice --> Undefined property: Currencies::$Model_common C:\xampp\htdocs\zeal-site\application\controllers\admin\Currencies.php 16
ERROR - 2023-05-27 23:10:27 --> Severity: error --> Exception: Call to a member function get_setting_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Currencies.php 16
ERROR - 2023-05-27 23:10:51 --> Severity: Notice --> Undefined property: Currencies::$Model_common C:\xampp\htdocs\zeal-site\application\controllers\admin\Currencies.php 16
ERROR - 2023-05-27 23:10:51 --> Severity: error --> Exception: Call to a member function get_setting_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Currencies.php 16
ERROR - 2023-05-27 23:14:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\zeal-site\application\controllers\admin\Currencies.php 19
ERROR - 2023-05-27 23:14:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\zeal-site\application\controllers\admin\Currencies.php 20
ERROR - 2023-05-27 23:20:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\zeal-site\application\controllers\admin\Currencies.php 19
ERROR - 2023-05-27 23:20:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\zeal-site\application\controllers\admin\Currencies.php 20
ERROR - 2023-05-27 23:22:08 --> Severity: Notice --> Undefined property: Currencies::$Model_common C:\xampp\htdocs\zeal-site\application\controllers\admin\Currencies.php 17
ERROR - 2023-05-27 23:22:08 --> Severity: error --> Exception: Call to a member function get_setting_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Currencies.php 17
ERROR - 2023-05-27 23:24:22 --> Query error: Table 'zealforex.tbl_subscriber' doesn't exist - Invalid query: SELECT * FROM tbl_subscriber WHERE subs_active=1
