<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-09 06:25:18 --> 404 Page Not Found: Env/index
ERROR - 2020-12-09 06:25:50 --> 404 Page Not Found: Env/index
ERROR - 2020-12-09 06:26:20 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-12-09 13:33:29 --> 404 Page Not Found: Env/index
ERROR - 2020-12-09 13:41:15 --> 404 Page Not Found: Env/index
ERROR - 2020-12-09 18:43:43 --> 404 Page Not Found: Wordpress/wp_admin
