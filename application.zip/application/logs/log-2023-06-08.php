<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-08 11:01:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:01:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:01:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:01:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:01:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:01:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:02:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:02:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:02:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:02:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:02:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:11:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:11:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:11:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:11:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:11:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:11:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:16:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:22:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:22:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:22:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:22:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:22:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:22:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:24:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:24:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:24:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:24:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:24:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:24:51 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_title C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 958
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_description C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 965
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_logo C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 986
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_title C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 958
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_description C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 965
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_logo C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 986
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_title C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 958
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_description C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 965
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_logo C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 986
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_title C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 958
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_description C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 965
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_logo C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 986
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_title C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 958
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_description C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 965
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_logo C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 986
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_title C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 958
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_description C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 965
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_logo C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 986
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_title C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 958
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_description C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 965
ERROR - 2023-06-08 11:53:05 --> Severity: Notice --> Undefined index: partner_logo C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 986
ERROR - 2023-06-08 11:57:15 --> Severity: Notice --> Undefined index: our_review_client_image C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 947
ERROR - 2023-06-08 11:57:15 --> Severity: Notice --> Undefined index: our_review_client_image C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 947
ERROR - 2023-06-08 11:57:15 --> Severity: Notice --> Undefined index: our_review_client_image C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 947
ERROR - 2023-06-08 11:57:15 --> Severity: Notice --> Undefined index: our_review_client_image C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 947
ERROR - 2023-06-08 11:57:15 --> Severity: Notice --> Undefined index: our_review_client_image C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 947
ERROR - 2023-06-08 11:57:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:57:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:57:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:57:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:57:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:58:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:58:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:58:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:58:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:58:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:58:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:58:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:58:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:58:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 11:58:59 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:24:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:24:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:24:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:24:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:24:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:24:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:26:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\zeal-site\application\models\admin\content_management\Home_content_management_mdl.php 159
ERROR - 2023-06-08 12:28:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:28:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:28:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:28:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:31:11 --> Severity: Notice --> Undefined variable: image C:\xampp\htdocs\zeal-site\application\models\admin\content_management\Home_content_management_mdl.php 161
ERROR - 2023-06-08 12:31:11 --> Query error: Column 'partner_logo' cannot be null - Invalid query: INSERT INTO `tbl_home_partners` (`partner_title`, `partner_logo`, `partner_description`) VALUES ('Centenary Bank', NULL, 'We are dealing with Centenary Bank')
ERROR - 2023-06-08 12:32:11 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:32:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:32:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:32:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:32:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:32:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:32:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:32:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:32:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:33:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-08 12:34:51 --> 404 Page Not Found: Assets/site
