<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-29 18:08:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-02-29 18:08:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-02-29 18:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-02-29 18:13:54 --> 404 Page Not Found: Robotstxt/index
