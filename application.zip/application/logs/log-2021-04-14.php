<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-14 17:09:06 --> 404 Page Not Found: Adminerphp/index
ERROR - 2021-04-14 17:15:02 --> 404 Page Not Found: Faviconico/index
