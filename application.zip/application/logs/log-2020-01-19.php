<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-19 03:17:34 --> 404 Page Not Found: Adstxt/index
