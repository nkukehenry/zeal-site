<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-02 13:22:40 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-05-02 13:22:41 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-05-02 21:33:53 --> 404 Page Not Found: admin/Jquery_file_upload/server
