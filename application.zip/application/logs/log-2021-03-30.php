<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-30 00:11:47 --> 404 Page Not Found: Plugins/jquery_file_upload
ERROR - 2021-03-30 06:21:43 --> 404 Page Not Found: Env/index
ERROR - 2021-03-30 12:49:02 --> 404 Page Not Found: Assets/backend
ERROR - 2021-03-30 12:49:02 --> 404 Page Not Found: Assets/admin
ERROR - 2021-03-30 17:11:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-30 17:48:48 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-03-30 17:49:38 --> 404 Page Not Found: Wp_includes/fonts
ERROR - 2021-03-30 20:08:26 --> 404 Page Not Found: Env/index
