<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-16 12:46:06 --> 404 Page Not Found: Public/uploads
ERROR - 2022-02-16 12:46:09 --> 404 Page Not Found: Public/uploads
