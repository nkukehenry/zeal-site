<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-04 15:38:49 --> 404 Page Not Found: _profiler/empty
