<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-12 04:24:09 --> 404 Page Not Found: Wp/wp_admin
ERROR - 2020-12-12 11:06:02 --> 404 Page Not Found: Wp_admin/index
ERROR - 2020-12-12 14:35:37 --> 404 Page Not Found: Env/index
ERROR - 2020-12-12 14:35:50 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-12-12 21:14:13 --> 404 Page Not Found: Oluxphp/index
ERROR - 2020-12-12 21:14:16 --> 404 Page Not Found: Indoxploitphp/index
ERROR - 2020-12-12 21:14:19 --> 404 Page Not Found: Indoxploitphp/index
ERROR - 2020-12-12 21:14:21 --> 404 Page Not Found: Wsophp/index
ERROR - 2020-12-12 21:14:25 --> 404 Page Not Found: Images/index
ERROR - 2020-12-12 21:14:27 --> 404 Page Not Found: Uploads/index
ERROR - 2020-12-12 21:14:29 --> 404 Page Not Found: Img/index
ERROR - 2020-12-12 21:14:31 --> 404 Page Not Found: Upload/index
ERROR - 2020-12-12 21:14:34 --> 404 Page Not Found: Gallery/index
ERROR - 2020-12-12 21:14:37 --> 404 Page Not Found: Files/index
ERROR - 2020-12-12 21:14:39 --> 404 Page Not Found: Pdf/index
ERROR - 2020-12-12 21:14:42 --> 404 Page Not Found: Docs/index
ERROR - 2020-12-12 21:14:47 --> 404 Page Not Found: Upphp/index
ERROR - 2020-12-12 21:15:01 --> 404 Page Not Found: Uploadphp/index
ERROR - 2020-12-12 21:15:04 --> 404 Page Not Found: Shellphp/index
