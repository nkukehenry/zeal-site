<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-05 08:05:54 --> 404 Page Not Found: Google06ee0fde9864ffdfhtml/index
ERROR - 2020-10-05 17:10:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-10-05 21:02:01 --> 404 Page Not Found: Wp_content/plugins
