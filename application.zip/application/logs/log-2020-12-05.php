<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-05 05:17:51 --> 404 Page Not Found: Wp_admin/index
ERROR - 2020-12-05 07:52:20 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-05 07:52:35 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-05 07:52:49 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-05 07:53:03 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-05 07:53:19 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-05 07:53:36 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-05 07:53:52 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-05 07:54:10 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-05 07:54:27 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-05 10:17:21 --> 404 Page Not Found: Google06ee0fde9864ffdfhtml/index
ERROR - 2020-12-05 20:43:23 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-05 20:44:06 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-05 20:44:45 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-05 20:45:29 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-05 20:46:08 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-05 20:46:46 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-05 20:47:58 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-05 20:48:39 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-05 20:49:20 --> 404 Page Not Found: 403shtml/index
