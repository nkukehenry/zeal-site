<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-26 10:49:02 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-05-26 15:26:29 --> 404 Page Not Found: Wp_admin/index
