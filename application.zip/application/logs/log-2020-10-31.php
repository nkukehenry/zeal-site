<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-31 17:12:06 --> 404 Page Not Found: Faviconico/index
