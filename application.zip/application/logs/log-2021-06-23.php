<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-23 06:57:12 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-06-23 08:48:24 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2021-06-23 08:48:33 --> 404 Page Not Found: Wp/wp_admin
ERROR - 2021-06-23 08:48:46 --> 404 Page Not Found: New/wp_admin
ERROR - 2021-06-23 08:48:58 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-06-23 08:49:05 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-06-23 08:49:24 --> 404 Page Not Found: Test/wp_admin
ERROR - 2021-06-23 08:49:33 --> 404 Page Not Found: Blog/wp_admin
ERROR - 2021-06-23 08:49:44 --> 404 Page Not Found: Cms/wp_admin
ERROR - 2021-06-23 08:50:01 --> 404 Page Not Found: Web/wp_admin
ERROR - 2021-06-23 08:50:14 --> 404 Page Not Found: Backup/wp_admin
ERROR - 2021-06-23 08:50:28 --> 404 Page Not Found: Site/wp_admin
ERROR - 2021-06-23 08:50:39 --> 404 Page Not Found: Oldsite/wp_admin
