<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-23 01:38:41 --> 404 Page Not Found: Git/HEAD
ERROR - 2021-02-23 04:56:06 --> 404 Page Not Found: Git/HEAD
ERROR - 2021-02-23 05:40:22 --> 404 Page Not Found: Git/HEAD
ERROR - 2021-02-23 07:16:55 --> 404 Page Not Found: 403shtml/index
ERROR - 2021-02-23 12:24:54 --> 404 Page Not Found: Wordpress/wp_admin
