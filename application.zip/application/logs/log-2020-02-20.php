<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-20 08:01:56 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-02-20 08:01:56 --> 404 Page Not Found: Well_known/autoconfig
ERROR - 2020-02-20 09:02:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-02-20 16:35:02 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-02-20 16:35:02 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-02-20 16:35:23 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-02-20 16:35:23 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-02-20 16:37:23 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-02-20 16:37:24 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-02-20 18:01:50 --> 404 Page Not Found: Wp_loginphp/index
