<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-22 17:13:00 --> 404 Page Not Found: Env/index
ERROR - 2021-04-22 17:13:06 --> 404 Page Not Found: Vendor/.env
ERROR - 2021-04-22 17:13:06 --> 404 Page Not Found: Storage/.env
ERROR - 2021-04-22 17:13:06 --> 404 Page Not Found: Public/.env
ERROR - 2021-04-22 17:33:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-22 17:33:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-22 17:36:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-22 17:39:37 --> 404 Page Not Found: Faviconico/index
