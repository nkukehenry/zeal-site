<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-29 03:21:17 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-09-29 10:34:05 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-09-29 12:20:39 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-29 12:20:54 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-29 12:20:56 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-29 12:21:10 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-29 12:21:12 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-29 12:21:16 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-29 12:21:21 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-29 12:21:25 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-29 12:21:29 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-29 12:21:32 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-29 12:21:35 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-29 12:21:37 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-29 18:55:05 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2020-09-29 19:01:35 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2020-09-29 19:08:02 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2020-09-29 19:54:53 --> 404 Page Not Found: Atomxml/index
