<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-26 10:40:45 --> 404 Page Not Found: Blog/license.txt
