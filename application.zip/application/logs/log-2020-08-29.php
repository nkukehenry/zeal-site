<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-29 18:20:10 --> 404 Page Not Found: Wp_content/plugins
