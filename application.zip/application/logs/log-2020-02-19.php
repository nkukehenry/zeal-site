<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-19 22:03:35 --> 404 Page Not Found: Robotstxt/index
