<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-19 01:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-19 03:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-19 04:25:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-03-19 10:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-19 13:40:58 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-03-19 16:32:44 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-03-19 16:32:44 --> 404 Page Not Found: Well_known/autoconfig
ERROR - 2020-03-19 18:21:15 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-03-19 20:21:02 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-03-19 21:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-19 23:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-19 23:01:53 --> 404 Page Not Found: Faviconico/index
