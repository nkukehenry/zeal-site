<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-08 01:31:09 --> 404 Page Not Found: Env/index
ERROR - 2021-03-08 07:58:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-03-08 07:58:13 --> 404 Page Not Found: admin/Assets/plugins
ERROR - 2021-03-08 10:16:42 --> 404 Page Not Found: Assets/mobile
ERROR - 2021-03-08 17:09:10 --> 404 Page Not Found: Faviconico/index
