<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-21 02:12:19 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2021-01-21 03:25:25 --> 404 Page Not Found: Wp_admin/config.bak.php
ERROR - 2021-01-21 23:15:29 --> 404 Page Not Found: Wp_content/plugins
