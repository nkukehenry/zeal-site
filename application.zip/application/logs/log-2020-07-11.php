<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-11 05:29:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-11 08:07:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-11 08:38:23 --> 404 Page Not Found: Wemail/index
ERROR - 2020-07-11 09:15:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-11 09:26:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-11 09:35:03 --> 404 Page Not Found: Google2db62eba065ea73bhtml/index
ERROR - 2020-07-11 09:35:03 --> 404 Page Not Found: Google06ee0fde9864ffdfhtml/index
ERROR - 2020-07-11 09:37:19 --> 404 Page Not Found: Google06ee0fde9864ffdfhtml/index
ERROR - 2020-07-11 09:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-11 09:40:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-11 09:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-11 22:22:06 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-11 22:22:40 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
