<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-20 01:20:43 --> 404 Page Not Found: Feed/index
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-20 01:20:43 --> 404 Page Not Found: Rssxml/index
ERROR - 2021-06-20 01:20:43 --> 404 Page Not Found: Indexrss/index
ERROR - 2021-06-20 01:20:43 --> 404 Page Not Found: Feeds/index
ERROR - 2021-06-20 01:20:43 --> 404 Page Not Found: Indexrdf/index
ERROR - 2021-06-20 01:20:43 --> 404 Page Not Found: Indexxml/index
ERROR - 2021-06-20 04:33:51 --> 404 Page Not Found: Wp_admin/index
ERROR - 2021-06-20 20:30:23 --> 404 Page Not Found: Wp_includes/index
ERROR - 2021-06-20 23:24:56 --> 404 Page Not Found: Vendor/phpunit
