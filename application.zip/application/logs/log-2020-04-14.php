<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-14 07:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-14 08:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-14 13:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-14 14:11:23 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-04-14 17:29:05 --> 404 Page Not Found: Ntn/index
ERROR - 2020-04-14 17:29:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-04-14 17:29:16 --> 404 Page Not Found: Ntn/index
ERROR - 2020-04-14 17:29:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-04-14 20:14:21 --> 404 Page Not Found: Robotstxt/index
