<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-19 06:20:34 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2020-09-19 07:35:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-09-19 10:37:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-09-19 10:39:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-09-19 17:24:39 --> 404 Page Not Found: Xxxss/index
ERROR - 2020-09-19 17:24:40 --> 404 Page Not Found: Css/album.css
ERROR - 2020-09-19 20:03:10 --> 404 Page Not Found: Wp/index
ERROR - 2020-09-19 20:03:41 --> 404 Page Not Found: Wordpress/index
ERROR - 2020-09-19 20:05:12 --> 404 Page Not Found: Wp/index
ERROR - 2020-09-19 20:06:02 --> 404 Page Not Found: Wordpress/index
ERROR - 2020-09-19 22:15:41 --> 404 Page Not Found: Wp/wp_admin
