<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-09 01:25:17 --> 404 Page Not Found: Wp_admin/upgrade.php
ERROR - 2021-03-09 08:21:06 --> 404 Page Not Found: Assets/mobile
ERROR - 2021-03-09 08:21:06 --> 404 Page Not Found: Assets/jquery_file_upload
ERROR - 2021-03-09 08:21:06 --> 404 Page Not Found: Assets/jquery_file_upload
ERROR - 2021-03-09 08:21:06 --> 404 Page Not Found: Assets/mobile
ERROR - 2021-03-09 17:15:35 --> 404 Page Not Found: Public/assets
ERROR - 2021-03-09 17:15:35 --> 404 Page Not Found: Public/assets
ERROR - 2021-03-09 17:15:35 --> 404 Page Not Found: Assets/plupload
ERROR - 2021-03-09 17:15:35 --> 404 Page Not Found: Public/assets
ERROR - 2021-03-09 17:15:35 --> 404 Page Not Found: Assets/backend
ERROR - 2021-03-09 17:19:11 --> 404 Page Not Found: Faviconico/index
