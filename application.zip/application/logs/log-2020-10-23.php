<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-23 11:07:14 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-10-23 11:14:14 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-10-23 17:17:13 --> 404 Page Not Found: Faviconico/index
