<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-12 13:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-12 13:13:07 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-04-12 18:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-12 21:45:03 --> 404 Page Not Found: Robotstxt/index
