<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-09 14:05:51 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-01-09 22:49:02 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-01-09 22:49:03 --> 404 Page Not Found: Adstxt/index
