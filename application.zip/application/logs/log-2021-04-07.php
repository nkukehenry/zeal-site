<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-07 12:06:18 --> 404 Page Not Found: Public/assets
ERROR - 2021-04-07 12:35:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-07 17:25:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-07 17:27:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-07 17:28:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-07 17:33:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-07 22:07:44 --> 404 Page Not Found: Wp_admin/index
ERROR - 2021-04-07 22:40:23 --> 404 Page Not Found: E/data
ERROR - 2021-04-07 23:51:19 --> 404 Page Not Found: Wordpress/wp_admin
