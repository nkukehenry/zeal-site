<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-15 04:48:33 --> 404 Page Not Found: Env/index
ERROR - 2021-03-15 04:48:34 --> 404 Page Not Found: Wp_content/index
ERROR - 2021-03-15 13:27:06 --> 404 Page Not Found: Wp_admin/index
ERROR - 2021-03-15 16:25:03 --> 404 Page Not Found: __media__/js
ERROR - 2021-03-15 17:27:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-15 17:27:23 --> 404 Page Not Found: Faviconico/index
