<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-01 20:47:35 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-10-01 20:51:42 --> 404 Page Not Found: Wp_content/plugins
