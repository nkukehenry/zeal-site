<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-03 02:36:35 --> 404 Page Not Found: Wp_loginphp/index
