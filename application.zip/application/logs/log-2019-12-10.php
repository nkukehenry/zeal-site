<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-10 19:49:03 --> 404 Page Not Found: Robotstxt/index
