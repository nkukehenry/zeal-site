<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-09 09:26:49 --> 404 Page Not Found: admin/Assets/plugins
ERROR - 2021-04-09 09:26:49 --> 404 Page Not Found: Public/admin
ERROR - 2021-04-09 12:33:53 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-04-09 12:33:53 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-04-09 12:33:54 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-04-09 17:25:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-09 18:07:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-09 18:07:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-09 18:07:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-09 18:07:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-09 19:59:10 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-04-09 20:58:01 --> 404 Page Not Found: Assets/admin
ERROR - 2021-04-09 22:25:55 --> 404 Page Not Found: Faviconico/index
