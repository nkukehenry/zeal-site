<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-14 13:08:57 --> 404 Page Not Found: Wp_loginphp/index
