<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-21 07:08:46 --> 404 Page Not Found: Env/index
ERROR - 2020-12-21 15:46:35 --> 404 Page Not Found: Configbakphp/index
