<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-13 02:54:55 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-02-13 05:56:59 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2021-02-13 08:18:20 --> 404 Page Not Found: Env/index
ERROR - 2021-02-13 22:15:50 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-02-13 22:15:51 --> 404 Page Not Found: Adstxt/index
