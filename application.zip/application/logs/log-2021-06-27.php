<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-27 21:57:45 --> 404 Page Not Found: Fileupload/server
