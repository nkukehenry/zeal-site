<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-14 15:18:20 --> 404 Page Not Found: Robotstxt/index
