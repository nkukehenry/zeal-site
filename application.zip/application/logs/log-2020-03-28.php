<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-28 01:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-28 08:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-28 11:10:05 --> 404 Page Not Found: Arx/license.txt
ERROR - 2020-03-28 17:29:47 --> 404 Page Not Found: Res/license.txt
ERROR - 2020-03-28 21:29:37 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-03-28 22:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-28 23:44:22 --> 404 Page Not Found: Backup/license.txt
