<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-28 17:03:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-10-28 17:12:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-10-28 23:50:53 --> 404 Page Not Found: A/index
ERROR - 2020-10-28 23:50:53 --> 404 Page Not Found: Public/js
ERROR - 2020-10-28 23:50:57 --> 404 Page Not Found: Util/login.aspx
ERROR - 2020-10-28 23:50:58 --> 404 Page Not Found: Magento_version/index
ERROR - 2020-10-28 23:50:58 --> 404 Page Not Found: Installphp/index
