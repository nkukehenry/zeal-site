<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-16 09:23:06 --> 404 Page Not Found: About_us/index
ERROR - 2022-11-16 09:23:12 --> 404 Page Not Found: About_/index
