<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-21 11:43:29 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-21 11:43:31 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-21 11:43:38 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-21 11:44:13 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-21 11:44:14 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-21 11:44:14 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
