<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-17 00:45:05 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-01-17 00:45:17 --> 404 Page Not Found: Wp_includes/fonts
ERROR - 2021-01-17 11:10:32 --> 404 Page Not Found: Backup/wp_admin
ERROR - 2021-01-17 17:44:41 --> 404 Page Not Found: Env/index
ERROR - 2021-01-17 17:57:03 --> 404 Page Not Found: Configbakphp/index
ERROR - 2021-01-17 21:51:49 --> 404 Page Not Found: Env/index
ERROR - 2021-01-17 22:17:14 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-01-17 23:42:14 --> 404 Page Not Found: Wordpress/wp_admin
