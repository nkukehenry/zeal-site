<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-30 18:23:03 --> 404 Page Not Found: Wp_loginphp/index
