<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-28 08:44:38 --> 404 Page Not Found: App_adstxt/index
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-28 08:44:38 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-02-28 09:35:35 --> 404 Page Not Found: Public/uploads
ERROR - 2022-02-28 09:35:39 --> 404 Page Not Found: Public/uploads
