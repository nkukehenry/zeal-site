<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-31 13:22:25 --> 404 Page Not Found: Backup/wp_admin
ERROR - 2021-05-31 13:56:07 --> 404 Page Not Found: Wp/wp_admin
ERROR - 2021-05-31 20:32:31 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2021-05-31 23:15:08 --> 404 Page Not Found: Vendor/phpunit
