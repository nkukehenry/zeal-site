<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-06 09:07:08 --> 404 Page Not Found: Env/index
ERROR - 2020-12-06 13:19:19 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-12-06 18:55:36 --> 404 Page Not Found: Old/wp_admin
