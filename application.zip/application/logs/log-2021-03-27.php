<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-27 05:12:33 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-03-27 05:12:34 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-03-27 11:11:35 --> 404 Page Not Found: Public/assets
