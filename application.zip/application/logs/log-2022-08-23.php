<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-23 10:07:17 --> 404 Page Not Found: Administrator/index.php
