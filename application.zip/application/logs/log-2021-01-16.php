<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-16 17:14:43 --> 404 Page Not Found: Env/index
ERROR - 2021-01-16 22:47:30 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-01-16 22:48:10 --> 404 Page Not Found: Wp_includes/fonts
ERROR - 2021-01-16 23:31:10 --> 404 Page Not Found: Vendor/phpunit
