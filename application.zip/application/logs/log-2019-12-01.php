<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-01 10:57:21 --> 404 Page Not Found: Public/css
ERROR - 2019-12-01 10:57:57 --> 404 Page Not Found: Public/css
ERROR - 2019-12-01 11:14:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-12-01 11:14:26 --> 404 Page Not Found: Faviconico/index
