<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-22 10:59:35 --> 404 Page Not Found: Apple_touch_icon_120x120_precomposedpng/index
ERROR - 2020-10-22 10:59:36 --> 404 Page Not Found: Apple_touch_icon_120x120png/index
ERROR - 2020-10-22 10:59:36 --> 404 Page Not Found: Apple_touch_icon_precomposedpng/index
ERROR - 2020-10-22 10:59:36 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-10-22 17:04:56 --> 404 Page Not Found: 403shtml/index
