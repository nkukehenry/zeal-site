<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-08 08:23:38 --> 404 Page Not Found: Assets/developer
ERROR - 2021-01-08 08:23:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-01-08 09:50:48 --> 404 Page Not Found: Env/index
ERROR - 2021-01-08 12:16:05 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-01-08 13:57:30 --> 404 Page Not Found: OLD/wp_admin
ERROR - 2021-01-08 14:14:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-01-08 15:58:07 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-01-08 17:40:35 --> 404 Page Not Found: admin/Assets/global
ERROR - 2021-01-08 17:40:35 --> 404 Page Not Found: Public/assets
ERROR - 2021-01-08 17:40:35 --> 404 Page Not Found: admin/Assets/plugins
ERROR - 2021-01-08 17:40:36 --> 404 Page Not Found: Public/assets
