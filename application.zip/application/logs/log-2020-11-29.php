<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-29 10:18:14 --> 404 Page Not Found: Wp_includes/css
ERROR - 2020-11-29 10:59:17 --> 404 Page Not Found: Env/index
