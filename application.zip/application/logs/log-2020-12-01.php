<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-01 13:18:13 --> 404 Page Not Found: Configbakphp/index
ERROR - 2020-12-01 18:18:32 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-12-01 18:18:33 --> 404 Page Not Found: Adstxt/index
