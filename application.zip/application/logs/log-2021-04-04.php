<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-04 01:09:07 --> 404 Page Not Found: _ignition/health_check
ERROR - 2021-04-04 17:14:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-04 17:29:28 --> 404 Page Not Found: Wp_loginphp/index
