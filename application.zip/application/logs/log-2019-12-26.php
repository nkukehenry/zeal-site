<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-26 01:10:29 --> 404 Page Not Found: News/wp_login.php
ERROR - 2019-12-26 03:28:14 --> 404 Page Not Found: Cms/wp_login.php
ERROR - 2019-12-26 13:06:46 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2019-12-26 13:07:45 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2019-12-26 17:08:51 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2019-12-26 17:11:37 --> 404 Page Not Found: Wp_loginphp/index
