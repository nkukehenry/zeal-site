<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-23 12:52:39 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-23 12:52:53 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-23 12:52:59 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-23 12:53:30 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-23 12:53:35 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-23 17:22:59 --> 404 Page Not Found: Well_known/assetlinks.json
