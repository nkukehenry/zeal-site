<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-28 19:08:39 --> 404 Page Not Found: Robotstxt/index
