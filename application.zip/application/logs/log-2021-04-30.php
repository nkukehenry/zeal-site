<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-30 10:30:34 --> 404 Page Not Found: Plugins/jQuery_File_Upload
ERROR - 2021-04-30 11:51:31 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-04-30 11:51:32 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-04-30 12:02:33 --> 404 Page Not Found: admin/View/javascript
