<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-23 14:44:00 --> 404 Page Not Found: Wp_loginphp/index
