<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-05 20:10:58 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-07-05 20:10:58 --> 404 Page Not Found: Wp_loginphp/index
