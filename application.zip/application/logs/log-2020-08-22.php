<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-22 14:56:12 --> 404 Page Not Found: Vendor/phpunit
