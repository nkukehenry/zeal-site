<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-20 08:13:29 --> 404 Page Not Found: Data/admin
