<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-22 05:12:57 --> 404 Page Not Found: Configbakphp/index
ERROR - 2021-05-22 08:58:17 --> 404 Page Not Found: Uploadphp/wp_admin
ERROR - 2021-05-22 11:31:31 --> 404 Page Not Found: Public/assets
