<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-17 20:40:58 --> 404 Page Not Found: Robotstxt/index
