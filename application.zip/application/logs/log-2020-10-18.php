<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-18 08:37:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-10-18 10:33:15 --> 404 Page Not Found: Faviconico/index
