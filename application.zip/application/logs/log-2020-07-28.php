<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-28 11:46:22 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-07-28 17:06:33 --> 404 Page Not Found: Faviconico/index
