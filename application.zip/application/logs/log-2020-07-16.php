<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-16 07:37:23 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-16 07:37:25 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-16 07:37:25 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-16 07:37:58 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-16 07:38:02 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-16 13:57:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-16 18:05:59 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-16 18:06:30 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
