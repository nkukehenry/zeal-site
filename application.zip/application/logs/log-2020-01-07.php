<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-07 07:20:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-01-07 18:57:57 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-01-07 18:57:57 --> 404 Page Not Found: Well_known/autoconfig
ERROR - 2020-01-07 19:00:16 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-01-07 19:01:13 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-01-07 19:02:50 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-01-07 19:37:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-01-07 20:07:04 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-01-07 20:08:10 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-01-07 20:08:13 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
