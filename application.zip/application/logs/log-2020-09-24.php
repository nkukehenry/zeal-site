<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-24 08:58:26 --> 404 Page Not Found: Apple_touch_icon_precomposedpng/index
ERROR - 2020-09-24 08:58:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-09-24 08:58:26 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-09-24 15:02:22 --> 404 Page Not Found: Env/index
ERROR - 2020-09-24 15:02:23 --> 404 Page Not Found: admin/Env/index
ERROR - 2020-09-24 15:02:24 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-09-24 15:02:25 --> 404 Page Not Found: Public/.env
ERROR - 2020-09-24 15:02:29 --> 404 Page Not Found: V1/.env
ERROR - 2020-09-24 15:02:31 --> 404 Page Not Found: App/.env
ERROR - 2020-09-24 15:02:33 --> 404 Page Not Found: Config/.env
ERROR - 2020-09-24 15:02:36 --> 404 Page Not Found: Core/.env
ERROR - 2020-09-24 15:02:37 --> 404 Page Not Found: Apps/.env
ERROR - 2020-09-24 15:02:38 --> 404 Page Not Found: Lib/.env
ERROR - 2020-09-24 15:02:39 --> 404 Page Not Found: Cron/.env
ERROR - 2020-09-24 23:32:47 --> 404 Page Not Found: Laravel/vendor
ERROR - 2020-09-24 23:33:19 --> 404 Page Not Found: Modules/autoupgrade
ERROR - 2020-09-24 23:37:24 --> 404 Page Not Found: Mahara/auth
ERROR - 2020-09-24 23:39:47 --> 404 Page Not Found: Platform/vendor
ERROR - 2020-09-24 23:41:17 --> 404 Page Not Found: Pro/vendor
ERROR - 2020-09-24 23:42:25 --> 404 Page Not Found: App/vendor
ERROR - 2020-09-24 23:42:39 --> 404 Page Not Found: Old/vendor
ERROR - 2020-09-24 23:42:58 --> 404 Page Not Found: 2020/vendor
ERROR - 2020-09-24 23:48:51 --> 404 Page Not Found: Site/vendor
