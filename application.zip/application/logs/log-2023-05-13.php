<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-13 11:31:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-13 11:31:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-13 11:31:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-13 11:33:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-13 11:33:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-13 11:33:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-13 11:35:49 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-13 11:35:49 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-13 11:35:49 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-13 12:29:37 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-13 12:29:37 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-13 12:34:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-13 12:34:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-13 12:34:46 --> 404 Page Not Found: Assets/site
