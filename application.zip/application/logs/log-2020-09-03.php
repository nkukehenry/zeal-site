<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-03 09:39:16 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-09-03 21:38:56 --> 404 Page Not Found: Wp_includes/js
ERROR - 2020-09-03 21:38:57 --> 404 Page Not Found: Administrator/help
ERROR - 2020-09-03 21:38:58 --> 404 Page Not Found: Administrator/language
ERROR - 2020-09-03 21:38:58 --> 404 Page Not Found: Plugins/system
ERROR - 2020-09-03 21:38:59 --> 404 Page Not Found: Administrator/index
ERROR - 2020-09-03 21:39:02 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2020-09-03 21:39:04 --> 404 Page Not Found: admin/View/javascript
ERROR - 2020-09-03 21:39:04 --> 404 Page Not Found: admin/Includes/general.js
ERROR - 2020-09-03 21:39:05 --> 404 Page Not Found: Images/editor
ERROR - 2020-09-03 21:39:05 --> 404 Page Not Found: Js/header_rollup_554.js
ERROR - 2020-09-03 21:39:06 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-09-03 21:39:07 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2020-09-03 21:39:07 --> 404 Page Not Found: 403shtml/index
