<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-11 02:21:02 --> 404 Page Not Found: OLD/wp_admin
ERROR - 2021-04-11 07:15:42 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-04-11 13:22:13 --> 404 Page Not Found: Asset/plugins
ERROR - 2021-04-11 13:22:14 --> 404 Page Not Found: Asset/plugins
ERROR - 2021-04-11 16:39:25 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2021-04-11 16:45:51 --> 404 Page Not Found: Assets/file_uploader
ERROR - 2021-04-11 17:08:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-11 17:08:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-11 17:16:05 --> 404 Page Not Found: Faviconico/index
