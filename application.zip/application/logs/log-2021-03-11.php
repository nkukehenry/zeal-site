<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-11 16:52:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-11 16:56:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-11 16:59:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-11 17:25:15 --> 404 Page Not Found: Faviconico/index
