<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-10 08:13:34 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-06-10 18:32:49 --> 404 Page Not Found: Js/mage
