<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-14 00:26:20 --> 404 Page Not Found: Cms/license.txt
ERROR - 2020-03-14 10:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-14 11:51:55 --> 404 Page Not Found: W/license.txt
ERROR - 2020-03-14 17:32:14 --> 404 Page Not Found: 2/license.txt
ERROR - 2020-03-14 20:31:01 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-03-14 23:08:30 --> 404 Page Not Found: Tmp/license.txt
