<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-03 08:51:44 --> 404 Page Not Found: Wp_admin/index
ERROR - 2021-03-03 17:22:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-03 19:22:30 --> 404 Page Not Found: Wp/wp_admin
