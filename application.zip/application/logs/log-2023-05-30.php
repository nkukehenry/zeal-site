<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-30 05:03:59 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:04:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:04:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:04:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:04:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:04:01 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:13:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:13:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:13:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:13:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:13:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:13:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:13:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:13:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:13:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:13:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:13:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:13:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:19:30 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\view_header.php 47
ERROR - 2023-05-30 05:19:30 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\view_header.php 48
ERROR - 2023-05-30 05:19:30 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\view_header.php 49
ERROR - 2023-05-30 05:19:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:19:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:19:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:19:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:19:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:19:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:20:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:20:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:20:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:20:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:20:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:20:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:20:17 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\view_header.php 47
ERROR - 2023-05-30 05:20:17 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\view_header.php 48
ERROR - 2023-05-30 05:20:17 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\view_header.php 49
ERROR - 2023-05-30 05:20:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:20:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:20:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:20:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:21:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:21:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:21:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:21:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:21:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:23:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:23:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:23:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:23:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:23:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:23:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:23:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:23:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:23:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:23:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:23:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:34:28 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\view_header.php 47
ERROR - 2023-05-30 05:34:28 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\view_header.php 48
ERROR - 2023-05-30 05:34:28 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\view_header.php 49
ERROR - 2023-05-30 05:34:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:34:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:34:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:34:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:34:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:34:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:35:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:35:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:35:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:35:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:35:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:35:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:36:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:36:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:36:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:36:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:36:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:36:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:37:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:37:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:37:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:37:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:37:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:37:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:37:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:37:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:37:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:37:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:37:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:37:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:38:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:38:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:38:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:38:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:38:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:38:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:38:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:38:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:38:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:38:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:38:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:42:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:42:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:42:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:42:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:42:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 05:42:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 12:52:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 12:52:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 12:52:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 12:52:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 12:52:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 12:52:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 12:53:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 12:53:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 12:53:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 12:53:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 12:53:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 12:53:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 12:53:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 12:53:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 12:53:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 12:53:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 13:09:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 13:09:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 13:09:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 13:09:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 13:10:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 13:10:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 13:10:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 13:10:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 14:26:27 --> Severity: error --> Exception: C:\xampp\htdocs\zeal-site\application\models/admin/content_management/Home_content_management_mdl.php exists, but doesn't declare class Home_content_management_mdl C:\xampp\htdocs\zeal-site\system\core\Loader.php 340
ERROR - 2023-05-30 14:27:56 --> Severity: error --> Exception: C:\xampp\htdocs\zeal-site\application\models/admin/content_management/Home_content_management_mdl.php exists, but doesn't declare class Home_content_management_mdl C:\xampp\htdocs\zeal-site\system\core\Loader.php 340
ERROR - 2023-05-30 14:27:57 --> Severity: error --> Exception: C:\xampp\htdocs\zeal-site\application\models/admin/content_management/Home_content_management_mdl.php exists, but doesn't declare class Home_content_management_mdl C:\xampp\htdocs\zeal-site\system\core\Loader.php 340
ERROR - 2023-05-30 14:27:57 --> Severity: error --> Exception: C:\xampp\htdocs\zeal-site\application\models/admin/content_management/Home_content_management_mdl.php exists, but doesn't declare class Home_content_management_mdl C:\xampp\htdocs\zeal-site\system\core\Loader.php 340
ERROR - 2023-05-30 14:27:58 --> Severity: error --> Exception: C:\xampp\htdocs\zeal-site\application\models/admin/content_management/Home_content_management_mdl.php exists, but doesn't declare class Home_content_management_mdl C:\xampp\htdocs\zeal-site\system\core\Loader.php 340
ERROR - 2023-05-30 14:27:58 --> Severity: error --> Exception: C:\xampp\htdocs\zeal-site\application\models/admin/content_management/Home_content_management_mdl.php exists, but doesn't declare class Home_content_management_mdl C:\xampp\htdocs\zeal-site\system\core\Loader.php 340
ERROR - 2023-05-30 14:28:22 --> Severity: Notice --> Undefined property: Home_content_management::$home_content_management_mdl C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 17
ERROR - 2023-05-30 14:28:22 --> Severity: error --> Exception: Call to a member function get_home_content_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 17
ERROR - 2023-05-30 14:29:06 --> Severity: Notice --> Undefined property: Home_content_management::$home_content_management_mdl C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 17
ERROR - 2023-05-30 14:29:06 --> Severity: error --> Exception: Call to a member function get_home_content_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 17
ERROR - 2023-05-30 14:29:13 --> Severity: Notice --> Undefined property: Home_content_management::$home_content_management_mdl C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 17
ERROR - 2023-05-30 14:29:13 --> Severity: error --> Exception: Call to a member function get_home_content_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 17
ERROR - 2023-05-30 14:30:38 --> Severity: Notice --> Undefined property: Home_content_management::$home_content_management_mdl C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 17
ERROR - 2023-05-30 14:30:38 --> Severity: error --> Exception: Call to a member function get_home_content_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 17
ERROR - 2023-05-30 14:31:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 14:31:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 14:31:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 14:31:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 14:31:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 14:31:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 14:37:46 --> Severity: Notice --> Undefined property: Home_content_management::$home_content_management_mdl C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 17
ERROR - 2023-05-30 14:37:46 --> Severity: error --> Exception: Call to a member function get_home_content_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 17
ERROR - 2023-05-30 14:38:06 --> Severity: Notice --> Undefined property: Home_content_management::$home_content_management_mdl C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 17
ERROR - 2023-05-30 14:38:06 --> Severity: error --> Exception: Call to a member function get_home_content_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 17
ERROR - 2023-05-30 14:38:17 --> Severity: Notice --> Undefined property: Home_content_management::$home_content_management_mdl C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 17
ERROR - 2023-05-30 14:38:17 --> Severity: error --> Exception: Call to a member function get_home_content_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 17
ERROR - 2023-05-30 14:38:39 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 68
ERROR - 2023-05-30 14:38:39 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 74
ERROR - 2023-05-30 14:38:39 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 80
ERROR - 2023-05-30 14:38:39 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 96
ERROR - 2023-05-30 14:38:39 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 102
ERROR - 2023-05-30 14:38:39 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 108
ERROR - 2023-05-30 14:38:39 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 114
ERROR - 2023-05-30 14:38:39 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 120
ERROR - 2023-05-30 14:38:39 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 124
ERROR - 2023-05-30 14:38:39 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 130
ERROR - 2023-05-30 14:38:39 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 134
ERROR - 2023-05-30 14:38:39 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 140
ERROR - 2023-05-30 14:38:39 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 144
ERROR - 2023-05-30 14:38:39 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 150
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 154
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 160
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 164
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 171
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 172
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 190
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 214
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 220
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 227
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 228
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 247
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 253
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 260
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 261
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 280
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 286
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 293
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 294
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 312
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 316
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 320
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 326
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 330
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 334
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 340
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 344
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 348
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 354
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 358
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 362
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 369
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 370
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 387
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 410
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 416
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 423
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 424
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 443
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 449
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 456
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 457
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 476
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 500
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 506
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 513
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 514
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 533
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 539
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 546
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 547
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 566
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 572
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 579
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 580
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 598
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 621
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 627
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 633
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 640
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 641
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 662
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 668
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 674
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 680
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 686
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_faq C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 705
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_faq C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 711
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_faq C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 717
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_faq C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 723
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_service C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 742
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_service C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 748
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_service C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 754
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_service C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 760
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_testimonial C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 779
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_testimonial C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 785
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_testimonial C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 791
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_testimonial C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 797
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_news C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 816
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_news C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 822
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_news C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 828
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_news C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 834
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_event C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 853
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_event C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 859
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_event C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 865
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_event C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 871
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 889
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 895
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 901
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 907
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 913
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 919
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 925
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 931
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_search C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 949
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_search C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 955
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_search C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 961
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_search C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 967
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_term C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 987
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_term C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 993
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_term C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 999
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_term C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 1005
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_term C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 1011
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_privacy C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 1029
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_privacy C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 1035
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_privacy C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 1041
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_privacy C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 1047
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_privacy C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 1053
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_team C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 1074
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_team C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 1080
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_team C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 1086
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_team C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 1092
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_portfolio C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 1112
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_portfolio C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 1118
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_portfolio C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 1124
ERROR - 2023-05-30 14:38:40 --> Severity: Notice --> Undefined variable: page_portfolio C:\xampp\htdocs\zeal-site\application\views\admin\content_management\home_content_management.php 1130
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 68
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 74
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 80
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 96
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 102
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 108
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 114
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 120
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 124
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 130
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 134
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 140
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 144
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 150
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 154
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 160
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 164
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 171
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 172
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 190
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 214
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 220
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 227
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 228
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 247
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 253
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 260
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 261
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 280
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 286
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 293
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 294
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 312
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 316
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 320
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 326
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 330
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 334
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 340
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 344
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 348
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 354
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 358
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 362
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 369
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 370
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 387
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 410
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 416
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 423
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 424
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 443
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 449
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 456
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 457
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 476
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 500
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 506
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 513
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 514
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 533
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 539
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 546
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 547
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 566
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 572
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 579
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 580
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 598
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 621
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 627
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 633
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 640
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 641
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 662
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 668
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 674
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 680
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 686
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_faq C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 705
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_faq C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 711
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_faq C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 717
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_faq C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 723
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_service C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 742
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_service C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 748
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_service C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 754
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_service C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 760
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_testimonial C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 779
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_testimonial C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 785
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_testimonial C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 791
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_testimonial C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 797
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_news C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 816
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_news C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 822
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_news C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 828
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_news C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 834
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_event C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 853
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_event C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 859
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_event C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 865
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_event C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 871
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 889
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 895
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 901
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 907
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 913
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 919
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 925
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 931
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_search C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 949
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_search C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 955
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_search C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 961
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_search C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 967
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_term C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 987
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_term C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 993
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_term C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 999
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_term C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 1005
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_term C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 1011
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_privacy C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 1029
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_privacy C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 1035
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_privacy C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 1041
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_privacy C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 1047
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_privacy C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 1053
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_team C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 1074
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_team C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 1080
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_team C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 1086
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_team C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 1092
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_portfolio C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 1112
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_portfolio C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 1118
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_portfolio C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 1124
ERROR - 2023-05-30 14:40:38 --> Severity: Notice --> Undefined variable: page_portfolio C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 1130
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 68
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 74
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 80
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 96
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 102
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 108
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 114
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 120
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 124
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 130
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 134
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 140
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 144
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 150
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 154
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 160
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 164
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 171
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 172
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 190
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 214
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 220
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 227
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 228
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 247
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 253
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 260
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 261
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 280
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 286
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 293
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 294
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 312
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 316
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 320
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 326
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 330
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 334
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 340
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 344
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 348
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 354
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 358
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 362
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 369
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 370
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 387
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 410
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 416
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 423
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 424
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 443
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 449
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 456
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 457
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 476
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 500
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 506
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 513
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 514
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 533
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 539
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 546
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 547
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 566
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 572
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 579
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 580
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 598
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 621
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 627
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 633
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 640
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 641
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 662
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 668
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 674
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 680
ERROR - 2023-05-30 14:44:10 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 686
ERROR - 2023-05-30 14:50:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 68
ERROR - 2023-05-30 14:50:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 74
ERROR - 2023-05-30 14:50:40 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 80
ERROR - 2023-05-30 14:53:16 --> Severity: Notice --> Undefined variable: title2 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 44
ERROR - 2023-05-30 15:33:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 15:33:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 15:33:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 15:33:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 15:33:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 15:33:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 15:34:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 15:34:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 15:34:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 15:34:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 15:34:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 15:34:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 15:38:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 15:38:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 15:38:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 15:38:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:00:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:00:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:00:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:00:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:00:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:00:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:14:02 --> Severity: Notice --> Undefined property: Home_content_management::$home_content_management_mdl C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 18
ERROR - 2023-05-30 16:14:02 --> Severity: error --> Exception: Call to a member function get_home_content_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 18
ERROR - 2023-05-30 16:14:44 --> Severity: Notice --> Undefined property: Home_content_management::$home_content_management_mdl C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 18
ERROR - 2023-05-30 16:14:44 --> Severity: error --> Exception: Call to a member function get_home_content_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 18
ERROR - 2023-05-30 16:14:45 --> Severity: Notice --> Undefined property: Home_content_management::$home_content_management_mdl C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 18
ERROR - 2023-05-30 16:14:45 --> Severity: error --> Exception: Call to a member function get_home_content_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 18
ERROR - 2023-05-30 16:14:46 --> Severity: Notice --> Undefined property: Home_content_management::$home_content_management_mdl C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 18
ERROR - 2023-05-30 16:14:46 --> Severity: error --> Exception: Call to a member function get_home_content_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 18
ERROR - 2023-05-30 16:14:46 --> Severity: Notice --> Undefined property: Home_content_management::$home_content_management_mdl C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 18
ERROR - 2023-05-30 16:14:46 --> Severity: error --> Exception: Call to a member function get_home_content_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 18
ERROR - 2023-05-30 16:14:46 --> Severity: Notice --> Undefined property: Home_content_management::$home_content_management_mdl C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 18
ERROR - 2023-05-30 16:14:46 --> Severity: error --> Exception: Call to a member function get_home_content_data() on null C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 18
ERROR - 2023-05-30 16:16:33 --> Severity: Notice --> Undefined index: top_header C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 71
ERROR - 2023-05-30 16:18:36 --> Severity: Notice --> Undefined index: top_header C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 71
ERROR - 2023-05-30 16:20:46 --> Severity: Notice --> Undefined index: top_header  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 71
ERROR - 2023-05-30 16:20:59 --> Severity: Notice --> Undefined index: top_header C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 71
ERROR - 2023-05-30 16:22:14 --> Severity: Notice --> Undefined index: second_header C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 71
ERROR - 2023-05-30 16:23:32 --> Query error: Table 'zealforex.tbl_home_currency_section_header' doesn't exist - Invalid query: SELECT *
FROM `tbl_home_currency_section_header`
ERROR - 2023-05-30 16:23:43 --> Severity: Notice --> Undefined index: second_header C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 71
ERROR - 2023-05-30 16:23:59 --> Severity: Notice --> Undefined index: top_header C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 71
ERROR - 2023-05-30 16:26:00 --> Severity: Notice --> Undefined index: top_header C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 71
ERROR - 2023-05-30 16:29:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:29:59 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:29:59 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:29:59 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:29:59 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:30:00 --> Severity: Notice --> Undefined index: top_header C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 71
ERROR - 2023-05-30 16:30:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:31:35 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 9
ERROR - 2023-05-30 16:31:35 --> Severity: Notice --> Undefined variable: section_title C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 65
ERROR - 2023-05-30 16:31:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 71
ERROR - 2023-05-30 16:31:35 --> Severity: Notice --> Undefined variable: section_title C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 144
ERROR - 2023-05-30 16:32:12 --> Severity: Notice --> Undefined variable: mdata C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 71
ERROR - 2023-05-30 16:32:23 --> Severity: Notice --> Undefined variable: mdata C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 71
ERROR - 2023-05-30 16:32:53 --> Severity: Notice --> Undefined index: top_header C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 71
ERROR - 2023-05-30 16:40:22 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\zeal-site\application\controllers\admin\Page.php 44
ERROR - 2023-05-30 16:40:22 --> Severity: Notice --> Undefined index: meta_keyword C:\xampp\htdocs\zeal-site\application\controllers\admin\Page.php 45
ERROR - 2023-05-30 16:40:22 --> Severity: Notice --> Undefined index: meta_description C:\xampp\htdocs\zeal-site\application\controllers\admin\Page.php 46
ERROR - 2023-05-30 16:41:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:41:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:41:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:41:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:41:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:41:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:41:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:41:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:41:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:41:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:41:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:41:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:41:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:41:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:41:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:41:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:41:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:41:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 16:45:19 --> 404 Page Not Found: admin/Home_content_management/update_data
ERROR - 2023-05-30 17:03:18 --> Severity: error --> Exception: Call to undefined method Home_content_management_mdl::get_home_content() C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 18
ERROR - 2023-05-30 17:10:24 --> Severity: Compile Error --> Cannot redeclare Home_content_management_mdl::get_home_content() C:\xampp\htdocs\zeal-site\application\models\admin\content_management\Home_content_management_mdl.php 15
ERROR - 2023-05-30 17:23:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 17:23:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 17:23:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 17:23:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 17:50:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 17:54:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 17:54:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 17:54:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 17:54:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 17:54:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 17:55:29 --> Severity: Notice --> Undefined variable: section_title C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 65
ERROR - 2023-05-30 17:55:29 --> Severity: Notice --> Undefined variable: section_title C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 144
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 150
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 155
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 163
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 168
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 176
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 181
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 189
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 194
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 202
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 207
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 215
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 220
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 228
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 233
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 241
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 246
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 254
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 259
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 267
ERROR - 2023-05-30 18:37:06 --> Severity: Notice --> Undefined index: contact_us_button_text C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 272
ERROR - 2023-05-30 18:44:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 18:45:40 --> 404 Page Not Found: Zeal_site/assets
ERROR - 2023-05-30 19:17:05 --> Severity: error --> Exception: Call to undefined method Home_content_management_mdl::update_home_content() C:\xampp\htdocs\zeal-site\application\controllers\admin\Home_content_management.php 28
ERROR - 2023-05-30 20:11:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Employees_mdl C:\xampp\htdocs\zeal-site\system\core\Loader.php 348
ERROR - 2023-05-30 20:43:11 --> Severity: error --> Exception: Too few arguments to function Model_home::get_currency_data(), 1 passed in C:\xampp\htdocs\zeal-site\application\controllers\Home.php on line 38 and exactly 3 expected C:\xampp\htdocs\zeal-site\application\models\Model_home.php 74
ERROR - 2023-05-30 20:49:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:49:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:49:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:49:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:50:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:50:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:50:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:50:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:51:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:51:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:51:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:51:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:51:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:51:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:56:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:56:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:56:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:56:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:56:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:56:59 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:57:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:57:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:57:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:57:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:57:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:57:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:57:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:57:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:57:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:58:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:58:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:58:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:58:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:58:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:58:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:59:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:59:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:59:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:59:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:59:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 20:59:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 21:05:02 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-30 21:06:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 21:06:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 21:06:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 21:06:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 21:06:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 21:06:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 21:08:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 21:08:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 21:08:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 21:08:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 21:08:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 21:08:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 21:08:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 21:08:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 21:08:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 21:08:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 23:44:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 23:44:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 23:44:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 23:44:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 23:44:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 23:44:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-30 23:50:05 --> 404 Page Not Found: Assets/site
