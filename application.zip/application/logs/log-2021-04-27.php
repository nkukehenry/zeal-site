<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-27 21:56:20 --> 404 Page Not Found: Assets/jQuery_File_Upload
