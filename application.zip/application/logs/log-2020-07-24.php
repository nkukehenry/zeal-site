<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-24 01:46:17 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-07-24 21:45:37 --> 404 Page Not Found: Well_known/assetlinks.json
