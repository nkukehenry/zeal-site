<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-19 00:10:44 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-06-19 00:10:49 --> 404 Page Not Found: Wp/index
ERROR - 2021-06-19 00:10:52 --> 404 Page Not Found: Blog/index
ERROR - 2021-06-19 00:11:10 --> 404 Page Not Found: New/index
ERROR - 2021-06-19 00:11:14 --> 404 Page Not Found: Old/index
ERROR - 2021-06-19 00:11:20 --> 404 Page Not Found: Newsite/index
ERROR - 2021-06-19 00:11:23 --> 404 Page Not Found: Test/index
ERROR - 2021-06-19 00:11:30 --> 404 Page Not Found: Main/index
ERROR - 2021-06-19 08:03:04 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2021-06-19 08:03:17 --> 404 Page Not Found: Wp/wp_admin
ERROR - 2021-06-19 08:03:32 --> 404 Page Not Found: New/wp_admin
ERROR - 2021-06-19 08:03:46 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-06-19 08:04:00 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-06-19 08:04:15 --> 404 Page Not Found: Test/wp_admin
ERROR - 2021-06-19 08:04:29 --> 404 Page Not Found: Blog/wp_admin
ERROR - 2021-06-19 08:04:43 --> 404 Page Not Found: Cms/wp_admin
ERROR - 2021-06-19 08:05:37 --> 404 Page Not Found: Web/wp_admin
ERROR - 2021-06-19 08:05:51 --> 404 Page Not Found: Backup/wp_admin
ERROR - 2021-06-19 08:06:06 --> 404 Page Not Found: Site/wp_admin
ERROR - 2021-06-19 08:06:21 --> 404 Page Not Found: Oldsite/wp_admin
ERROR - 2021-06-19 09:35:04 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-06-19 12:50:07 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-06-19 15:27:07 --> 404 Page Not Found: Wordpress/wp_admin
