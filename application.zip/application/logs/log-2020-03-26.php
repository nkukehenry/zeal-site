<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-26 02:20:55 --> 404 Page Not Found: Web/license.txt
ERROR - 2020-03-26 03:31:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-26 05:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-26 07:00:02 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-03-26 07:26:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-03-26 08:42:51 --> 404 Page Not Found: Www/license.txt
ERROR - 2020-03-26 12:40:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-26 12:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-26 12:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-26 15:00:10 --> 404 Page Not Found: Main/license.txt
ERROR - 2020-03-26 18:07:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-26 21:38:27 --> 404 Page Not Found: Reserv/license.txt
