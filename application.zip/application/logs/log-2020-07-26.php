<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-26 04:34:24 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-07-26 20:53:36 --> 404 Page Not Found: Well_known/assetlinks.json
