<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-11 06:10:59 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-08-11 16:44:04 --> 404 Page Not Found: Profile/register
ERROR - 2020-08-11 16:44:14 --> 404 Page Not Found: Wp/profile
ERROR - 2020-08-11 16:44:22 --> 404 Page Not Found: Wordpress/profile
ERROR - 2020-08-11 16:44:30 --> 404 Page Not Found: Blog/profile
ERROR - 2020-08-11 16:44:36 --> 404 Page Not Found: New/profile
ERROR - 2020-08-11 16:44:47 --> 404 Page Not Found: Old/profile
ERROR - 2020-08-11 16:45:00 --> 404 Page Not Found: Demo/profile
ERROR - 2020-08-11 17:44:05 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-08-11 20:23:52 --> 404 Page Not Found: Wp_admin/install.php
