<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-05 09:05:46 --> 404 Page Not Found: Google06ee0fde9864ffdfhtml/index
ERROR - 2020-09-05 14:22:12 --> 404 Page Not Found: Wp_content/plugins
