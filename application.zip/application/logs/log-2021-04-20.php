<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-20 06:54:52 --> 404 Page Not Found: Public/assets
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-20 06:54:52 --> 404 Page Not Found: Assets/global
ERROR - 2021-04-20 06:54:52 --> 404 Page Not Found: Assets/jQuery_File_Upload
ERROR - 2021-04-20 06:54:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 06:54:53 --> 404 Page Not Found: admin/JQuery_File_Upload/server
ERROR - 2021-04-20 06:54:53 --> 404 Page Not Found: admin/Assets/admin
ERROR - 2021-04-20 13:47:31 --> 404 Page Not Found: admin/Assets/global
ERROR - 2021-04-20 13:47:31 --> 404 Page Not Found: admin/Assets/plugins
ERROR - 2021-04-20 13:47:31 --> 404 Page Not Found: Public/assets
ERROR - 2021-04-20 13:47:31 --> 404 Page Not Found: Public/assets
ERROR - 2021-04-20 13:47:31 --> 404 Page Not Found: Public/assets
ERROR - 2021-04-20 17:13:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-20 17:13:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-20 21:01:26 --> 404 Page Not Found: admin/Assets/jQuery_File_Upload
ERROR - 2021-04-20 21:01:26 --> 404 Page Not Found: Plugins/jQuery_File_Upload
ERROR - 2021-04-20 21:01:26 --> 404 Page Not Found: Public/admin
ERROR - 2021-04-20 21:01:26 --> 404 Page Not Found: Assets/admin
ERROR - 2021-04-20 21:01:26 --> 404 Page Not Found: Assets/backend
ERROR - 2021-04-20 21:01:26 --> 404 Page Not Found: Theme/assets
