<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-15 21:22:20 --> 404 Page Not Found: Faviconico/index
