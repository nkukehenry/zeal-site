<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-09 15:44:23 --> 404 Page Not Found: OLD/wp_admin
