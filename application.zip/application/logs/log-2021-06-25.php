<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-25 00:01:24 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2021-06-25 00:01:25 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-06-25 00:01:26 --> 404 Page Not Found: New/wp_admin
ERROR - 2021-06-25 00:01:27 --> 404 Page Not Found: Wp/wp_admin
ERROR - 2021-06-25 00:01:27 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-06-25 00:01:28 --> 404 Page Not Found: Test/wp_admin
ERROR - 2021-06-25 00:01:29 --> 404 Page Not Found: Blog/wp_admin
ERROR - 2021-06-25 00:01:30 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-06-25 00:01:31 --> 404 Page Not Found: Wp_admin/setup_config.php
ERROR - 2021-06-25 00:01:32 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-06-25 00:01:32 --> 404 Page Not Found: New/wp_admin
ERROR - 2021-06-25 00:01:33 --> 404 Page Not Found: Wp/wp_admin
ERROR - 2021-06-25 00:01:34 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-06-25 00:01:35 --> 404 Page Not Found: Test/wp_admin
ERROR - 2021-06-25 00:01:36 --> 404 Page Not Found: Blog/wp_admin
ERROR - 2021-06-25 00:01:36 --> 404 Page Not Found: Wp_admin/admin_ajax.php
ERROR - 2021-06-25 00:01:37 --> 404 Page Not Found: Wp_admin/index
