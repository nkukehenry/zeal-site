<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-31 00:21:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 00:21:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 00:21:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 00:21:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 00:21:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 00:21:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 00:22:26 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 00:31:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 00:31:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 00:31:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 00:31:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 00:31:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 00:31:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 01:07:36 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 01:11:10 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 66
ERROR - 2023-05-31 01:11:28 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 148
ERROR - 2023-05-31 01:11:40 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 304
ERROR - 2023-05-31 01:11:41 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 304
ERROR - 2023-05-31 01:12:04 --> Severity: Notice --> Undefined index: home_we_are_flexible_top_header C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 304
ERROR - 2023-05-31 01:12:04 --> Severity: Notice --> Undefined index: home_we_are_flexible_top_header C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 309
ERROR - 2023-05-31 01:12:04 --> Severity: Notice --> Undefined index: home_we_are_flexible_second_header C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 317
ERROR - 2023-05-31 01:12:04 --> Severity: Notice --> Undefined index: home_we_are_flexible_second_header C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 322
ERROR - 2023-05-31 01:15:09 --> Severity: Notice --> Undefined variable: home_we_are_flexible_section C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 304
ERROR - 2023-05-31 01:15:09 --> Severity: Notice --> Undefined variable: home_we_are_flexible_section C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 317
ERROR - 2023-05-31 01:15:56 --> Severity: Notice --> Undefined variable: home_we_are_flexible_section C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 304
ERROR - 2023-05-31 01:15:56 --> Severity: Notice --> Undefined variable: home_we_are_flexible_section C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 317
ERROR - 2023-05-31 01:19:24 --> 404 Page Not Found: Send_moneyhtml/index
ERROR - 2023-05-31 01:19:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 01:19:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 01:19:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 01:32:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 01:32:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 01:32:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 01:32:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 01:36:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 01:36:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 01:36:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 01:36:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 01:36:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 01:36:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 391
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 392
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 393
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 394
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 395
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 391
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 392
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 393
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 394
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 395
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 391
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 392
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 393
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 394
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 395
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 391
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 392
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 393
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 394
ERROR - 2023-05-31 01:42:45 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 395
ERROR - 2023-05-31 07:32:59 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 07:33:33 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 07:33:54 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 07:34:18 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 07:41:24 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 08:15:08 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 08:15:58 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 08:17:26 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 08:53:17 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 09:18:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 09:20:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\zeal-site\application\models\admin\content_management\Home_content_management_mdl.php 52
ERROR - 2023-05-31 09:21:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\zeal-site\application\models\admin\content_management\Home_content_management_mdl.php 52
ERROR - 2023-05-31 09:32:33 --> 404 Page Not Found: admin/Home_content_management/delete_home_content
ERROR - 2023-05-31 09:32:45 --> 404 Page Not Found: admin/Home_content_management/delete_home_content
ERROR - 2023-05-31 09:33:04 --> 404 Page Not Found: admin/Home_content_management/delete_home_content
ERROR - 2023-05-31 10:12:29 --> Query error: Column 'content_button_url' cannot be null - Invalid query: INSERT INTO `tbl_home_we_are_flexible_content` (`content_header`, `content_description`, `content_icon`, `content_button_text`, `content_button_url`) VALUES ('kkkkkk', 'kkkkkkkkkkkkkkkkkkkkkk', 'kkkkkkkkkkkkkkk', 'kkkkkkkkkkkkkkkkkkkk', NULL)
ERROR - 2023-05-31 10:14:40 --> Query error: Column 'content_button_url' cannot be null - Invalid query: INSERT INTO `tbl_home_we_are_flexible_content` (`content_header`, `content_description`, `content_icon`, `content_button_text`, `content_button_url`) VALUES ('', '', '', '', NULL)
ERROR - 2023-05-31 10:19:16 --> Query error: Column 'content_button_url' cannot be null - Invalid query: INSERT INTO `tbl_home_we_are_flexible_content` (`content_header`, `content_description`, `content_icon`, `content_button_text`, `content_button_url`) VALUES ('llllllll', 'loooooooooooo', 'hhhhhhhhhhhhhhh', '88888888888888', NULL)
ERROR - 2023-05-31 10:37:39 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\zeal-site\application\views\view_home.php 15
ERROR - 2023-05-31 10:38:54 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\zeal-site\application\views\view_home.php 158
ERROR - 2023-05-31 10:39:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:39:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:39:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:39:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:39:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:39:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:39:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:39:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:39:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:39:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:39:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:39:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:42:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:42:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:42:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:42:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:42:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:42:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:42:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:42:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:42:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:42:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:42:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:42:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:42:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:42:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:42:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:42:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:42:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:46:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:46:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:46:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:46:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:46:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:46:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:49:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:49:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:49:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:49:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:52:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:52:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:52:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:52:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:52:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:52:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:52:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:52:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:52:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:52:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:52:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:53:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:53:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:53:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:53:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:53:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:54:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:54:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:54:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:54:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:54:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:55:31 --> 404 Page Not Found: Send_moneyhtml/index
ERROR - 2023-05-31 10:55:36 --> 404 Page Not Found: Send_moneyhtml/index
ERROR - 2023-05-31 10:55:41 --> 404 Page Not Found: Send_moneyhtml/index
ERROR - 2023-05-31 10:55:51 --> 404 Page Not Found: Send_moneyhtml/index
ERROR - 2023-05-31 10:55:59 --> 404 Page Not Found: Send_moneyhtml/index
ERROR - 2023-05-31 10:56:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:56:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:56:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:56:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:56:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:56:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:56:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:56:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:56:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:56:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:56:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:56:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:56:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:56:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:56:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:56:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:56:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:57:00 --> 404 Page Not Found: Alertshtml/index
ERROR - 2023-05-31 10:57:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:57:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:57:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:57:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:57:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:59:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:59:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:59:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 10:59:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 11:00:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 11:00:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 11:00:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 11:00:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 11:00:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:43:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:43:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:43:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:43:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:47:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:47:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:47:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:47:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:47:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:47:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:47:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:47:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:47:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:47:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:47:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:48:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:48:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:48:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:48:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:48:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:48:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:49:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:49:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:49:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:49:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:49:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:50:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:50:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:50:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:50:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:50:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:50:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:51:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:51:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:51:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:51:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:51:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:51:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:51:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:51:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:51:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:51:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 14:51:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 15:16:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 15:16:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 15:16:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 15:16:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 15:16:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 15:16:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 15:18:51 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:18:51 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:18:51 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:21:12 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:21:12 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:21:12 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:21:14 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:21:14 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:21:14 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:21:16 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:21:16 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:21:16 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:21:17 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:21:17 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:21:17 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:21:19 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:21:19 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:21:19 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:23:25 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:23:25 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:23:25 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:40:59 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:40:59 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:40:59 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:40:59 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:40:59 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:40:59 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:40:59 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:40:59 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:40:59 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:40:59 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:40:59 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:01 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:01 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:01 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:01 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:01 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:01 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:01 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:01 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:01 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:01 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:01 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:02 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:02 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:02 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:02 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:02 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:02 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:02 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:02 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:02 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:02 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:41:02 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:42:41 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:42:41 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:42:41 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:43:50 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:43:50 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:43:50 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:44:46 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:44:46 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:44:46 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:45:45 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:45:45 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:45:45 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:46:41 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:46:41 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:46:41 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:47:52 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:47:52 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:47:52 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:49:35 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:49:35 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:49:35 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:50:14 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:50:14 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:50:14 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:50:29 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:50:29 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:50:29 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:50:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 15:50:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 15:50:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 15:50:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 15:51:01 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:51:01 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:51:01 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:51:05 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:51:05 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:51:05 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:51:09 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:51:09 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:51:09 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:53:45 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:53:45 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:53:45 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:54:10 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:54:10 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:54:10 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:54:19 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:54:19 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:54:19 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:54:20 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 15:57:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 15:57:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 15:57:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 15:57:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 15:57:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 15:57:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:51:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:51:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:51:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:51:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:51:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:55:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:57:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:57:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:57:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:57:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:57:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:57:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:58:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:58:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:58:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:58:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:58:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:58:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:58:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:58:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:58:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:58:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:58:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:58:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:58:49 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:58:49 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:58:49 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:58:49 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:59:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:59:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:59:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:59:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:59:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:59:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:59:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:59:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:59:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 16:59:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 17:14:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:21:42 --> Severity: Notice --> Undefined index: content_header C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 520
ERROR - 2023-05-31 18:21:42 --> Severity: Notice --> Undefined index: content_description C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 527
ERROR - 2023-05-31 18:21:42 --> Severity: Notice --> Undefined index: content_icon C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 534
ERROR - 2023-05-31 18:21:42 --> Severity: Notice --> Undefined index: content_header C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 520
ERROR - 2023-05-31 18:21:42 --> Severity: Notice --> Undefined index: content_description C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 527
ERROR - 2023-05-31 18:21:42 --> Severity: Notice --> Undefined index: content_icon C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 534
ERROR - 2023-05-31 18:21:42 --> Severity: Notice --> Undefined index: content_header C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 520
ERROR - 2023-05-31 18:21:42 --> Severity: Notice --> Undefined index: content_description C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 527
ERROR - 2023-05-31 18:21:42 --> Severity: Notice --> Undefined index: content_icon C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 534
ERROR - 2023-05-31 18:24:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\zeal-site\application\models\admin\content_management\Home_content_management_mdl.php 70
ERROR - 2023-05-31 18:38:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\view_home.php 237
ERROR - 2023-05-31 18:38:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\view_home.php 238
ERROR - 2023-05-31 18:38:35 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\zeal-site\application\views\view_home.php 239
ERROR - 2023-05-31 18:38:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:38:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:38:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:38:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:38:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:39:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:39:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:39:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:39:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:39:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:39:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:40:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:40:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:40:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:40:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:40:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:43:12 --> Severity: Notice --> Undefined index: service_header C:\xampp\htdocs\zeal-site\application\views\view_home.php 249
ERROR - 2023-05-31 18:43:12 --> Severity: Notice --> Undefined index: service_description C:\xampp\htdocs\zeal-site\application\views\view_home.php 250
ERROR - 2023-05-31 18:43:12 --> Severity: Notice --> Undefined index: service_header C:\xampp\htdocs\zeal-site\application\views\view_home.php 249
ERROR - 2023-05-31 18:43:12 --> Severity: Notice --> Undefined index: service_description C:\xampp\htdocs\zeal-site\application\views\view_home.php 250
ERROR - 2023-05-31 18:43:12 --> Severity: Notice --> Undefined index: service_header C:\xampp\htdocs\zeal-site\application\views\view_home.php 249
ERROR - 2023-05-31 18:43:12 --> Severity: Notice --> Undefined index: service_description C:\xampp\htdocs\zeal-site\application\views\view_home.php 250
ERROR - 2023-05-31 18:43:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:43:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:43:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:43:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:43:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:43:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:43:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:43:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:43:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:44:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:44:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:44:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:44:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:44:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:44:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:44:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:44:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:44:51 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:55:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:55:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:55:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:55:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:55:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:55:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:57:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:57:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:57:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:57:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:57:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 18:57:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 19:19:59 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 19:29:19 --> Severity: Notice --> Undefined index: image_1 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 564
ERROR - 2023-05-31 19:29:19 --> Severity: Notice --> Undefined index: image_2 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 565
ERROR - 2023-05-31 19:29:19 --> Severity: Notice --> Undefined index: image_3 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 566
ERROR - 2023-05-31 19:29:19 --> Severity: Notice --> Undefined index: shape_1 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 567
ERROR - 2023-05-31 19:29:19 --> Severity: Notice --> Undefined index: shape_2 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 568
ERROR - 2023-05-31 19:31:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 19:31:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 19:31:14 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 19:42:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 19:42:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 19:43:11 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 19:43:11 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:46:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:46:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:46:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:47:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:47:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:47:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:48:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:48:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:48:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:49:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:49:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:49:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:49:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:49:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:49:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:49:56 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 20:52:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:52:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:52:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:52:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:52:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:52:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:53:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:53:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:53:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:53:33 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 20:53:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:53:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:53:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:54:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:54:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:54:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:55:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:55:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:55:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:55:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:55:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:55:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:55:58 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 20:59:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:59:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 20:59:18 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 21:00:16 --> Severity: Notice --> Undefined index: choose_image_1 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 639
ERROR - 2023-05-31 21:00:16 --> Severity: Notice --> Undefined index: choose_image_2 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 640
ERROR - 2023-05-31 21:00:16 --> Severity: Notice --> Undefined index: choose_image_3 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 641
ERROR - 2023-05-31 21:00:17 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-31 21:01:12 --> Severity: Notice --> Undefined index: image_2 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 566
ERROR - 2023-05-31 21:01:12 --> Severity: Notice --> Undefined index: image_2 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 589
ERROR - 2023-05-31 21:01:12 --> Severity: Notice --> Undefined index: image_3 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 612
ERROR - 2023-05-31 21:01:57 --> Severity: Notice --> Undefined index: image_2 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 566
ERROR - 2023-05-31 21:01:57 --> Severity: Notice --> Undefined index: image_2 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 589
ERROR - 2023-05-31 21:01:57 --> Severity: Notice --> Undefined index: image_3 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 612
ERROR - 2023-05-31 21:02:18 --> Severity: Notice --> Undefined index: image_2 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 566
ERROR - 2023-05-31 21:02:18 --> Severity: Notice --> Undefined index: image_2 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 589
ERROR - 2023-05-31 21:02:18 --> Severity: Notice --> Undefined index: image_3 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 612
ERROR - 2023-05-31 21:02:40 --> Severity: Notice --> Undefined index: image_2 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 566
ERROR - 2023-05-31 21:02:40 --> Severity: Notice --> Undefined index: image_2 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 589
ERROR - 2023-05-31 21:02:40 --> Severity: Notice --> Undefined index: image_3 C:\xampp\htdocs\zeal-site\application\views\admin\content_management\view_home_content_management.php 612
ERROR - 2023-05-31 21:05:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:05:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:05:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:16:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\zeal-site\application\models\admin\content_management\Home_content_management_mdl.php 94
ERROR - 2023-05-31 21:17:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\zeal-site\application\models\admin\content_management\Home_content_management_mdl.php 94
ERROR - 2023-05-31 21:19:00 --> Query error: Unknown column 'image_1' in 'field list' - Invalid query: UPDATE `tbl_home_why_choose_us_images_and_shapes` SET `image_1` = 'hero-img-6.jpg'
WHERE `id` = '1'
ERROR - 2023-05-31 21:20:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:21:46 --> Severity: Notice --> Undefined index: image_1 C:\xampp\htdocs\zeal-site\application\views\view_home.php 263
ERROR - 2023-05-31 21:21:46 --> Severity: Notice --> Undefined index: image_2 C:\xampp\htdocs\zeal-site\application\views\view_home.php 266
ERROR - 2023-05-31 21:21:46 --> Severity: Notice --> Undefined index: image_3 C:\xampp\htdocs\zeal-site\application\views\view_home.php 272
ERROR - 2023-05-31 21:21:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:21:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:21:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:21:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:21:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:21:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:21:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:22:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:22:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:22:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:22:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:22:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:22:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:23:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:25:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:25:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:25:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:25:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:25:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:25:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:25:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:28:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:37:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:37:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:37:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:37:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:41:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:42:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:42:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:42:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:42:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:42:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:42:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:44:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:44:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:44:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:44:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:44:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:44:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:44:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:44:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:44:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:44:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:44:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:45:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:45:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:45:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:45:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:45:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:46:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:46:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:46:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:46:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:46:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:47:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:47:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:47:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:47:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:47:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:47:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:47:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:47:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:47:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:47:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:49:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:49:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:49:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:49:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:49:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-31 21:49:24 --> 404 Page Not Found: Assets/site
