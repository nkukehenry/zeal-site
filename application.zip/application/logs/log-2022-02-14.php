<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-14 22:33:11 --> 404 Page Not Found: Infophp/index
ERROR - 2022-02-14 22:33:13 --> 404 Page Not Found: Phpinfophp/index
ERROR - 2022-02-14 22:33:15 --> 404 Page Not Found: Info/index
