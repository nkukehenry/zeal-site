<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-09 05:45:34 --> 404 Page Not Found: Public/uploads
ERROR - 2022-02-09 05:45:37 --> 404 Page Not Found: Public/uploads
ERROR - 2022-02-09 05:45:39 --> 404 Page Not Found: Public/uploads
ERROR - 2022-02-09 05:45:42 --> 404 Page Not Found: Public/uploads
ERROR - 2022-02-09 05:59:45 --> 404 Page Not Found: Public/uploads
ERROR - 2022-02-09 05:59:47 --> 404 Page Not Found: Public/uploads
ERROR - 2022-02-09 05:59:48 --> 404 Page Not Found: Public/uploads
ERROR - 2022-02-09 05:59:50 --> 404 Page Not Found: Public/uploads
