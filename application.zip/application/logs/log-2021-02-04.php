<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-04 04:00:17 --> 404 Page Not Found: 403shtml/index
