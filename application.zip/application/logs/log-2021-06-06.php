<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-06 09:04:14 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-06-06 09:23:44 --> 404 Page Not Found: Administrator/index.php
ERROR - 2021-06-06 09:32:02 --> 404 Page Not Found: Administrator/components
ERROR - 2021-06-06 21:15:10 --> 404 Page Not Found: Shlphp/index
ERROR - 2021-06-06 21:15:11 --> 404 Page Not Found: admin/Dumperphp/index
ERROR - 2021-06-06 21:15:12 --> 404 Page Not Found: Backup/dumper.php
ERROR - 2021-06-06 21:15:13 --> 404 Page Not Found: Db/dumper.php
ERROR - 2021-06-06 21:15:14 --> 404 Page Not Found: Dump/dumper.php
ERROR - 2021-06-06 21:15:15 --> 404 Page Not Found: Dumperphp/index
ERROR - 2021-06-06 21:15:17 --> 404 Page Not Found: Dumper/dumper.php
ERROR - 2021-06-06 21:15:18 --> 404 Page Not Found: Sxd/index.php
ERROR - 2021-06-06 21:15:19 --> 404 Page Not Found: Sypex/dumper.php
