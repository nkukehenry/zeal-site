<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-10 12:55:50 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2020-12-10 12:55:50 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2020-12-10 12:55:50 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2020-12-10 12:55:50 --> 404 Page Not Found: Web/wp_includes
ERROR - 2020-12-10 12:55:51 --> 404 Page Not Found: Wordpress/wp_includes
ERROR - 2020-12-10 12:55:51 --> 404 Page Not Found: Website/wp_includes
ERROR - 2020-12-10 12:55:51 --> 404 Page Not Found: Wp/wp_includes
ERROR - 2020-12-10 12:55:51 --> 404 Page Not Found: News/wp_includes
ERROR - 2020-12-10 12:55:51 --> 404 Page Not Found: 2020/wp_includes
ERROR - 2020-12-10 12:55:51 --> 404 Page Not Found: 2019/wp_includes
ERROR - 2020-12-10 12:55:52 --> 404 Page Not Found: Shop/wp_includes
ERROR - 2020-12-10 12:55:52 --> 404 Page Not Found: Wp1/wp_includes
ERROR - 2020-12-10 12:55:52 --> 404 Page Not Found: Test/wp_includes
ERROR - 2020-12-10 12:55:52 --> 404 Page Not Found: Wp2/wp_includes
ERROR - 2020-12-10 12:55:52 --> 404 Page Not Found: Site/wp_includes
ERROR - 2020-12-10 12:55:53 --> 404 Page Not Found: Cms/wp_includes
ERROR - 2020-12-10 12:55:53 --> 404 Page Not Found: Sito/wp_includes
ERROR - 2020-12-10 17:50:00 --> 404 Page Not Found: Backup/wp_admin
ERROR - 2020-12-10 20:54:10 --> 404 Page Not Found: Env/index
ERROR - 2020-12-10 20:54:12 --> 404 Page Not Found: Env/index
ERROR - 2020-12-10 20:54:13 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-12-10 21:45:54 --> 404 Page Not Found: Env/index
