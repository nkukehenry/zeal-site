<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-14 02:18:21 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-05-14 02:18:23 --> 404 Page Not Found: Adstxt/index
