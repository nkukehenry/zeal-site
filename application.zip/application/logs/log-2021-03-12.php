<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-12 01:14:47 --> 404 Page Not Found: 403shtml/index
ERROR - 2021-03-12 06:33:15 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-03-12 07:24:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-12 14:35:02 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-03-12 14:43:51 --> 404 Page Not Found: Wp_includes/fonts
ERROR - 2021-03-12 16:35:01 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-03-12 16:43:14 --> 404 Page Not Found: Wp_includes/fonts
ERROR - 2021-03-12 17:20:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-12 18:21:34 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-03-12 18:28:34 --> 404 Page Not Found: Env/index
