<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-16 03:01:55 --> 404 Page Not Found: Composerjson/index
ERROR - 2021-02-16 09:05:15 --> 404 Page Not Found: Public/home
ERROR - 2021-02-16 09:33:22 --> 404 Page Not Found: Wp/wp_admin
