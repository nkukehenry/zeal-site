<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-23 18:40:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-09-23 18:43:57 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2020-09-23 18:43:57 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2020-09-23 18:43:58 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2020-09-23 18:43:58 --> 404 Page Not Found: Web/wp_includes
ERROR - 2020-09-23 18:43:58 --> 404 Page Not Found: Wordpress/wp_includes
ERROR - 2020-09-23 18:43:58 --> 404 Page Not Found: Website/wp_includes
ERROR - 2020-09-23 18:43:58 --> 404 Page Not Found: Wp/wp_includes
ERROR - 2020-09-23 18:43:59 --> 404 Page Not Found: News/wp_includes
ERROR - 2020-09-23 18:44:00 --> 404 Page Not Found: Wp1/wp_includes
ERROR - 2020-09-23 18:44:01 --> 404 Page Not Found: Test/wp_includes
ERROR - 2020-09-23 18:44:01 --> 404 Page Not Found: Wp2/wp_includes
ERROR - 2020-09-23 18:44:03 --> 404 Page Not Found: Site/wp_includes
ERROR - 2020-09-23 18:44:04 --> 404 Page Not Found: Cms/wp_includes
ERROR - 2020-09-23 18:44:04 --> 404 Page Not Found: Sito/wp_includes
ERROR - 2020-09-23 22:01:47 --> 404 Page Not Found: Api/vendor
ERROR - 2020-09-23 22:03:11 --> 404 Page Not Found: Laravel/vendor
ERROR - 2020-09-23 22:04:49 --> 404 Page Not Found: admin/Vendor/phpunit
ERROR - 2020-09-23 22:04:57 --> 404 Page Not Found: Modules/ps_facetedsearch
ERROR - 2020-09-23 22:07:16 --> 404 Page Not Found: Core/vendor
ERROR - 2020-09-23 22:07:44 --> 404 Page Not Found: Mahara/auth
ERROR - 2020-09-23 22:09:02 --> 404 Page Not Found: Lib/vendor
ERROR - 2020-09-23 22:09:31 --> 404 Page Not Found: Backup/vendor
ERROR - 2020-09-23 22:13:02 --> 404 Page Not Found: Www/vendor
ERROR - 2020-09-23 22:13:20 --> 404 Page Not Found: App/vendor
ERROR - 2020-09-23 22:18:22 --> 404 Page Not Found: Administration/vendor
