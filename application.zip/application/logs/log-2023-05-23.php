<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-23 08:19:11 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-23 08:19:11 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-23 08:19:11 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-23 08:19:11 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-23 08:20:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-23 08:20:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-23 08:20:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-23 08:20:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-23 08:21:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-23 08:21:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-23 08:21:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-23 08:21:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-23 08:21:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-23 08:23:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-23 08:23:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-23 08:23:21 --> 404 Page Not Found: Assets/site
