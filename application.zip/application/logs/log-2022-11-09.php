<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-09 16:31:44 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:39:35 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:39:41 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:41:38 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:41:59 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:42:04 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:47:20 --> 404 Page Not Found: Public/home
ERROR - 2022-11-09 16:48:10 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:48:13 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:48:29 --> 404 Page Not Found: Public/home
ERROR - 2022-11-09 16:49:23 --> 404 Page Not Found: Public/home
ERROR - 2022-11-09 16:50:34 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:51:35 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:52:32 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:52:41 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:53:29 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:53:50 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:54:17 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:54:29 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:55:05 --> 404 Page Not Found: Public/home
ERROR - 2022-11-09 16:55:55 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:55:55 --> 404 Page Not Found: Public/home
ERROR - 2022-11-09 16:56:11 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:56:11 --> 404 Page Not Found: Public/home
ERROR - 2022-11-09 16:56:29 --> 404 Page Not Found: Public/home
ERROR - 2022-11-09 16:56:59 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:57:04 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:57:32 --> 404 Page Not Found: Public/home
ERROR - 2022-11-09 16:58:45 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:58:45 --> 404 Page Not Found: Public/home
ERROR - 2022-11-09 16:58:47 --> 404 Page Not Found: Public/home
ERROR - 2022-11-09 16:58:47 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:59:18 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:59:18 --> 404 Page Not Found: Public/home
ERROR - 2022-11-09 16:59:29 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 16:59:29 --> 404 Page Not Found: Public/home
ERROR - 2022-11-09 17:00:33 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 17:00:46 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 17:01:04 --> 404 Page Not Found: Public/home
ERROR - 2022-11-09 17:03:03 --> 404 Page Not Found: Public/home
ERROR - 2022-11-09 17:03:03 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 17:04:19 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 17:04:26 --> 404 Page Not Found: Public/home
ERROR - 2022-11-09 17:04:47 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 17:05:38 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 17:09:56 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 17:10:35 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 17:10:38 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 17:10:44 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 17:10:47 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 17:11:05 --> Severity: Warning --> unlink(./public/uploads/service-2.png): No such file or directory C:\xampp\htdocs\forex\application\controllers\admin\Service.php 168
ERROR - 2022-11-09 17:20:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 987
ERROR - 2022-11-09 17:20:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 993
ERROR - 2022-11-09 17:20:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 999
ERROR - 2022-11-09 17:20:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1005
ERROR - 2022-11-09 17:20:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1011
ERROR - 2022-11-09 17:29:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 987
ERROR - 2022-11-09 17:29:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 993
ERROR - 2022-11-09 17:29:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 999
ERROR - 2022-11-09 17:29:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1005
ERROR - 2022-11-09 17:29:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1011
ERROR - 2022-11-09 17:31:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 987
ERROR - 2022-11-09 17:31:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 993
ERROR - 2022-11-09 17:31:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 999
ERROR - 2022-11-09 17:31:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1005
ERROR - 2022-11-09 17:31:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1011
ERROR - 2022-11-09 17:31:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 987
ERROR - 2022-11-09 17:31:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 993
ERROR - 2022-11-09 17:31:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 999
ERROR - 2022-11-09 17:31:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1005
ERROR - 2022-11-09 17:31:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1011
ERROR - 2022-11-09 17:35:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 987
ERROR - 2022-11-09 17:35:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 993
ERROR - 2022-11-09 17:35:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 999
ERROR - 2022-11-09 17:35:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1005
ERROR - 2022-11-09 17:35:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1011
ERROR - 2022-11-09 17:35:19 --> 404 Page Not Found: Public/home
ERROR - 2022-11-09 17:53:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 987
ERROR - 2022-11-09 17:53:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 993
ERROR - 2022-11-09 17:53:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 999
ERROR - 2022-11-09 17:53:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1005
ERROR - 2022-11-09 17:53:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1011
ERROR - 2022-11-09 20:15:50 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\forex\application\controllers\admin\Slider.php 58
ERROR - 2022-11-09 20:16:49 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 20:16:53 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 20:16:56 --> 404 Page Not Found: Public/uploads
ERROR - 2022-11-09 20:17:04 --> Severity: Warning --> unlink(./public/uploads/slider-3.PNG): No such file or directory C:\xampp\htdocs\forex\application\controllers\admin\Slider.php 138
ERROR - 2022-11-09 20:18:06 --> 404 Page Not Found: Public/home
ERROR - 2022-11-09 20:20:54 --> 404 Page Not Found: Public/css
ERROR - 2022-11-09 20:25:53 --> Severity: Notice --> Undefined index: about_title C:\xampp\htdocs\forex\application\views\view_about.php 4
ERROR - 2022-11-09 20:35:07 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\forex\application\views\view_contact.php 3
ERROR - 2022-11-09 20:35:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\view_contact.php 3
ERROR - 2022-11-09 20:45:32 --> 404 Page Not Found: Public/css
ERROR - 2022-11-09 20:47:39 --> 404 Page Not Found: Public/css
ERROR - 2022-11-09 20:47:43 --> 404 Page Not Found: Public/css
ERROR - 2022-11-09 21:07:46 --> 404 Page Not Found: Public/css
ERROR - 2022-11-09 21:09:48 --> 404 Page Not Found: Public/css
ERROR - 2022-11-09 21:11:21 --> 404 Page Not Found: Public/home
