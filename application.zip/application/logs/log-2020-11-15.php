<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-15 01:21:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-11-15 03:13:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-11-15 07:35:48 --> 404 Page Not Found: Old/wp_admin
ERROR - 2020-11-15 10:27:57 --> 404 Page Not Found: Env/index
ERROR - 2020-11-15 20:55:18 --> 404 Page Not Found: Xmlrpcphp/index
