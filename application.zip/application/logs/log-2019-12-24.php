<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-24 22:52:21 --> 404 Page Not Found: Wp_loginphp/index
