<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-25 22:22:57 --> 404 Page Not Found: Public/assets
