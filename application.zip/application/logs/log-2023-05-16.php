<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-16 13:36:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'zealforex' C:\xampp\htdocs\zeal-site\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-05-16 13:36:42 --> Unable to connect to the database
