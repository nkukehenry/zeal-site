<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-17 16:27:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'zealforex' C:\xampp\htdocs\zeal-site\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-05-17 16:27:45 --> Unable to connect to the database
ERROR - 2023-05-17 16:29:38 --> Query error: No database selected - Invalid query: SELECT * from tbl_settings WHERE id=1
ERROR - 2023-05-17 16:31:54 --> Query error: No database selected - Invalid query: SELECT * from tbl_settings WHERE id=1
