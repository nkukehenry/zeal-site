<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-08 00:18:02 --> 404 Page Not Found: Shop/admin
ERROR - 2020-01-08 00:18:03 --> 404 Page Not Found: Store/admin
ERROR - 2020-01-08 00:18:04 --> 404 Page Not Found: Magento/admin
ERROR - 2020-01-08 00:18:05 --> 404 Page Not Found: Magento2/admin
ERROR - 2020-01-08 00:18:06 --> 404 Page Not Found: Pub/errors
ERROR - 2020-01-08 00:18:07 --> 404 Page Not Found: Shop/pub
ERROR - 2020-01-08 00:18:08 --> 404 Page Not Found: Store/pub
ERROR - 2020-01-08 00:18:08 --> 404 Page Not Found: Magento/pub
ERROR - 2020-01-08 00:18:09 --> 404 Page Not Found: Magento2/pub
ERROR - 2020-01-08 00:18:12 --> 404 Page Not Found: Shop/index
ERROR - 2020-01-08 00:18:13 --> 404 Page Not Found: Store/index
ERROR - 2020-01-08 00:18:14 --> 404 Page Not Found: Magento/index
ERROR - 2020-01-08 00:18:14 --> 404 Page Not Found: Magento2/index
ERROR - 2020-01-08 00:48:18 --> 404 Page Not Found: Shop/admin
ERROR - 2020-01-08 00:48:19 --> 404 Page Not Found: Store/admin
ERROR - 2020-01-08 00:48:25 --> 404 Page Not Found: Magento/admin
ERROR - 2020-01-08 00:48:26 --> 404 Page Not Found: Magento2/admin
ERROR - 2020-01-08 00:48:27 --> 404 Page Not Found: Pub/errors
ERROR - 2020-01-08 00:48:28 --> 404 Page Not Found: Shop/pub
ERROR - 2020-01-08 00:48:29 --> 404 Page Not Found: Store/pub
ERROR - 2020-01-08 00:48:30 --> 404 Page Not Found: Magento/pub
ERROR - 2020-01-08 00:48:31 --> 404 Page Not Found: Magento2/pub
ERROR - 2020-01-08 00:48:38 --> 404 Page Not Found: Shop/index
ERROR - 2020-01-08 00:48:39 --> 404 Page Not Found: Store/index
ERROR - 2020-01-08 00:48:40 --> 404 Page Not Found: Magento/index
ERROR - 2020-01-08 00:48:41 --> 404 Page Not Found: Magento2/index
