<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-28 03:04:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-09-28 05:07:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-09-28 13:35:05 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-09-28 13:35:06 --> 404 Page Not Found: Adstxt/index
