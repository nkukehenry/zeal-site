<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-15 00:19:12 --> 404 Page Not Found: Wp_admin/setup_config.php
ERROR - 2021-06-15 00:19:34 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-06-15 00:19:43 --> 404 Page Not Found: Blog/wp_admin
ERROR - 2021-06-15 00:20:15 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-06-15 00:20:44 --> 404 Page Not Found: New/wp_admin
ERROR - 2021-06-15 00:20:58 --> 404 Page Not Found: Test/wp_admin
ERROR - 2021-06-15 00:21:00 --> 404 Page Not Found: Wp/wp_admin
