<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-07 13:08:49 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-08-07 13:31:55 --> 404 Page Not Found: Adstxt/index
