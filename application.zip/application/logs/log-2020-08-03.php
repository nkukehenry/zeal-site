<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-03 11:06:55 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-08-03 13:54:06 --> 404 Page Not Found: Wp_admin/install.php
