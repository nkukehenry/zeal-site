<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-22 00:02:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-22 01:40:28 --> 404 Page Not Found: Env/index
ERROR - 2021-02-22 01:40:29 --> 404 Page Not Found: Wp_content/index
ERROR - 2021-02-22 05:09:51 --> 404 Page Not Found: 403shtml/index
ERROR - 2021-02-22 08:54:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-22 10:50:35 --> 404 Page Not Found: 403shtml/index
ERROR - 2021-02-22 15:24:23 --> 404 Page Not Found: Git/HEAD
ERROR - 2021-02-22 17:16:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-22 17:17:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-22 17:21:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-22 17:38:27 --> 404 Page Not Found: Git/HEAD
ERROR - 2021-02-22 17:48:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-22 18:02:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-22 18:12:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-22 23:32:48 --> 404 Page Not Found: Git/HEAD
