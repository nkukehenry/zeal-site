<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-06 14:58:04 --> 404 Page Not Found: Adstxt/index
