<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-02 00:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-02 03:05:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-02 11:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-02 23:21:38 --> 404 Page Not Found: Robotstxt/index
