<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-08 20:37:18 --> 404 Page Not Found: Wp_loginphp/index
