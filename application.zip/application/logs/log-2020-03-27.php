<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-27 01:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-27 06:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-27 07:53:42 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-03-27 08:15:35 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-03-27 10:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-27 14:16:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-27 14:16:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-27 20:19:07 --> 404 Page Not Found: Vendor/phpunit
