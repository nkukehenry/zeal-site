<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-04 03:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-04 11:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-04 11:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-04 16:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-04 16:43:52 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-04-04 20:53:05 --> 404 Page Not Found: Robotstxt/index
