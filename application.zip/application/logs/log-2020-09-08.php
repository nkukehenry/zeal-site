<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-08 04:46:21 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-09-08 12:05:18 --> 404 Page Not Found: Wp_content/plugins
