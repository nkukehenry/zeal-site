<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-10 09:15:23 --> 404 Page Not Found: Assets/file_uploader
ERROR - 2021-04-10 15:23:54 --> 404 Page Not Found: Laravel/_ignition
ERROR - 2021-04-10 16:56:31 --> 404 Page Not Found: Owa/auth
ERROR - 2021-04-10 17:13:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-10 17:14:44 --> 404 Page Not Found: Faviconico/index
