<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-23 02:46:34 --> 404 Page Not Found: Wp_admin/config.bak.php
ERROR - 2021-01-23 17:50:05 --> 404 Page Not Found: Env/index
