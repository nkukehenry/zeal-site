<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-01 11:25:59 --> 404 Page Not Found: Theme/assets
ERROR - 2021-04-01 17:16:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-01 17:18:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-01 17:27:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-01 17:33:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-01 17:42:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-01 17:48:44 --> 404 Page Not Found: Faviconico/index
