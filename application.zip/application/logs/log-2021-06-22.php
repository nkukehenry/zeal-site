<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-22 02:35:23 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2021-06-22 02:36:37 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2021-06-22 18:30:49 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2021-06-22 18:32:43 --> 404 Page Not Found: Wp_content/plugins
