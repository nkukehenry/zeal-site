<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-21 13:27:35 --> 404 Page Not Found: Wp_content/plugins
