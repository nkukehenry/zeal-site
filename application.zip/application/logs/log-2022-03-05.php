<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-05 02:33:06 --> 404 Page Not Found: Wordpress/index
ERROR - 2022-03-05 02:33:08 --> 404 Page Not Found: Wp/index
ERROR - 2022-03-05 02:33:08 --> 404 Page Not Found: Bc/index
ERROR - 2022-03-05 02:33:09 --> 404 Page Not Found: Bk/index
ERROR - 2022-03-05 02:33:10 --> 404 Page Not Found: Backup/index
ERROR - 2022-03-05 02:33:10 --> 404 Page Not Found: Old/index
ERROR - 2022-03-05 02:33:10 --> 404 Page Not Found: New/index
ERROR - 2022-03-05 02:33:11 --> 404 Page Not Found: Main/index
