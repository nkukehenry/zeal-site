<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-13 23:07:39 --> 404 Page Not Found: Faviconico/index
