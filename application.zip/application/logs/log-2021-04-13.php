<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-13 10:08:19 --> 404 Page Not Found: Plugins/file_uploader
ERROR - 2021-04-13 17:24:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-13 17:37:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-13 21:17:29 --> 404 Page Not Found: Assets/admin
