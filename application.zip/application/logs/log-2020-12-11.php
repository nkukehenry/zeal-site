<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-11 16:01:09 --> 404 Page Not Found: Env/index
