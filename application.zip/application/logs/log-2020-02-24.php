<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-24 12:28:52 --> 404 Page Not Found: Robotstxt/index
