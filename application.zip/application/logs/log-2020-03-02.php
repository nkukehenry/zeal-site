<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-02 09:31:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-03-02 19:44:14 --> 404 Page Not Found: Robotstxt/index
