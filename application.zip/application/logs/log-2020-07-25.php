<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-25 03:14:08 --> 404 Page Not Found: Public/home
ERROR - 2020-07-25 17:03:49 --> 404 Page Not Found: Well_known/assetlinks.json
