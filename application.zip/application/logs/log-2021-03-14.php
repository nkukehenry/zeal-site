<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-14 01:21:48 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-03-14 01:21:49 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-03-14 01:49:14 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-03-14 07:33:41 --> 404 Page Not Found: admin/Assets/plupload
ERROR - 2021-03-14 07:33:41 --> 404 Page Not Found: Public/admin
ERROR - 2021-03-14 07:33:41 --> 404 Page Not Found: admin/Assets/global
ERROR - 2021-03-14 07:33:41 --> 404 Page Not Found: Plugins/plupload
ERROR - 2021-03-14 07:33:41 --> 404 Page Not Found: admin/Assets/plugins
ERROR - 2021-03-14 17:20:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-14 17:20:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-14 18:59:19 --> 404 Page Not Found: admin/Js/plugins
ERROR - 2021-03-14 18:59:19 --> 404 Page Not Found: Assets/backend
ERROR - 2021-03-14 18:59:19 --> 404 Page Not Found: Assets/admin
