<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-28 13:04:22 --> 404 Page Not Found: Info/license.txt
ERROR - 2020-02-28 19:46:40 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-02-28 20:38:46 --> 404 Page Not Found: Wp_loginphp/index
