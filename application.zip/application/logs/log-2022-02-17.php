<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-17 08:07:40 --> 404 Page Not Found: Public/uploads
ERROR - 2022-02-17 08:07:43 --> 404 Page Not Found: Public/uploads
