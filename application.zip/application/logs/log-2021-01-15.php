<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-15 03:33:56 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-01-15 03:33:57 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-01-15 04:30:14 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-01-15 04:30:29 --> 404 Page Not Found: Wp_includes/fonts
ERROR - 2021-01-15 04:47:51 --> 404 Page Not Found: Wp_admin/index
ERROR - 2021-01-15 10:06:21 --> 404 Page Not Found: Env/index
ERROR - 2021-01-15 13:39:58 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-01-15 13:40:12 --> 404 Page Not Found: Wp_includes/fonts
ERROR - 2021-01-15 15:50:03 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-01-15 19:16:36 --> 404 Page Not Found: 403shtml/index
