<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-12 21:21:23 --> 404 Page Not Found: DS_Store/index
ERROR - 2022-04-12 21:21:25 --> 404 Page Not Found: DS_Store/index
