<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-06 08:50:24 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2021-02-06 17:12:55 --> 404 Page Not Found: Faviconico/index
