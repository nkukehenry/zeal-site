<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-01 00:02:48 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\servixo\benos\benos\cms\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-03-01 00:02:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\servixo\benos\benos\cms\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-03-01 00:02:48 --> Unable to connect to the database
ERROR - 2019-03-01 04:03:51 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\servixo\benos\benos\cms\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-03-01 04:03:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\servixo\benos\benos\cms\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-03-01 04:03:51 --> Unable to connect to the database
