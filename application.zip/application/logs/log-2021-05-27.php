<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-27 01:47:03 --> 404 Page Not Found: Ckfinder/core
ERROR - 2021-05-27 01:47:03 --> 404 Page Not Found: Js/ckfinder
ERROR - 2021-05-27 09:55:20 --> 404 Page Not Found: Wp_admin/admin_ajax.php
