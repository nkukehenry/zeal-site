<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-11 15:57:52 --> 404 Page Not Found: Wp_content/plugins
