<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-28 09:36:59 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 09:37:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 09:37:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 09:37:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:43:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:43:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:43:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:43:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:43:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:43:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:43:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:43:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:43:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:43:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:43:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:43:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:43:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:43:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:43:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:44:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:47:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:47:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:47:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:47:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:48:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:48:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:48:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:48:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:48:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:48:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:49:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:49:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:49:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:49:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:49:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:49:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:51:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:51:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:51:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:51:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:51:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:51:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:58:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:58:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:58:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:58:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:58:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:58:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:59:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:59:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:59:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:59:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:59:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 10:59:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 11:00:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 11:00:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 11:19:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 12:04:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Model_currencies C:\xampp\htdocs\zeal-site\system\core\Loader.php 348
ERROR - 2023-05-28 12:04:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Model_currencies C:\xampp\htdocs\zeal-site\system\core\Loader.php 348
ERROR - 2023-05-28 12:04:50 --> Severity: error --> Exception: Unable to locate the model you have specified: Model_currencies C:\xampp\htdocs\zeal-site\system\core\Loader.php 348
ERROR - 2023-05-28 12:04:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Model_currencies C:\xampp\htdocs\zeal-site\system\core\Loader.php 348
ERROR - 2023-05-28 12:04:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Model_currencies C:\xampp\htdocs\zeal-site\system\core\Loader.php 348
ERROR - 2023-05-28 12:04:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Model_currencies C:\xampp\htdocs\zeal-site\system\core\Loader.php 348
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 68
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 74
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 80
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 96
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 102
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 108
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 114
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 120
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 124
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 130
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 134
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 140
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 144
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 150
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 154
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 160
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 164
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 171
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 172
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 190
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 214
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 220
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 227
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 228
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 247
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 253
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 260
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 261
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 280
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 286
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 293
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 294
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 312
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 316
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 320
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 326
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 330
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 334
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 340
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 344
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 348
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 354
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 358
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 362
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 369
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 370
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 387
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 410
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 416
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 423
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 424
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 443
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 449
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 456
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 457
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 476
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 500
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 506
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 513
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 514
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 533
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 539
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 546
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 547
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 566
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 572
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 579
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 580
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 598
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 621
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 627
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 633
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 640
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_home C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 641
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 662
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 668
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 674
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 680
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_about C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 686
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_faq C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 705
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_faq C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 711
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_faq C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 717
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_faq C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 723
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_service C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 742
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_service C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 748
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_service C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 754
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_service C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 760
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_testimonial C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 779
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_testimonial C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 785
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_testimonial C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 791
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_testimonial C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 797
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_news C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 816
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_news C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 822
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_news C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 828
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_news C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 834
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_event C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 853
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_event C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 859
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_event C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 865
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_event C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 871
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 889
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 895
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 901
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 907
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 913
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 919
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 925
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_contact C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 931
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_search C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 949
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_search C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 955
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_search C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 961
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_search C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 967
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_term C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 987
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_term C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 993
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_term C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 999
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_term C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 1005
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_term C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 1011
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_privacy C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 1029
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_privacy C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 1035
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_privacy C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 1041
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_privacy C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 1047
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_privacy C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 1053
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_team C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 1074
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_team C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 1080
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_team C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 1086
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_team C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 1092
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_portfolio C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 1112
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_portfolio C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 1118
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_portfolio C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 1124
ERROR - 2023-05-28 12:12:12 --> Severity: Notice --> Undefined variable: page_portfolio C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 1130
ERROR - 2023-05-28 12:12:32 --> Query error: Table 'zealforex.tbl_subscriber' doesn't exist - Invalid query: SELECT * FROM tbl_subscriber WHERE subs_active=1
ERROR - 2023-05-28 12:14:49 --> Severity: Notice --> Undefined variable: portfolio_category C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 53
ERROR - 2023-05-28 12:14:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 53
ERROR - 2023-05-28 12:15:50 --> Severity: Notice --> Undefined variable: portfolio_category C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 53
ERROR - 2023-05-28 12:15:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 53
ERROR - 2023-05-28 12:19:02 --> Severity: Notice --> Undefined variable: portfolio_category C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 53
ERROR - 2023-05-28 12:19:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 53
ERROR - 2023-05-28 12:41:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 12:41:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 12:41:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 12:41:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 12:41:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 12:41:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 12:41:37 --> Severity: Notice --> Undefined variable: portfolio_category C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 53
ERROR - 2023-05-28 12:41:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 53
ERROR - 2023-05-28 12:43:52 --> Severity: error --> Exception: Call to undefined method Model_currencies::remitted_currencies_data() C:\xampp\htdocs\zeal-site\application\controllers\admin\Currencies.php 17
ERROR - 2023-05-28 12:44:03 --> Severity: Notice --> Undefined variable: portfolio_category C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 53
ERROR - 2023-05-28 12:44:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 53
ERROR - 2023-05-28 12:44:18 --> Severity: error --> Exception: Call to undefined method Model_currencies::remitted_currencies_data() C:\xampp\htdocs\zeal-site\application\controllers\admin\Currencies.php 17
ERROR - 2023-05-28 13:06:10 --> Severity: Notice --> Undefined variable: portfolio_category C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 53
ERROR - 2023-05-28 13:06:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 53
ERROR - 2023-05-28 13:13:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 53
ERROR - 2023-05-28 13:14:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 53
ERROR - 2023-05-28 13:17:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 52
ERROR - 2023-05-28 13:17:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 52
ERROR - 2023-05-28 13:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 52
ERROR - 2023-05-28 13:23:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 53
ERROR - 2023-05-28 13:23:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_remitted_currencies.php 53
ERROR - 2023-05-28 13:37:08 --> 404 Page Not Found: admin/Currencies/add_forex_data
ERROR - 2023-05-28 13:37:15 --> 404 Page Not Found: admin/Currencies/add_remitted_data
ERROR - 2023-05-28 13:47:26 --> Severity: Notice --> Undefined property: CI_Form_validation::$run C:\xampp\htdocs\zeal-site\application\controllers\admin\Currencies.php 47
ERROR - 2023-05-28 13:48:40 --> Query error: Table 'zealforex.tbl_subscriber' doesn't exist - Invalid query: SELECT * FROM tbl_subscriber WHERE subs_active=1
ERROR - 2023-05-28 13:49:05 --> Query error: Table 'zealforex.tbl_subscriber' doesn't exist - Invalid query: SELECT * FROM tbl_subscriber WHERE subs_active=1
ERROR - 2023-05-28 14:23:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 14:29:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 14:29:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 14:29:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 14:29:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 14:29:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 14:48:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 14:48:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 14:48:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 14:48:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 14:48:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 14:48:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:14:24 --> Query error: Table 'zealforex.tbl_subscriber' doesn't exist - Invalid query: SELECT * FROM tbl_subscriber WHERE subs_active=1
ERROR - 2023-05-28 15:29:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:29:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:29:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:29:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:29:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:29:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:29:40 --> 404 Page Not Found: admin/Currencies/remitted_currencies
ERROR - 2023-05-28 15:31:13 --> 404 Page Not Found: admin/Currencies/remitted_currencies
ERROR - 2023-05-28 15:36:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:36:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:36:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:36:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:36:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:36:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:39:26 --> 404 Page Not Found: admin/Currencies/remitted_currencies
ERROR - 2023-05-28 15:41:02 --> 404 Page Not Found: admin/Currencies/remitted_currencies
ERROR - 2023-05-28 15:51:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:51:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:51:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:51:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:51:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:51:48 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:51:49 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 15:51:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 16:10:00 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-28 16:35:24 --> 404 Page Not Found: Public/admin
ERROR - 2023-05-28 16:46:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 16:46:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 16:49:01 --> Query error: Table 'zealforex.tbl_subscriber' doesn't exist - Invalid query: SELECT * FROM tbl_subscriber WHERE subs_active=1
ERROR - 2023-05-28 16:52:47 --> 404 Page Not Found: admin/Currencies/index
ERROR - 2023-05-28 16:52:58 --> 404 Page Not Found: admin/Currencies/index
ERROR - 2023-05-28 16:53:00 --> 404 Page Not Found: admin/Currencies/index
ERROR - 2023-05-28 16:59:03 --> Severity: Notice --> Undefined variable: class_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 82
ERROR - 2023-05-28 16:59:03 --> Severity: Notice --> Undefined variable: class_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 82
ERROR - 2023-05-28 16:59:03 --> Severity: Notice --> Undefined variable: class_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 82
ERROR - 2023-05-28 17:00:36 --> Severity: Notice --> Undefined variable: class_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 83
ERROR - 2023-05-28 17:00:36 --> Severity: Notice --> Undefined variable: class_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 83
ERROR - 2023-05-28 17:00:36 --> Severity: Notice --> Undefined variable: class_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 83
ERROR - 2023-05-28 17:00:49 --> Severity: Notice --> Undefined variable: class_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 83
ERROR - 2023-05-28 17:00:49 --> Severity: Notice --> Undefined variable: class_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 83
ERROR - 2023-05-28 17:00:49 --> Severity: Notice --> Undefined variable: class_name C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 83
ERROR - 2023-05-28 17:07:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 17:41:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 17:41:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 17:41:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 17:41:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 17:41:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 17:41:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 17:57:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 17:57:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 17:57:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 17:57:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:44:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:44:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:44:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:44:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:44:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:44:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:45:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:45:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:45:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:45:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:45:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:45:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:45:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:45:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:45:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:45:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:45:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:45:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:46:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:46:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:46:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:46:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:46:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:46:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:46:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:46:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:46:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:46:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:46:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:46:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:47:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:47:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:47:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:47:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:48:24 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:48:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:48:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:48:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:48:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:50:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:50:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:50:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:50:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:50:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:57:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:57:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:57:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:57:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:57:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:57:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
ERROR - 2023-05-28 18:59:08 --> Severity: Notice --> Undefined index: country_code C:\xampp\htdocs\zeal-site\application\views\admin\currencies\view_add_currency_data.php 49
