<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-01 02:38:11 --> 404 Page Not Found: Wordpress/index
ERROR - 2020-11-01 02:38:11 --> 404 Page Not Found: Wp/index
ERROR - 2020-11-01 02:38:12 --> 404 Page Not Found: Blog/index
ERROR - 2020-11-01 02:38:12 --> 404 Page Not Found: New/index
ERROR - 2020-11-01 02:38:13 --> 404 Page Not Found: Old/index
ERROR - 2020-11-01 02:38:13 --> 404 Page Not Found: Backup/index
ERROR - 2020-11-01 02:38:14 --> 404 Page Not Found: Oldsite/index
ERROR - 2020-11-01 02:38:14 --> 404 Page Not Found: 2019/index
ERROR - 2020-11-01 02:38:15 --> 404 Page Not Found: 2018/index
ERROR - 2020-11-01 02:38:16 --> 404 Page Not Found: Dev/index
ERROR - 2020-11-01 09:21:55 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2020-11-01 21:40:14 --> 404 Page Not Found: Wordpress/wp_admin
