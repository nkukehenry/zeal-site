<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-14 20:40:55 --> 404 Page Not Found: Robotstxt/index
