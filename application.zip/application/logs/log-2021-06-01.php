<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-01 09:54:54 --> 404 Page Not Found: Wp_admin/admin_ajax.php
