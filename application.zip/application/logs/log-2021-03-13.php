<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-13 17:25:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-13 17:28:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-13 17:29:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-13 18:18:22 --> 404 Page Not Found: admin/Js/plugins
