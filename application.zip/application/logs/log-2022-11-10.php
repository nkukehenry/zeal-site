<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-10 14:24:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 987
ERROR - 2022-11-10 14:24:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 993
ERROR - 2022-11-10 14:24:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 999
ERROR - 2022-11-10 14:24:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1005
ERROR - 2022-11-10 14:24:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1011
ERROR - 2022-11-10 14:25:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 987
ERROR - 2022-11-10 14:25:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 993
ERROR - 2022-11-10 14:25:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 999
ERROR - 2022-11-10 14:25:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1005
ERROR - 2022-11-10 14:25:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1011
ERROR - 2022-11-10 14:25:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 987
ERROR - 2022-11-10 14:25:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 993
ERROR - 2022-11-10 14:25:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 999
ERROR - 2022-11-10 14:25:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1005
ERROR - 2022-11-10 14:25:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1011
ERROR - 2022-11-10 14:27:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 987
ERROR - 2022-11-10 14:27:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 993
ERROR - 2022-11-10 14:27:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 999
ERROR - 2022-11-10 14:27:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1005
ERROR - 2022-11-10 14:27:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1011
ERROR - 2022-11-10 14:36:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 987
ERROR - 2022-11-10 14:36:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 993
ERROR - 2022-11-10 14:36:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 999
ERROR - 2022-11-10 14:36:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1005
ERROR - 2022-11-10 14:36:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\forex\application\views\admin\view_page.php 1011
