<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-20 10:28:54 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-20 10:28:56 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-20 10:28:59 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-20 10:29:31 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-20 10:29:32 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-20 10:29:33 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-20 13:03:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-20 20:09:10 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
