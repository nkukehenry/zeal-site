<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-24 04:04:32 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2020-11-24 06:18:16 --> 404 Page Not Found: Sitemap_indexxml/index
