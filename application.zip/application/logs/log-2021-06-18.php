<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-18 12:04:58 --> 404 Page Not Found: Files/index.php
ERROR - 2021-06-18 21:19:44 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2021-06-18 21:19:57 --> 404 Page Not Found: Wp/wp_admin
ERROR - 2021-06-18 21:20:11 --> 404 Page Not Found: New/wp_admin
ERROR - 2021-06-18 21:20:22 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-06-18 21:20:35 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-06-18 21:21:20 --> 404 Page Not Found: Test/wp_admin
ERROR - 2021-06-18 21:21:28 --> 404 Page Not Found: Blog/wp_admin
ERROR - 2021-06-18 21:21:43 --> 404 Page Not Found: Cms/wp_admin
ERROR - 2021-06-18 21:22:03 --> 404 Page Not Found: Web/wp_admin
ERROR - 2021-06-18 21:22:22 --> 404 Page Not Found: Backup/wp_admin
ERROR - 2021-06-18 21:22:31 --> 404 Page Not Found: Site/wp_admin
ERROR - 2021-06-18 21:22:47 --> 404 Page Not Found: Oldsite/wp_admin
