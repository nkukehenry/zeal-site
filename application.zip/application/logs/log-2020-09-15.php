<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-15 02:40:57 --> 404 Page Not Found: Sites/default
ERROR - 2020-09-15 03:33:00 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-09-15 03:33:01 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-09-15 13:23:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-09-15 20:00:53 --> 404 Page Not Found: Components/com_foxcontact
