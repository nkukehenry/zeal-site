<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-15 17:07:19 --> 404 Page Not Found: Js/admin.js
ERROR - 2021-02-15 17:24:54 --> 404 Page Not Found: Faviconico/index
