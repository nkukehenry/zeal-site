<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-09 03:11:41 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2022-08-09 03:11:44 --> 404 Page Not Found: Wordpress/wp_login.php
ERROR - 2022-08-09 03:11:45 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2022-08-09 03:11:48 --> 404 Page Not Found: Wp/wp_login.php
