<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-16 11:58:04 --> 404 Page Not Found: Faviconico/index
