<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-18 15:59:34 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2022-07-18 15:59:35 --> 404 Page Not Found: Wordpress/wp_login.php
ERROR - 2022-07-18 15:59:36 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2022-07-18 15:59:37 --> 404 Page Not Found: Wp/wp_login.php
