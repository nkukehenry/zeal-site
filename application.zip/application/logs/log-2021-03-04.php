<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-04 01:39:35 --> 404 Page Not Found: Env/index
ERROR - 2021-03-04 01:39:38 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-03-04 08:22:08 --> 404 Page Not Found: admin/Assets/file_uploader
ERROR - 2021-03-04 08:22:08 --> 404 Page Not Found: Assets/global
ERROR - 2021-03-04 08:22:08 --> 404 Page Not Found: Assets/file_uploader
ERROR - 2021-03-04 08:22:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-03-04 08:22:08 --> 404 Page Not Found: Public/assets
ERROR - 2021-03-04 12:49:57 --> 404 Page Not Found: Env/index
ERROR - 2021-03-04 13:59:01 --> 404 Page Not Found: admin/Assets/plugins
ERROR - 2021-03-04 13:59:01 --> 404 Page Not Found: Public/admin
ERROR - 2021-03-04 13:59:01 --> 404 Page Not Found: Public/assets
ERROR - 2021-03-04 13:59:01 --> 404 Page Not Found: Public/assets
ERROR - 2021-03-04 13:59:01 --> 404 Page Not Found: admin/Assets/global
ERROR - 2021-03-04 16:08:26 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-03-04 17:44:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-04 19:45:14 --> 404 Page Not Found: Application/assets
ERROR - 2021-03-04 19:45:14 --> 404 Page Not Found: Application/assets
ERROR - 2021-03-04 19:45:14 --> 404 Page Not Found: Application/assets
ERROR - 2021-03-04 19:45:17 --> 404 Page Not Found: Assets/admin
ERROR - 2021-03-04 19:45:18 --> 404 Page Not Found: Plugins/jquery_file_upload
