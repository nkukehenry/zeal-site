<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-07 00:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-07 00:20:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-07 06:09:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-07 06:09:57 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-04-07 15:22:49 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-04-07 15:26:52 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-04-07 18:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-07 18:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-07 20:58:50 --> 404 Page Not Found: Robotstxt/index
