<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-10 13:49:33 --> 404 Page Not Found: Apple_touch_icon_120x120_precomposedpng/index
ERROR - 2020-07-10 13:49:33 --> 404 Page Not Found: Apple_touch_icon_120x120_precomposedpng/index
ERROR - 2020-07-10 13:49:33 --> 404 Page Not Found: Apple_touch_icon_120x120png/index
ERROR - 2020-07-10 13:49:33 --> 404 Page Not Found: Apple_touch_icon_120x120png/index
ERROR - 2020-07-10 13:49:33 --> 404 Page Not Found: Apple_touch_icon_precomposedpng/index
ERROR - 2020-07-10 13:49:33 --> 404 Page Not Found: Apple_touch_icon_precomposedpng/index
ERROR - 2020-07-10 13:49:34 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-07-10 13:49:34 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-07-10 18:07:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-10 18:08:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-10 19:12:08 --> Query error: Table 'solvhong_kreb.tbl_subscriber' doesn't exist - Invalid query: SELECT * FROM tbl_subscriber WHERE subs_active=1
ERROR - 2020-07-10 19:12:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-10 19:12:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-10 19:15:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-10 23:40:01 --> 404 Page Not Found: BingSiteAuthxml/index
ERROR - 2020-07-10 23:42:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-10 23:42:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-10 23:49:02 --> 404 Page Not Found: Google2db62eba065ea73bhtml/index
ERROR - 2020-07-10 23:49:02 --> 404 Page Not Found: Google06ee0fde9864ffdfhtml/index
ERROR - 2020-07-10 23:50:08 --> 404 Page Not Found: Faviconico/index
