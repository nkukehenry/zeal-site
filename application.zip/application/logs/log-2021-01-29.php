<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-29 04:14:21 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2021-01-29 12:43:00 --> 404 Page Not Found: Git/config
ERROR - 2021-01-29 21:13:45 --> 404 Page Not Found: Wp_content/plugins
