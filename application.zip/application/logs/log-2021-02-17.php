<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-17 01:08:13 --> 404 Page Not Found: Wp_loginphp/index
