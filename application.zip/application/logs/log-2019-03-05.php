<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-05 04:38:08 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\servixo\benos\benos\cms\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-03-05 04:38:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\servixo\benos\benos\cms\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-03-05 04:38:08 --> Unable to connect to the database
ERROR - 2019-03-05 04:43:35 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\servixo\benos\benos\cms\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-03-05 04:43:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\servixo\benos\benos\cms\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-03-05 04:43:35 --> Unable to connect to the database
ERROR - 2019-03-05 08:21:48 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\servixo\benos\benos\cms\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-03-05 08:21:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\servixo\benos\benos\cms\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-03-05 08:21:48 --> Unable to connect to the database
