<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-30 11:02:32 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-12-30 11:02:33 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-12-30 18:03:24 --> 404 Page Not Found: Old/wp_admin
