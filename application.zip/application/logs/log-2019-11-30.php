<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-30 22:30:04 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'cheetjuq_cheeternet'@'localhost' (using password: YES) /home/cheepjuq/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-11-30 22:30:04 --> Unable to connect to the database
ERROR - 2019-11-30 22:31:04 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'cheepjuq_cheeternet'@'localhost' (using password: YES) /home/cheepjuq/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-11-30 22:31:04 --> Unable to connect to the database
ERROR - 2019-11-30 22:48:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-11-30 23:12:58 --> 404 Page Not Found: Public/css
ERROR - 2019-11-30 23:15:38 --> 404 Page Not Found: Public/css
ERROR - 2019-11-30 23:55:45 --> 404 Page Not Found: Google73ccfd9972ab0f70html/index
ERROR - 2019-11-30 23:55:46 --> 404 Page Not Found: Google7466353f8ac01709html/index
ERROR - 2019-11-30 23:56:41 --> 404 Page Not Found: Google73ccfd9972ab0f70html/index
ERROR - 2019-11-30 23:57:06 --> 404 Page Not Found: Google73ccfd9972ab0f70html/index
ERROR - 2019-11-30 23:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-11-30 23:58:48 --> 404 Page Not Found: Faviconico/index
