<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-28 00:23:18 --> 404 Page Not Found: admin/Assets/plugins
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-28 00:23:18 --> 404 Page Not Found: Public/assets
ERROR - 2021-03-28 09:04:57 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-03-28 11:40:18 --> 404 Page Not Found: admin/Assets/global
