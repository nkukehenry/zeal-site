<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-02 00:35:40 --> 404 Page Not Found: Env/index
ERROR - 2020-12-02 14:14:21 --> 404 Page Not Found: OLD/wp_admin
ERROR - 2020-12-02 14:48:11 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2020-12-02 15:19:06 --> 404 Page Not Found: Wp_includes/css
ERROR - 2020-12-02 15:19:21 --> 404 Page Not Found: Wp_includes/fonts
ERROR - 2020-12-02 17:18:33 --> 404 Page Not Found: Faviconico/index
