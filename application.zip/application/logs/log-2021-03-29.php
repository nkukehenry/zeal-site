<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-29 00:26:22 --> 404 Page Not Found: admin/Assets/plugins
ERROR - 2021-03-29 00:26:22 --> 404 Page Not Found: admin/Assets/jquery_file_upload
ERROR - 2021-03-29 12:19:18 --> 404 Page Not Found: Public/admin
ERROR - 2021-03-29 17:09:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-29 17:09:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-29 19:00:13 --> 404 Page Not Found: Wp_loginphp/index
