<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-01 22:29:35 --> 404 Page Not Found: Robotstxt/index
