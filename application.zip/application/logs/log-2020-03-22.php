<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-22 08:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-22 13:10:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-22 16:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-22 17:00:45 --> 404 Page Not Found: Wp_loginphp/index
