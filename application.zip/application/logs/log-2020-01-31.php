<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-31 10:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-01-31 20:35:48 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-01-31 20:52:20 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-01-31 22:30:37 --> 404 Page Not Found: 403shtml/index
