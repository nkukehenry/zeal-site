<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-25 07:38:30 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-10-25 13:32:26 --> 404 Page Not Found: Apple_touch_icon_120x120_precomposedpng/index
ERROR - 2020-10-25 13:32:26 --> 404 Page Not Found: Apple_touch_icon_120x120png/index
ERROR - 2020-10-25 13:32:26 --> 404 Page Not Found: Apple_touch_icon_precomposedpng/index
ERROR - 2020-10-25 13:32:26 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-10-25 22:41:09 --> 404 Page Not Found: Env/index
