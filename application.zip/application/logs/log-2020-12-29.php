<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-29 17:09:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-12-29 22:34:02 --> 404 Page Not Found: Wp_loginphp/index
