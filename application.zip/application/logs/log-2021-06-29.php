<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-29 04:45:49 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-06-29 05:10:34 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2021-06-29 05:10:42 --> 404 Page Not Found: Wp/wp_admin
ERROR - 2021-06-29 05:10:52 --> 404 Page Not Found: New/wp_admin
ERROR - 2021-06-29 05:11:04 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-06-29 05:11:15 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-06-29 05:11:28 --> 404 Page Not Found: Test/wp_admin
ERROR - 2021-06-29 05:11:40 --> 404 Page Not Found: Blog/wp_admin
ERROR - 2021-06-29 05:11:51 --> 404 Page Not Found: Cms/wp_admin
ERROR - 2021-06-29 05:12:01 --> 404 Page Not Found: Web/wp_admin
ERROR - 2021-06-29 05:12:14 --> 404 Page Not Found: Backup/wp_admin
ERROR - 2021-06-29 05:12:25 --> 404 Page Not Found: Site/wp_admin
ERROR - 2021-06-29 05:12:37 --> 404 Page Not Found: Oldsite/wp_admin
ERROR - 2021-06-29 20:26:04 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2021-06-29 20:26:14 --> 404 Page Not Found: Wp/wp_admin
ERROR - 2021-06-29 20:26:43 --> 404 Page Not Found: New/wp_admin
ERROR - 2021-06-29 20:27:08 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-06-29 20:27:28 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-06-29 20:27:44 --> 404 Page Not Found: Test/wp_admin
ERROR - 2021-06-29 20:28:00 --> 404 Page Not Found: Blog/wp_admin
ERROR - 2021-06-29 20:28:18 --> 404 Page Not Found: Cms/wp_admin
ERROR - 2021-06-29 20:28:39 --> 404 Page Not Found: Web/wp_admin
ERROR - 2021-06-29 20:28:58 --> 404 Page Not Found: Backup/wp_admin
ERROR - 2021-06-29 20:29:15 --> 404 Page Not Found: Site/wp_admin
ERROR - 2021-06-29 20:29:34 --> 404 Page Not Found: Oldsite/wp_admin
ERROR - 2021-06-29 23:06:13 --> 404 Page Not Found: Wp_admin/index
