<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-02 13:38:04 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-10-02 18:18:04 --> 404 Page Not Found: Wordpress/index
ERROR - 2020-10-02 18:18:08 --> 404 Page Not Found: Wp/index
ERROR - 2020-10-02 18:18:10 --> 404 Page Not Found: Blog/index
ERROR - 2020-10-02 18:18:13 --> 404 Page Not Found: Old/index
ERROR - 2020-10-02 18:18:14 --> 404 Page Not Found: New/index
ERROR - 2020-10-02 18:18:17 --> 404 Page Not Found: Test/index
ERROR - 2020-10-02 18:18:20 --> 404 Page Not Found: Backup/index
ERROR - 2020-10-02 18:18:21 --> 404 Page Not Found: Temp/index
ERROR - 2020-10-02 21:04:40 --> 404 Page Not Found: Vendor/phpunit
