<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-16 00:19:58 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-09-16 14:55:15 --> 404 Page Not Found: Popcornphp/index
ERROR - 2020-09-16 21:15:46 --> 404 Page Not Found: Wp/wp_content
ERROR - 2020-09-16 21:16:31 --> 404 Page Not Found: Blog/wp_content
