<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-10 01:07:58 --> 404 Page Not Found: Js/mage
ERROR - 2021-02-10 05:06:41 --> 404 Page Not Found: Env/index
ERROR - 2021-02-10 08:27:49 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-02-10 08:27:50 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-02-10 19:50:55 --> 404 Page Not Found: Wp_admin/index
ERROR - 2021-02-10 20:21:26 --> 404 Page Not Found: Git/config
