<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-07 08:56:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 08:56:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 08:56:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 08:56:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 08:56:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:00:49 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:00:51 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:00:51 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:00:51 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:00:51 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:02:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:02:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:02:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:02:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:02:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:02:28 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:16:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:17:01 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:17:01 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:17:01 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:17:01 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:17:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:17:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:17:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:17:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:17:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:17:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:23:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:23:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 09:25:52 --> Query error: Table 'zealforex.tbl_subscriber' doesn't exist - Invalid query: SELECT * FROM tbl_subscriber WHERE subs_active=1
ERROR - 2023-06-07 16:44:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 16:44:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 16:44:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 16:44:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 16:44:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 16:44:11 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:48:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:48:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:48:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:48:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:48:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:48:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: sell_rates C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: sell_rates C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: sell_rates C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: sell_rates C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: sell_rates C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: sell_rates C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: sell_rates C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: sell_rates C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: sell_rates C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: sell_rates C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: sell_rates C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:38 --> Severity: Notice --> Undefined index: sell_rates C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:52:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:52:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:52:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:52:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:53:05 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:53:05 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:53:05 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:53:05 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:53:05 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:53:05 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:53:05 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:53:05 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:53:05 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:53:05 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:53:05 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:53:05 --> Severity: Notice --> Undefined index: currency C:\xampp\htdocs\zeal-site\application\views\view_home.php 111
ERROR - 2023-06-07 17:53:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:53:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:53:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:53:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:53:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:55:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:55:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:55:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:55:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:55:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:55:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:59:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:59:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:59:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:59:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 17:59:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:01:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:01:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:01:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:01:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:01:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:01:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:02:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:02:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:02:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:02:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:03:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:03:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:03:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:03:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:05:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:05:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:05:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:05:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:05:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:05:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:05:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:05:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:05:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:05:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:05:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:05:56 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:38 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:06:59 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:07:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:07:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:07:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:07:20 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:08:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:08:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:08:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:08:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:08:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:11:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:11:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:11:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:11:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:11:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:14:49 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:14:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:14:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:14:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:40:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:40:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:40:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:40:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:40:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:40:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:40:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:40:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:40:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:40:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:40:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:40:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:41:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:41:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:41:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:41:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:41:34 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:41:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:41:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:41:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:41:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:42:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:42:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:42:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:42:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:42:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:42:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:42:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:42:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:42:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:42:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:42:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:43:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:43:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:43:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:43:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:43:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:43:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:43:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:43:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:43:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:43:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:43:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:44:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:44:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:44:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:44:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:44:10 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:44:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:44:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:44:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:44:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:45:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:45:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:45:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:45:40 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:45:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:45:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:45:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:45:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:46:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:46:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:46:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:46:08 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:47:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:47:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:47:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:47:58 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:57:37 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:57:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:57:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:57:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:57:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 18:57:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:00:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:00:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:00:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:00:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:00:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:00:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:00:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:00:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:00:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:00:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:00:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:09:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:09:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:09:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:09:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:09:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:09:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:10:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:10:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:10:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:10:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:11:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:11:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:11:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:11:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:11:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:11:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:11:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:11:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:11:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:11:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:16:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:16:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:16:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:16:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:16:35 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:28:30 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:31:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:31:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:31:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:31:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:31:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:36:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:36:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:36:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:36:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:36:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:36:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:37:07 --> 404 Page Not Found: News/5
ERROR - 2023-06-07 19:37:11 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:37:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:37:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:37:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:37:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:37:12 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:37:36 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:37:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:37:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:37:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:37:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:38:01 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:38:01 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:38:01 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:38:01 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:38:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:38:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:38:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:38:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:38:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:38:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:38:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:38:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:38:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:38:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:38:42 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:44:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:44:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:44:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:44:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: sell_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 116
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: buy_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 121
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: sell_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 116
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: buy_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 121
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: sell_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 116
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: buy_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 121
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: sell_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 116
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: buy_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 121
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: sell_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 116
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: buy_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 121
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: sell_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 116
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: buy_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 121
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: sell_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 116
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: buy_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 121
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: sell_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 116
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: buy_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 121
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: sell_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 116
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: buy_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 121
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: sell_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 116
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: buy_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 121
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: sell_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 116
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: buy_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 121
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: sell_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 116
ERROR - 2023-06-07 19:59:24 --> Severity: Notice --> Undefined index: buy_rate C:\xampp\htdocs\zeal-site\application\views\view_home.php 121
ERROR - 2023-06-07 19:59:25 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:59:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:59:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:59:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 19:59:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:01:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:01:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:01:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:01:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:01:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:01:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:02:21 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:02:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:02:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:02:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:04:02 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:04:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:04:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:04:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:04:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:04:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:04:31 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:04:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:04:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:04:32 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:04:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:10:13 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:10:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:10:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:10:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:10:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:10:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:10:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:10:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:10:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:10:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:10:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:10:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:11:22 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:11:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:11:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:11:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:11:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:11:27 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:11:52 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:11:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:11:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:11:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:11:54 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:12:17 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:12:18 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:12:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:12:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:12:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:13:14 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:13:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:13:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:13:15 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:33:55 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:33:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:33:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:33:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:33:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:35:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:35:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:35:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:35:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:35:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:35:09 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-07 20:39:25 --> 404 Page Not Found: Assets/site
