<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-17 04:57:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-17 07:15:55 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-17 07:40:24 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-07-17 07:59:50 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-17 07:59:51 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-17 08:47:01 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-17 15:12:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-17 17:23:18 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
