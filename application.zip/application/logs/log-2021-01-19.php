<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-19 00:28:42 --> 404 Page Not Found: Env/index
ERROR - 2021-01-19 07:41:32 --> 404 Page Not Found: Application/admin
ERROR - 2021-01-19 07:41:32 --> 404 Page Not Found: Application/admin
ERROR - 2021-01-19 07:41:32 --> 404 Page Not Found: Application/admin
ERROR - 2021-01-19 07:44:40 --> 404 Page Not Found: admin/Assets/jquery_file_upload
ERROR - 2021-01-19 12:32:11 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2021-01-19 13:33:18 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2021-01-19 21:42:59 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-01-19 21:43:00 --> 404 Page Not Found: Adstxt/index
