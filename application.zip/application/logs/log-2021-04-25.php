<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-25 09:53:49 --> 404 Page Not Found: admin/Elfinder/connectors
ERROR - 2021-04-25 17:16:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-25 17:25:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-25 17:25:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-25 17:25:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-25 17:25:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-25 17:25:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-25 17:25:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-25 17:26:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-25 17:26:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-25 17:26:57 --> 404 Page Not Found: Faviconico/index
