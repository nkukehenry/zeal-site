<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-16 09:46:57 --> 404 Page Not Found: Blog/index
