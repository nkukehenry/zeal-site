<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-07 07:42:03 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-12-07 14:46:39 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-12-07 23:54:08 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-12-07 23:54:09 --> 404 Page Not Found: Adstxt/index
