<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-22 03:44:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-01-22 03:44:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-01-22 10:39:13 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2021-01-22 17:09:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-01-22 17:11:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-01-22 18:38:29 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2021-01-22 20:05:34 --> 404 Page Not Found: Wp_admin/index
ERROR - 2021-01-22 20:22:39 --> 404 Page Not Found: Env/index
