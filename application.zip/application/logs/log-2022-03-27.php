<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-27 13:51:29 --> 404 Page Not Found: Public/uploads
ERROR - 2022-03-27 13:51:32 --> 404 Page Not Found: Public/uploads
ERROR - 2022-03-27 13:51:35 --> 404 Page Not Found: Public/uploads
