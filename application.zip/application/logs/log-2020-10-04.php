<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-04 10:28:53 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-10-04 10:28:54 --> 404 Page Not Found: Adstxt/index
