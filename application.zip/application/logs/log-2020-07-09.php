<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-09 03:16:11 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-07-09 14:29:44 --> 404 Page Not Found: Apple_touch_icon_120x120_precomposedpng/index
ERROR - 2020-07-09 14:29:44 --> 404 Page Not Found: Apple_touch_icon_120x120png/index
ERROR - 2020-07-09 14:29:44 --> 404 Page Not Found: Apple_touch_icon_precomposedpng/index
ERROR - 2020-07-09 14:29:45 --> 404 Page Not Found: Apple_touch_iconpng/index
ERROR - 2020-07-09 17:46:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-09 17:46:38 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2020-07-09 17:46:48 --> 404 Page Not Found: Adstxt/index
