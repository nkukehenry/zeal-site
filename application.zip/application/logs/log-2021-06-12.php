<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-12 01:22:01 --> 404 Page Not Found: Wp_json/wp
ERROR - 2021-06-12 23:43:37 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-06-12 23:43:38 --> 404 Page Not Found: Adstxt/index
