<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-17 07:10:30 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2020-12-17 20:09:06 --> 404 Page Not Found: Adstxt/index
