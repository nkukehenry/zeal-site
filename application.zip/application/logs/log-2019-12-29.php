<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-29 01:19:19 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2019-12-29 02:17:37 --> 404 Page Not Found: Blog/wp_login.php
ERROR - 2019-12-29 02:37:43 --> 404 Page Not Found: Site/wp_login.php
ERROR - 2019-12-29 02:58:51 --> 404 Page Not Found: Www/wp_login.php
ERROR - 2019-12-29 03:19:50 --> 404 Page Not Found: Html/wp_login.php
ERROR - 2019-12-29 03:41:21 --> 404 Page Not Found: Public_html/wp_login.php
ERROR - 2019-12-29 04:25:38 --> 404 Page Not Found: Wp/wp_login.php
ERROR - 2019-12-29 16:21:14 --> 404 Page Not Found: Cms/wp_login.php
