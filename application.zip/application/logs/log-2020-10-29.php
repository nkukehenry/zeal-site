<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-29 09:37:58 --> 404 Page Not Found: Faviconico/index
