<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-04 13:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-02-04 20:10:36 --> 404 Page Not Found: Wp_loginphp/index
