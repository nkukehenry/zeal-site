<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-04 03:46:15 --> 404 Page Not Found: Env/index
ERROR - 2021-01-04 03:46:27 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-01-04 04:12:21 --> 404 Page Not Found: Google06ee0fde9864ffdfhtml/index
ERROR - 2021-01-04 12:17:13 --> 404 Page Not Found: Atomxml/index
ERROR - 2021-01-04 13:48:31 --> 404 Page Not Found: Wp_loginphp/index
