<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-25 02:35:25 --> 404 Page Not Found: Env/index
ERROR - 2021-01-25 17:19:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-01-25 17:21:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-01-25 17:34:43 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-01-25 19:26:22 --> 404 Page Not Found: Wordpress/wp_admin
