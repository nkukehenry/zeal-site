<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-05 08:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-12-05 09:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-12-05 19:21:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-12-05 20:37:05 --> 404 Page Not Found: Robotstxt/index
