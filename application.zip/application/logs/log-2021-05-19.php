<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-19 05:07:34 --> 404 Page Not Found: Theme/assets
ERROR - 2021-05-19 10:31:16 --> 404 Page Not Found: Theme/assets
ERROR - 2021-05-19 12:58:14 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2021-05-19 15:23:51 --> 404 Page Not Found: Public/home
ERROR - 2021-05-19 16:00:56 --> 404 Page Not Found: OLD/wp_admin
ERROR - 2021-05-19 18:50:41 --> 404 Page Not Found: Assets/uploadify
ERROR - 2021-05-19 23:07:47 --> 404 Page Not Found: Catalog/Adminhtml_category
ERROR - 2021-05-19 23:07:48 --> 404 Page Not Found: Catalog/Adminhtml_category
