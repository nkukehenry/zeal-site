<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-14 12:59:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-09-14 13:00:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-09-14 13:16:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-09-14 13:17:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-09-14 22:21:53 --> 404 Page Not Found: Public/css
ERROR - 2020-09-14 22:22:08 --> 404 Page Not Found: Public/css
