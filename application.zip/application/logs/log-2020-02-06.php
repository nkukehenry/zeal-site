<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-06 09:43:31 --> 404 Page Not Found: Well_known/pki_validation
ERROR - 2020-02-06 09:43:32 --> 404 Page Not Found: Well_known/pki_validation
ERROR - 2020-02-06 15:33:13 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-02-06 16:05:22 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-02-06 16:39:57 --> 404 Page Not Found: Wp_loginphp/index
