<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-09 08:20:07 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-01-09 08:20:35 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-01-09 12:49:16 --> 404 Page Not Found: Robotstxt/index
