<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-11 12:33:42 --> 404 Page Not Found: Misc/print.css
ERROR - 2021-01-11 12:33:43 --> 404 Page Not Found: Misc/print.css
ERROR - 2021-01-11 19:26:33 --> 404 Page Not Found: Themes/README.txt
ERROR - 2021-01-11 19:26:33 --> 404 Page Not Found: Themes/README.txt
