<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-09 07:21:29 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-02-09 14:29:12 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-02-09 20:09:19 --> 404 Page Not Found: Wp_loginphp/index
