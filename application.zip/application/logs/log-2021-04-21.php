<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-21 05:35:01 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-04-21 07:57:29 --> 404 Page Not Found: Theme/assets
ERROR - 2021-04-21 07:57:29 --> 404 Page Not Found: Theme/assets
ERROR - 2021-04-21 07:57:29 --> 404 Page Not Found: admin/Assets/admin
ERROR - 2021-04-21 07:57:29 --> 404 Page Not Found: admin/Jquery_file_upload/server
ERROR - 2021-04-21 07:57:29 --> 404 Page Not Found: Public/assets
ERROR - 2021-04-21 07:57:29 --> 404 Page Not Found: admin/Elfinder/connectors
ERROR - 2021-04-21 17:04:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-21 17:04:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-21 17:06:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-21 17:08:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-21 17:17:38 --> 404 Page Not Found: Asset/plugins
ERROR - 2021-04-21 17:18:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-21 17:19:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-21 17:34:52 --> 404 Page Not Found: Faviconico/index
