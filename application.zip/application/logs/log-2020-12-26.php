<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-26 08:08:56 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-12-26 17:24:44 --> 404 Page Not Found: OLD/wp_admin
