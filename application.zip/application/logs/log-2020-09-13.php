<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-13 14:46:45 --> 404 Page Not Found: Data/admin
