<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-25 05:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-25 06:39:07 --> 404 Page Not Found: Licensetxt/index
ERROR - 2020-03-25 13:29:51 --> 404 Page Not Found: Site/license.txt
ERROR - 2020-03-25 20:35:08 --> 404 Page Not Found: Temp/license.txt
