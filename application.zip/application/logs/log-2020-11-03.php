<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-03 10:43:13 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2020-11-03 10:43:13 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2020-11-03 10:43:14 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2020-11-03 10:43:14 --> 404 Page Not Found: Web/wp_includes
ERROR - 2020-11-03 10:43:14 --> 404 Page Not Found: Wordpress/wp_includes
ERROR - 2020-11-03 10:43:15 --> 404 Page Not Found: Website/wp_includes
ERROR - 2020-11-03 10:43:15 --> 404 Page Not Found: Wp/wp_includes
ERROR - 2020-11-03 10:43:15 --> 404 Page Not Found: News/wp_includes
ERROR - 2020-11-03 10:43:15 --> 404 Page Not Found: 2018/wp_includes
ERROR - 2020-11-03 10:43:16 --> 404 Page Not Found: 2019/wp_includes
ERROR - 2020-11-03 10:43:16 --> 404 Page Not Found: Shop/wp_includes
ERROR - 2020-11-03 10:43:16 --> 404 Page Not Found: Wp1/wp_includes
ERROR - 2020-11-03 10:43:16 --> 404 Page Not Found: Test/wp_includes
ERROR - 2020-11-03 10:43:16 --> 404 Page Not Found: Media/wp_includes
ERROR - 2020-11-03 10:43:17 --> 404 Page Not Found: Wp2/wp_includes
ERROR - 2020-11-03 10:43:17 --> 404 Page Not Found: Site/wp_includes
ERROR - 2020-11-03 10:43:17 --> 404 Page Not Found: Cms/wp_includes
ERROR - 2020-11-03 10:43:17 --> 404 Page Not Found: Sito/wp_includes
