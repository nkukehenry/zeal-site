<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-22 21:13:13 --> Severity: Notice --> Undefined index: photo F:\xampp\htdocs\cheetah\application\controllers\admin\Feature.php 141
ERROR - 2019-11-22 21:13:13 --> Severity: Warning --> unlink(./public/uploads/): Permission denied F:\xampp\htdocs\cheetah\application\controllers\admin\Feature.php 141
ERROR - 2019-11-22 23:17:38 --> 404 Page Not Found: Public/admin
ERROR - 2019-11-22 23:17:39 --> 404 Page Not Found: Public/admin
