<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-11 15:47:48 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2021-06-11 15:48:15 --> 404 Page Not Found: Wp/wp_admin
ERROR - 2021-06-11 15:48:51 --> 404 Page Not Found: New/wp_admin
ERROR - 2021-06-11 15:49:24 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-06-11 15:49:56 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-06-11 15:50:36 --> 404 Page Not Found: Test/wp_admin
ERROR - 2021-06-11 15:51:18 --> 404 Page Not Found: Blog/wp_admin
ERROR - 2021-06-11 15:51:46 --> 404 Page Not Found: Cms/wp_admin
ERROR - 2021-06-11 15:52:04 --> 404 Page Not Found: Web/wp_admin
ERROR - 2021-06-11 15:52:20 --> 404 Page Not Found: Backup/wp_admin
ERROR - 2021-06-11 15:52:34 --> 404 Page Not Found: Site/wp_admin
ERROR - 2021-06-11 15:52:50 --> 404 Page Not Found: Oldsite/wp_admin
ERROR - 2021-06-11 23:27:30 --> 404 Page Not Found: Adstxt/index
