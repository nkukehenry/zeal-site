<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-08 06:45:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-08 12:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-08 16:00:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-08 18:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-08 20:55:51 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-04-08 20:56:11 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-04-08 22:56:07 --> 404 Page Not Found: Wp_loginphp/index
