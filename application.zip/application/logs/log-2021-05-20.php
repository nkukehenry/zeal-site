<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-20 04:40:26 --> 404 Page Not Found: admin/Assets/admin
ERROR - 2021-05-20 11:16:01 --> 404 Page Not Found: admin/Uploader/server
ERROR - 2021-05-20 11:48:25 --> 404 Page Not Found: Indexrss/index
ERROR - 2021-05-20 11:48:25 --> 404 Page Not Found: Indexxml/index
ERROR - 2021-05-20 11:48:25 --> 404 Page Not Found: Feeds/index
ERROR - 2021-05-20 11:48:25 --> 404 Page Not Found: Feed/index
ERROR - 2021-05-20 11:48:25 --> 404 Page Not Found: Rssxml/index
ERROR - 2021-05-20 11:48:25 --> 404 Page Not Found: Indexrdf/index
ERROR - 2021-05-20 18:53:45 --> 404 Page Not Found: admin/Uploadify/uploadify.css
ERROR - 2021-05-20 21:39:34 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2021-05-20 21:39:34 --> 404 Page Not Found: Wp_loginphp/index
