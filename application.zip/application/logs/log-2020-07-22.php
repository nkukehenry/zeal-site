<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-22 10:37:28 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-22 10:37:57 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-22 10:38:11 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-22 10:38:12 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-22 10:38:33 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-22 10:38:45 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-22 18:14:35 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-07-22 19:48:54 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-22 19:49:24 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
