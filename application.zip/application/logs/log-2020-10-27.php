<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-27 17:28:11 --> 404 Page Not Found: Faviconico/index
