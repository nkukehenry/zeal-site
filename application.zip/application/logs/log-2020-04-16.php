<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-16 00:44:20 --> 404 Page Not Found: Licensetxt/index
ERROR - 2020-04-16 02:37:16 --> 404 Page Not Found: Test/license.txt
ERROR - 2020-04-16 04:39:54 --> 404 Page Not Found: Tmp/license.txt
ERROR - 2020-04-16 06:49:59 --> 404 Page Not Found: Temp/index
ERROR - 2020-04-16 09:08:23 --> 404 Page Not Found: Www/license.txt
ERROR - 2020-04-16 11:34:16 --> 404 Page Not Found: Site/license.txt
ERROR - 2020-04-16 14:09:34 --> 404 Page Not Found: New1/license.txt
ERROR - 2020-04-16 16:53:38 --> 404 Page Not Found: Old/license.txt
ERROR - 2020-04-16 19:44:41 --> 404 Page Not Found: New/license.txt
ERROR - 2020-04-16 19:56:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-16 22:39:28 --> 404 Page Not Found: 1/license.txt
ERROR - 2020-04-16 23:17:47 --> 404 Page Not Found: Public/css
