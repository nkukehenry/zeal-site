<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-04 06:22:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-12-04 08:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-12-04 15:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-12-04 16:17:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-12-04 19:59:00 --> 404 Page Not Found: Robotstxt/index
