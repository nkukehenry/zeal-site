<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-18 15:29:24 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2019-12-18 16:33:47 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2019-12-18 16:39:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-12-18 19:02:55 --> 404 Page Not Found: Wp_loginphp/index
