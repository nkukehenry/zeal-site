<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-18 07:04:42 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-18 07:04:43 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-18 07:04:44 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-18 07:05:15 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-18 07:05:20 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-18 07:05:20 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-18 13:06:44 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
