<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-06 12:27:30 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-01-06 17:21:21 --> 404 Page Not Found: Env/index
ERROR - 2021-01-06 20:19:29 --> 404 Page Not Found: Env/index
ERROR - 2021-01-06 23:24:39 --> 404 Page Not Found: Wp/wp_admin
