<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-25 03:52:34 --> 404 Page Not Found: Wordpress/wp_admin
