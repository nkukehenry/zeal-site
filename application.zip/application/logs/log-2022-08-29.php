<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-29 10:02:22 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2022-08-29 10:02:23 --> 404 Page Not Found: Phpinfophp/index
ERROR - 2022-08-29 10:02:36 --> 404 Page Not Found: Phpinfo/index
ERROR - 2022-08-29 10:02:37 --> 404 Page Not Found: Awsyml/index
ERROR - 2022-08-29 10:02:39 --> 404 Page Not Found: Infophp/index
ERROR - 2022-08-29 10:02:57 --> 404 Page Not Found: Aws/credentials
ERROR - 2022-08-29 10:02:58 --> 404 Page Not Found: Config/aws.yml
ERROR - 2022-08-29 10:02:59 --> 404 Page Not Found: Configjs/index
