<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-10 06:40:31 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-02-10 17:58:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-02-10 22:33:49 --> 404 Page Not Found: Robotstxt/index
