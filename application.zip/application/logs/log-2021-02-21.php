<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-21 05:05:37 --> 404 Page Not Found: 403shtml/index
ERROR - 2021-02-21 06:28:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-21 08:12:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-21 08:48:06 --> 404 Page Not Found: Wp_content/wp_1ogin_bak.php
ERROR - 2021-02-21 08:48:14 --> 404 Page Not Found: Wp_content/wp_1ogin_bak.php
ERROR - 2021-02-21 11:12:29 --> 404 Page Not Found: Wp_admin/index
ERROR - 2021-02-21 14:28:33 --> 404 Page Not Found: 403shtml/index
ERROR - 2021-02-21 16:35:25 --> 404 Page Not Found: 403shtml/index
ERROR - 2021-02-21 22:23:35 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-02-21 22:23:58 --> 404 Page Not Found: Wp_includes/fonts
