<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-11 06:02:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-11 08:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-11 17:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-11 20:22:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-11 22:25:43 --> 404 Page Not Found: Adstxt/index
