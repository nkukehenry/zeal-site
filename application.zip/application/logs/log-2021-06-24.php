<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-24 01:27:35 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2021-06-24 01:30:30 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2021-06-24 01:49:50 --> 404 Page Not Found: Wp_includes/index
ERROR - 2021-06-24 12:51:07 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2021-06-24 12:51:35 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2021-06-24 20:57:23 --> 404 Page Not Found: Wp_includes/index
ERROR - 2021-06-24 21:47:12 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2021-06-24 21:47:12 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-06-24 21:47:12 --> 404 Page Not Found: New/wp_admin
ERROR - 2021-06-24 21:47:13 --> 404 Page Not Found: Wp/wp_admin
ERROR - 2021-06-24 21:47:13 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-06-24 21:47:13 --> 404 Page Not Found: Test/wp_admin
ERROR - 2021-06-24 21:47:13 --> 404 Page Not Found: Blog/wp_admin
ERROR - 2021-06-24 21:47:14 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-06-24 21:47:14 --> 404 Page Not Found: Wp_admin/setup_config.php
ERROR - 2021-06-24 21:47:15 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-06-24 21:47:20 --> 404 Page Not Found: New/wp_admin
ERROR - 2021-06-24 21:47:20 --> 404 Page Not Found: Wp/wp_admin
ERROR - 2021-06-24 21:47:20 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-06-24 21:47:21 --> 404 Page Not Found: Test/wp_admin
ERROR - 2021-06-24 21:47:21 --> 404 Page Not Found: Blog/wp_admin
ERROR - 2021-06-24 21:47:22 --> 404 Page Not Found: Wp_admin/index
