<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-25 03:30:46 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-12-25 03:30:47 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-12-25 06:45:47 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2020-12-25 13:45:02 --> 404 Page Not Found: Env/index
