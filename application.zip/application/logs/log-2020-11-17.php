<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-17 03:08:44 --> 404 Page Not Found: Media/com_acym
ERROR - 2020-11-17 13:33:10 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2020-11-17 16:58:06 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-11-17 17:56:19 --> 404 Page Not Found: Wp_admin/index
ERROR - 2020-11-17 21:01:42 --> 404 Page Not Found: Env/index
ERROR - 2020-11-17 21:03:03 --> 404 Page Not Found: Images/gmapfp
ERROR - 2020-11-17 21:03:05 --> 404 Page Not Found: Images/gmapfp
ERROR - 2020-11-17 21:03:07 --> 404 Page Not Found: Images/gmapfp
ERROR - 2020-11-17 21:03:08 --> 404 Page Not Found: Images/gmapfp
