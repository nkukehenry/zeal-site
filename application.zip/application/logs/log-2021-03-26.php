<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-26 11:08:07 --> 404 Page Not Found: Catalog/Adminhtml_category
ERROR - 2021-03-26 11:08:23 --> 404 Page Not Found: Catalog/Adminhtml_category
ERROR - 2021-03-26 14:36:03 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2021-03-26 14:36:11 --> 404 Page Not Found: Wp/xmlrpc.php
ERROR - 2021-03-26 14:36:19 --> 404 Page Not Found: Wordpress/xmlrpc.php
ERROR - 2021-03-26 17:05:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-26 17:25:05 --> 404 Page Not Found: Env/index
ERROR - 2021-03-26 20:17:16 --> 404 Page Not Found: Owa/auth
