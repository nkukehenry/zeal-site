<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-07 23:20:22 --> 404 Page Not Found: DS_Store/index
ERROR - 2022-04-07 23:20:23 --> 404 Page Not Found: DS_Store/index
