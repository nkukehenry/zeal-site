<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-05 19:46:49 --> 404 Page Not Found: admin/Assets/dropzone
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-05 19:46:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-03-05 19:46:49 --> 404 Page Not Found: admin/Assets/admin
ERROR - 2021-03-05 21:22:46 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-03-05 21:35:32 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-03-05 22:04:11 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2021-03-05 22:22:24 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2021-03-05 23:51:53 --> 404 Page Not Found: OLD/wp_admin
ERROR - 2021-03-05 23:55:42 --> 404 Page Not Found: Vendor/phpunit
