<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-14 09:26:17 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-08-14 09:26:18 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-08-14 15:11:10 --> 404 Page Not Found: Well_known/assetlinks.json
