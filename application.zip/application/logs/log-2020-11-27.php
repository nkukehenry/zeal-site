<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-27 05:59:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-11-27 07:07:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-11-27 21:10:24 --> 404 Page Not Found: Env/index
ERROR - 2020-11-27 21:10:24 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-11-27 21:10:25 --> 404 Page Not Found: Storage/.env
ERROR - 2020-11-27 21:10:30 --> 404 Page Not Found: Public/.env
