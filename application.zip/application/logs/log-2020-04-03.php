<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-03 04:18:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-03 04:18:28 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-04-03 05:46:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-04-03 07:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-03 11:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-03 11:24:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-03 18:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-03 22:36:00 --> 404 Page Not Found: Faviconico/index
