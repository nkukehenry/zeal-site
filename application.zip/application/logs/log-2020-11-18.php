<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-18 02:51:58 --> 404 Page Not Found: Media/com_acym
ERROR - 2020-11-18 08:19:36 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-11-18 08:21:26 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-11-18 08:23:17 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-11-18 08:25:06 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-11-18 08:26:55 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-11-18 08:28:46 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-11-18 08:30:36 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-11-18 08:32:27 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-11-18 08:34:20 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-11-18 08:36:10 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-11-18 08:38:01 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-11-18 08:39:49 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-11-18 16:08:13 --> 404 Page Not Found: Media/com_acym
ERROR - 2020-11-18 16:49:43 --> 404 Page Not Found: Images/gmapfp
