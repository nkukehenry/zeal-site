<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-24 05:16:44 --> 404 Page Not Found: Wp/wp_admin
