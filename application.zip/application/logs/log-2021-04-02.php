<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-02 00:40:54 --> 404 Page Not Found: Js/lib
ERROR - 2021-04-02 02:03:40 --> 404 Page Not Found: Env/index
ERROR - 2021-04-02 17:11:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-02 17:18:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-02 19:45:14 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2021-04-02 19:45:15 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2021-04-02 19:45:15 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2021-04-02 19:45:15 --> 404 Page Not Found: Web/wp_includes
ERROR - 2021-04-02 19:45:16 --> 404 Page Not Found: Wordpress/wp_includes
ERROR - 2021-04-02 19:45:16 --> 404 Page Not Found: Website/wp_includes
ERROR - 2021-04-02 19:45:17 --> 404 Page Not Found: Wp/wp_includes
ERROR - 2021-04-02 19:45:17 --> 404 Page Not Found: News/wp_includes
ERROR - 2021-04-02 19:45:18 --> 404 Page Not Found: 2020/wp_includes
ERROR - 2021-04-02 19:45:18 --> 404 Page Not Found: 2019/wp_includes
ERROR - 2021-04-02 19:45:18 --> 404 Page Not Found: Shop/wp_includes
ERROR - 2021-04-02 19:45:18 --> 404 Page Not Found: Wp1/wp_includes
ERROR - 2021-04-02 19:45:18 --> 404 Page Not Found: Test/wp_includes
ERROR - 2021-04-02 19:45:18 --> 404 Page Not Found: Wp2/wp_includes
ERROR - 2021-04-02 19:45:19 --> 404 Page Not Found: Site/wp_includes
ERROR - 2021-04-02 19:45:19 --> 404 Page Not Found: Cms/wp_includes
ERROR - 2021-04-02 19:45:20 --> 404 Page Not Found: Sito/wp_includes
