<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-02 16:56:28 --> 404 Page Not Found: Wp_loginphp/index
