<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-07 13:47:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-12-07 13:47:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-12-07 13:47:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-12-07 13:49:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-12-07 15:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-12-07 15:40:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-12-07 15:44:35 --> 404 Page Not Found: Faviconico/index
