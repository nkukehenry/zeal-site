<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-03 05:12:07 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-01-03 05:12:10 --> 404 Page Not Found: Wp/index
ERROR - 2021-01-03 05:12:12 --> 404 Page Not Found: Blog/index
ERROR - 2021-01-03 05:12:14 --> 404 Page Not Found: New/index
ERROR - 2021-01-03 05:12:16 --> 404 Page Not Found: Old/index
ERROR - 2021-01-03 05:12:17 --> 404 Page Not Found: Newsite/index
ERROR - 2021-01-03 05:12:18 --> 404 Page Not Found: Test/index
ERROR - 2021-01-03 16:35:53 --> 404 Page Not Found: Env/index
