<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-08 03:14:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-10-08 04:48:09 --> 404 Page Not Found: Faviconico/index
