<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-16 08:47:31 --> 404 Page Not Found: Wp_admin/index
ERROR - 2021-05-16 09:35:16 --> 404 Page Not Found: Theme/assets
