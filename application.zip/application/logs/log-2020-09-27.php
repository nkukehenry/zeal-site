<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-27 15:26:59 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-27 15:27:00 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-27 15:27:00 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-27 15:27:01 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-27 15:27:01 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-27 15:27:02 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-27 15:27:02 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-27 15:27:03 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-27 15:27:03 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-27 15:27:03 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-27 15:27:04 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-27 15:27:04 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-27 15:27:05 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-27 15:27:05 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-27 15:27:06 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-27 15:27:07 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-27 15:27:07 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-09-27 15:27:08 --> 404 Page Not Found: 403shtml/index
