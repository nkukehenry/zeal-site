<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-15 14:09:59 --> 404 Page Not Found: Wp_loginphp/index
