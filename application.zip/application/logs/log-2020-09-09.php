<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-09 16:03:44 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-09-09 16:04:59 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-09-09 16:05:00 --> 404 Page Not Found: Adstxt/index
