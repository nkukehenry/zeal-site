<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-21 06:23:07 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-08-21 06:23:08 --> 404 Page Not Found: Adstxt/index
