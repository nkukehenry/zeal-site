<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-01 03:29:47 --> 404 Page Not Found: Wp_loginphp/index
