<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-28 09:53:46 --> 404 Page Not Found: Wp_content/plugins
