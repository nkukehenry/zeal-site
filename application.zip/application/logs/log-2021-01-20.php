<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-20 03:55:57 --> 404 Page Not Found: Wp_admin/config.bak.php
ERROR - 2021-01-20 03:56:19 --> 404 Page Not Found: Wp_content/config.bak.php
ERROR - 2021-01-20 03:56:39 --> 404 Page Not Found: Wp_includes/config.bak.php
ERROR - 2021-01-20 06:03:07 --> 404 Page Not Found: OLD/wp_admin
ERROR - 2021-01-20 08:21:09 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-01-20 08:21:55 --> 404 Page Not Found: Wp_includes/fonts
ERROR - 2021-01-20 19:27:59 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2021-01-20 22:51:17 --> 404 Page Not Found: Adstxt/index
