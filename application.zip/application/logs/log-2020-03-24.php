<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-24 01:51:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-24 11:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-24 14:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-24 17:07:42 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-03-24 21:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-24 23:07:02 --> 404 Page Not Found: Wp_loginphp/index
