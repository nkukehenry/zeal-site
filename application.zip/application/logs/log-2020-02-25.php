<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-25 11:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-02-25 15:18:02 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-02-25 22:30:40 --> 404 Page Not Found: Robotstxt/index
