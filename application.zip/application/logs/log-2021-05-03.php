<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-03 02:50:08 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-05-03 07:08:39 --> 404 Page Not Found: Asset/plugins
ERROR - 2021-05-03 07:08:39 --> 404 Page Not Found: Asset/plugins
ERROR - 2021-05-03 12:05:14 --> 404 Page Not Found: Assets/admin
ERROR - 2021-05-03 12:05:14 --> 404 Page Not Found: Plugins/elFinder
ERROR - 2021-05-03 19:01:16 --> 404 Page Not Found: admin/ElFinder/connectors
ERROR - 2021-05-03 19:01:16 --> 404 Page Not Found: Assets/backend
ERROR - 2021-05-03 19:01:16 --> 404 Page Not Found: Assets/jqueryupload
ERROR - 2021-05-03 19:01:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-05-03 19:01:16 --> 404 Page Not Found: Assets/global
