<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-22 04:22:10 --> 404 Page Not Found: Licensetxt/index
ERROR - 2020-02-22 08:54:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-02-22 20:11:34 --> 404 Page Not Found: Wp_loginphp/index
