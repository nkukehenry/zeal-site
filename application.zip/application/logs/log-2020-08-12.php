<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-12 05:38:24 --> 404 Page Not Found: A/index
ERROR - 2020-08-12 05:38:26 --> 404 Page Not Found: Public/js
ERROR - 2020-08-12 05:38:34 --> 404 Page Not Found: Util/login.aspx
ERROR - 2020-08-12 05:38:34 --> 404 Page Not Found: Magento_version/index
ERROR - 2020-08-12 05:38:34 --> 404 Page Not Found: Installphp/index
ERROR - 2020-08-12 07:13:24 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-12 07:13:39 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-12 07:13:53 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-12 07:14:08 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-12 07:14:21 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-12 07:14:35 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-12 07:14:47 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-12 07:15:04 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-12 07:15:17 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-12 21:34:12 --> 404 Page Not Found: Wp_loginphp/index
