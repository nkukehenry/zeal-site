<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-03 01:18:30 --> 404 Page Not Found: Public/home
