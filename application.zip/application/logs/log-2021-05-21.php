<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-21 05:15:43 --> 404 Page Not Found: Wp_content/index
ERROR - 2021-05-21 21:04:48 --> 404 Page Not Found: admin/Assets/uploadify
