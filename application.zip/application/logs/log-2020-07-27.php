<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-27 08:58:32 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-07-27 20:14:59 --> 404 Page Not Found: Well_known/assetlinks.json
