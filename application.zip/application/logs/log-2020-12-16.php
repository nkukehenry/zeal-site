<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-16 08:09:21 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2020-12-16 15:51:28 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2020-12-16 16:24:03 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2020-12-16 19:03:54 --> 404 Page Not Found: Env/index
