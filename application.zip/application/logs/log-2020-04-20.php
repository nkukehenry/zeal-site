<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-20 11:02:19 --> 404 Page Not Found: Public/home
