<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-06 00:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-12-06 01:47:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-12-06 08:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-12-06 11:51:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-12-06 18:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-12-06 19:27:43 --> 404 Page Not Found: Faviconico/index
