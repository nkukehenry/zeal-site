<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-26 03:38:27 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-09-26 03:38:29 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-09-26 10:35:33 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-09-26 19:59:30 --> 404 Page Not Found: Wp_content/plugins
