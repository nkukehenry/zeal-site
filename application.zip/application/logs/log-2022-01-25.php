<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-25 15:24:22 --> 404 Page Not Found: Adstxt/index
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-25 15:24:22 --> 404 Page Not Found: App_adstxt/index
