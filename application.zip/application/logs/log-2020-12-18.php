<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-18 18:17:43 --> 404 Page Not Found: Old/wp_admin
