<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-29 11:56:42 --> 404 Page Not Found: _wp/license.txt
ERROR - 2020-03-29 14:26:45 --> 404 Page Not Found: Robotstxt/index
