<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-22 13:15:30 --> 404 Page Not Found: Robotstxt/index
