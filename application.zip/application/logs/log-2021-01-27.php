<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-27 23:00:10 --> 404 Page Not Found: Wp_content/db_cache.php
