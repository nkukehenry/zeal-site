<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-29 00:29:05 --> 404 Page Not Found: Wp/wp_admin
ERROR - 2021-04-29 11:30:07 --> 404 Page Not Found: Assets/admin
ERROR - 2021-04-29 13:39:31 --> 404 Page Not Found: Env/index
ERROR - 2021-04-29 13:39:33 --> 404 Page Not Found: Vendor/.env
ERROR - 2021-04-29 13:39:33 --> 404 Page Not Found: Storage/.env
ERROR - 2021-04-29 13:39:34 --> 404 Page Not Found: Public/.env
