<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-12 13:53:54 --> 404 Page Not Found: App_adstxt/index
ERROR - 2022-05-12 13:53:54 --> 404 Page Not Found: Adstxt/index
