<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-18 08:26:11 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-04-18 18:07:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-18 18:25:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-18 19:58:44 --> 404 Page Not Found: Public/assets
ERROR - 2021-04-18 19:58:44 --> 404 Page Not Found: Asset/elfinder
ERROR - 2021-04-18 19:58:44 --> 404 Page Not Found: admin/Assets/plugins
ERROR - 2021-04-18 19:58:44 --> 404 Page Not Found: Public/assets
ERROR - 2021-04-18 19:58:44 --> 404 Page Not Found: Public/assets
ERROR - 2021-04-18 19:58:44 --> 404 Page Not Found: Assets/global
