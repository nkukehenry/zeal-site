<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-02 02:11:37 --> 404 Page Not Found: Backup/wp_admin
ERROR - 2021-03-02 17:21:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-02 18:02:57 --> 404 Page Not Found: Js/extjs.php
