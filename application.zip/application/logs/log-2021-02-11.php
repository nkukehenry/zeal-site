<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-11 12:34:09 --> 404 Page Not Found: Administrator/index.php
ERROR - 2021-02-11 13:09:27 --> 404 Page Not Found: Administrator/index.php
