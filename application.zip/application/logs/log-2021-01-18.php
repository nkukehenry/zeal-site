<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-18 00:58:16 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-01-18 00:58:56 --> 404 Page Not Found: Wp_includes/fonts
ERROR - 2021-01-18 01:30:29 --> 404 Page Not Found: 403shtml/index
ERROR - 2021-01-18 02:47:35 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2021-01-18 10:01:09 --> 404 Page Not Found: 403shtml/index
ERROR - 2021-01-18 14:43:36 --> 404 Page Not Found: Wp/wp_admin
ERROR - 2021-01-18 14:59:58 --> 404 Page Not Found: 403shtml/index
ERROR - 2021-01-18 19:25:30 --> 404 Page Not Found: Sitemaptxt/index
