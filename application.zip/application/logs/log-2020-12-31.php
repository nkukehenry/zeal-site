<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-31 04:15:18 --> 404 Page Not Found: Media/com_acym
ERROR - 2020-12-31 07:15:54 --> 404 Page Not Found: Media/com_acym
