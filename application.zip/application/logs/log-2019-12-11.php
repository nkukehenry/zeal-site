<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-11 20:40:52 --> 404 Page Not Found: Robotstxt/index
