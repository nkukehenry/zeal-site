<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-09 15:50:49 --> 404 Page Not Found: Profile/register
ERROR - 2020-08-09 15:50:53 --> 404 Page Not Found: Wp/profile
ERROR - 2020-08-09 15:50:55 --> 404 Page Not Found: Wordpress/profile
ERROR - 2020-08-09 15:51:00 --> 404 Page Not Found: Blog/profile
ERROR - 2020-08-09 15:51:02 --> 404 Page Not Found: New/profile
ERROR - 2020-08-09 15:51:05 --> 404 Page Not Found: Old/profile
ERROR - 2020-08-09 15:51:08 --> 404 Page Not Found: Demo/profile
