<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-17 11:31:36 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-02-17 16:48:07 --> 404 Page Not Found: Robotstxt/index
