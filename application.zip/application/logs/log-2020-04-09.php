<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-09 00:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-09 05:04:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-09 16:46:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-09 16:46:43 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-04-09 16:46:47 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-04-09 17:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-09 21:43:24 --> 404 Page Not Found: Robotstxt/index
