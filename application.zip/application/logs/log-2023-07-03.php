<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-07-03 14:44:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-07-03 14:44:39 --> 404 Page Not Found: Assets/site
ERROR - 2023-07-03 14:44:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-07-03 14:44:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-07-03 14:44:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-07-03 14:44:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-07-03 14:44:45 --> 404 Page Not Found: Assets/site
ERROR - 2023-07-03 14:44:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-07-03 14:44:46 --> 404 Page Not Found: Assets/site
ERROR - 2023-07-03 14:44:46 --> 404 Page Not Found: Assets/site
