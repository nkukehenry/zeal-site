<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-05 05:58:32 --> 404 Page Not Found: Robotstxt/index
