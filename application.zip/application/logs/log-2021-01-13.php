<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-13 09:38:24 --> 404 Page Not Found: Well_known/security.txt
ERROR - 2021-01-13 12:42:43 --> 404 Page Not Found: Old/wp_admin
ERROR - 2021-01-13 16:20:22 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-01-13 16:20:27 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-01-13 16:20:27 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-01-13 19:46:13 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-01-13 19:46:27 --> 404 Page Not Found: Wp_includes/fonts
ERROR - 2021-01-13 20:49:56 --> 404 Page Not Found: Env/index
ERROR - 2021-01-13 20:49:56 --> 404 Page Not Found: Wp_content/index
ERROR - 2021-01-13 22:53:37 --> 404 Page Not Found: Configbakphp/index
