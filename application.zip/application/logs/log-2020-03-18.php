<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-18 01:10:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-18 08:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-18 10:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-18 14:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-18 14:37:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-03-18 22:59:30 --> 404 Page Not Found: Robotstxt/index
