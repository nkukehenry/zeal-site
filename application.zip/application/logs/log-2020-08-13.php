<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-13 01:30:53 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-08-13 13:19:23 --> 404 Page Not Found: Well_known/assetlinks.json
