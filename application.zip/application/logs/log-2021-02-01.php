<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-01 14:42:02 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-02-01 14:42:28 --> 404 Page Not Found: Wp_includes/fonts
