<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-19 08:25:59 --> 404 Page Not Found: admin/Assets/global
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-19 08:25:59 --> 404 Page Not Found: Assets/admin
ERROR - 2021-04-19 08:25:59 --> 404 Page Not Found: admin/Assets/elfinder
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-19 08:25:59 --> 404 Page Not Found: Plugins/elfinder
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-19 08:25:59 --> 404 Page Not Found: Assets/backend
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-19 08:25:59 --> 404 Page Not Found: Public/admin
ERROR - 2021-04-19 10:16:58 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-04-19 15:29:59 --> 404 Page Not Found: Theme/assets
ERROR - 2021-04-19 15:29:59 --> 404 Page Not Found: Theme/assets
ERROR - 2021-04-19 15:29:59 --> 404 Page Not Found: Theme/assets
ERROR - 2021-04-19 16:14:38 --> 404 Page Not Found: Env/index
ERROR - 2021-04-19 16:14:39 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-04-19 16:36:34 --> 404 Page Not Found: _ignition/execute_solution
ERROR - 2021-04-19 16:59:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-19 17:22:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-19 17:36:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-19 17:42:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-19 18:14:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-19 18:15:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-19 19:35:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-19 23:17:58 --> 404 Page Not Found: Wp_admin/index
