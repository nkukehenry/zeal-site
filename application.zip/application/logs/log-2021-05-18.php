<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-18 07:02:09 --> 404 Page Not Found: Public/assets
ERROR - 2021-05-18 07:02:09 --> 404 Page Not Found: Public/assets
ERROR - 2021-05-18 07:02:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-05-18 07:02:09 --> 404 Page Not Found: Assets/global
ERROR - 2021-05-18 07:02:09 --> 404 Page Not Found: admin/Assets/plugins
ERROR - 2021-05-18 13:25:43 --> 404 Page Not Found: Public/admin
ERROR - 2021-05-18 13:25:43 --> 404 Page Not Found: admin/Assets/global
ERROR - 2021-05-18 13:25:43 --> 404 Page Not Found: Assets/backend
ERROR - 2021-05-18 13:25:43 --> 404 Page Not Found: Plugins/uploadify
ERROR - 2021-05-18 13:25:43 --> 404 Page Not Found: Assets/admin
ERROR - 2021-05-18 15:07:29 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-05-18 21:09:06 --> 404 Page Not Found: Assets/elfinder
