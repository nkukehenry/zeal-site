<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-09 07:52:09 --> 404 Page Not Found: admin/Assets/admin
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-09 07:52:09 --> 404 Page Not Found: Assets/mobile
ERROR - 2021-05-09 09:23:06 --> 404 Page Not Found: Assets/fileupload
ERROR - 2021-05-09 18:03:25 --> 404 Page Not Found: Public/assets
ERROR - 2021-05-09 19:00:31 --> 404 Page Not Found: Vendor/phpunit
