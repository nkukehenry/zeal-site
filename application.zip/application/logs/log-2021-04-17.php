<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-17 17:16:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-17 17:20:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-17 17:27:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-17 17:27:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-17 21:12:51 --> 404 Page Not Found: Faviconico/index
