<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-15 04:41:04 --> 404 Page Not Found: Ntn/index
ERROR - 2020-04-15 04:41:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-04-15 11:58:03 --> 404 Page Not Found: Robotstxt/index
