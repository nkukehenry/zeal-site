<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-15 03:59:10 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-15 03:59:18 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-15 03:59:26 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-15 03:59:37 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-15 03:59:39 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-15 03:59:47 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-15 03:59:57 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-15 04:00:05 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-15 04:00:13 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-15 04:00:22 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-15 04:00:29 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-15 04:00:37 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-08-15 16:53:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-08-15 17:41:11 --> 404 Page Not Found: Well_known/assetlinks.json
