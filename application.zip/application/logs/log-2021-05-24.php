<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-24 09:59:57 --> 404 Page Not Found: admin/Assets/plugins
ERROR - 2021-05-24 20:44:14 --> 404 Page Not Found: Plugins/uploadify
