<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-23 03:24:41 --> Severity: Notice --> Undefined variable: data F:\xampp\htdocs\cheetah\application\controllers\admin\Page.php 96
ERROR - 2019-11-23 03:24:41 --> Severity: Warning --> unlink(./public/uploads/): Permission denied F:\xampp\htdocs\cheetah\application\controllers\admin\Page.php 96
ERROR - 2019-11-23 03:45:05 --> Severity: Notice --> Undefined variable: data F:\xampp\htdocs\cheetah\application\controllers\admin\Page.php 234
ERROR - 2019-11-23 03:45:05 --> Severity: Warning --> unlink(./public/uploads/): Permission denied F:\xampp\htdocs\cheetah\application\controllers\admin\Page.php 234
ERROR - 2019-11-23 04:03:03 --> Severity: Notice --> Undefined index: photo F:\xampp\htdocs\cheetah\application\controllers\admin\Feature.php 141
ERROR - 2019-11-23 04:03:03 --> Severity: Warning --> unlink(./public/uploads/): Permission denied F:\xampp\htdocs\cheetah\application\controllers\admin\Feature.php 141
ERROR - 2019-11-23 04:03:08 --> Severity: Notice --> Undefined index: photo F:\xampp\htdocs\cheetah\application\controllers\admin\Feature.php 141
ERROR - 2019-11-23 04:03:08 --> Severity: Warning --> unlink(./public/uploads/): Permission denied F:\xampp\htdocs\cheetah\application\controllers\admin\Feature.php 141
ERROR - 2019-11-23 04:03:27 --> Severity: Notice --> Undefined index: photo F:\xampp\htdocs\cheetah\application\controllers\admin\Feature.php 141
ERROR - 2019-11-23 04:03:27 --> Severity: Warning --> unlink(./public/uploads/): Permission denied F:\xampp\htdocs\cheetah\application\controllers\admin\Feature.php 141
ERROR - 2019-11-23 04:19:31 --> Severity: Notice --> Undefined index: page F:\xampp\htdocs\cheetah\application\controllers\admin\Setting.php 180
ERROR - 2019-11-23 04:19:31 --> Severity: Warning --> unlink(./public/uploads/): Permission denied F:\xampp\htdocs\cheetah\application\controllers\admin\Setting.php 180
ERROR - 2019-11-23 04:40:12 --> 404 Page Not Found: Contact/Standard
ERROR - 2019-11-23 06:02:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-11-23 06:02:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-11-23 06:02:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-11-23 06:02:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-11-23 06:04:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-11-23 06:05:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-11-23 06:06:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-11-23 06:06:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-11-23 06:07:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-11-23 06:07:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-11-23 06:07:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-11-23 06:07:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-11-23 06:10:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-11-23 06:10:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-11-23 06:13:22 --> 404 Page Not Found: Faviconico/index
