<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-25 09:55:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-01-25 09:59:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-01-25 10:03:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-01-25 15:54:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-01-25 17:37:19 --> 404 Page Not Found: Faviconico/index
