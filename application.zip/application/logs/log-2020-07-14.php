<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-14 05:48:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-14 05:52:10 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-14 05:52:11 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-14 05:52:11 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-14 05:53:03 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-14 05:53:03 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-14 05:53:04 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-14 10:43:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-07-14 10:51:49 --> 404 Page Not Found: Public/css
