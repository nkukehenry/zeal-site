<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-06 04:02:20 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-04-06 09:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-06 16:27:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-06 23:38:41 --> 404 Page Not Found: Robotstxt/index
