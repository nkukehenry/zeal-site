<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-23 05:47:46 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-11-23 08:48:27 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-11-23 08:49:35 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-11-23 10:30:50 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-11-23 10:37:58 --> 404 Page Not Found: Env/index
ERROR - 2020-11-23 13:30:58 --> 404 Page Not Found: Old/wp_admin
ERROR - 2020-11-23 14:41:11 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-11-23 14:41:12 --> 404 Page Not Found: Ftpconfig/index
ERROR - 2020-11-23 14:41:13 --> 404 Page Not Found: Remote_syncjson/index
ERROR - 2020-11-23 14:41:13 --> 404 Page Not Found: Vscode/ftp_sync.json
ERROR - 2020-11-23 14:41:14 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2020-11-23 14:41:15 --> 404 Page Not Found: Deployment_configjson/index
ERROR - 2020-11-23 14:41:16 --> 404 Page Not Found: Ftpsyncsettings/index
ERROR - 2020-11-23 17:09:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-11-23 20:09:43 --> 404 Page Not Found: Env/index
ERROR - 2020-11-23 21:44:34 --> 404 Page Not Found: Env/index
ERROR - 2020-11-23 21:44:37 --> 404 Page Not Found: Env/index
ERROR - 2020-11-23 21:44:40 --> 404 Page Not Found: Vendor/phpunit
