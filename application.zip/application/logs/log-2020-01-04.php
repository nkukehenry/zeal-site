<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-04 09:02:33 --> 404 Page Not Found: Administrator/index
ERROR - 2020-01-04 09:02:34 --> 404 Page Not Found: Administrator/index.php
ERROR - 2020-01-04 09:06:40 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-01-04 09:06:40 --> 404 Page Not Found: Wp_admin/index
ERROR - 2020-01-04 09:07:32 --> 404 Page Not Found: Adminphp/index
ERROR - 2020-01-04 09:14:29 --> 404 Page Not Found: Administrator/index
ERROR - 2020-01-04 09:14:31 --> 404 Page Not Found: Administrator/index.php
ERROR - 2020-01-04 09:18:39 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-01-04 09:18:39 --> 404 Page Not Found: Wp_admin/index
ERROR - 2020-01-04 09:20:15 --> 404 Page Not Found: Adminphp/index
ERROR - 2020-01-04 09:28:03 --> 404 Page Not Found: Administrator/index.php
ERROR - 2020-01-04 09:30:38 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-01-04 09:30:39 --> 404 Page Not Found: Wp_admin/index
ERROR - 2020-01-04 09:31:42 --> 404 Page Not Found: Adminphp/index
ERROR - 2020-01-04 09:39:14 --> 404 Page Not Found: Administrator/index
ERROR - 2020-01-04 09:39:15 --> 404 Page Not Found: Administrator/index.php
ERROR - 2020-01-04 09:43:49 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-01-04 09:43:50 --> 404 Page Not Found: Wp_admin/index
ERROR - 2020-01-04 09:52:59 --> 404 Page Not Found: Adminphp/index
ERROR - 2020-01-04 10:04:40 --> 404 Page Not Found: Administrator/index
ERROR - 2020-01-04 10:04:41 --> 404 Page Not Found: Administrator/index.php
ERROR - 2020-01-04 10:12:48 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-01-04 10:12:48 --> 404 Page Not Found: Wp_admin/index
ERROR - 2020-01-04 10:16:01 --> 404 Page Not Found: Adminphp/index
ERROR - 2020-01-04 13:35:28 --> 404 Page Not Found: Robotstxt/index
