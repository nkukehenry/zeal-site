<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-31 19:56:07 --> 404 Page Not Found: Wp_admin/index
ERROR - 2021-01-31 20:03:10 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2021-01-31 21:07:36 --> 404 Page Not Found: Wp/wp_admin
