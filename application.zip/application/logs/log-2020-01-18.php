<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-18 03:28:07 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-01-18 22:04:00 --> 404 Page Not Found: Robotstxt/index
