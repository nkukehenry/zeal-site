<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-02 04:08:26 --> 404 Page Not Found: Wp_content/plugins
