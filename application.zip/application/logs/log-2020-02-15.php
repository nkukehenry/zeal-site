<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-15 17:58:50 --> 404 Page Not Found: Faviconico/index
