<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-04 21:58:38 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2021-07-04 21:59:07 --> 404 Page Not Found: Wp_content/plugins
