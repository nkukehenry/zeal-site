<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-24 03:58:09 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2020-10-24 05:06:59 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-10-24 07:23:04 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-10-24 07:35:22 --> 404 Page Not Found: Well_known/assetlinks.json
