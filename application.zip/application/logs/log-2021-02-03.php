<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-03 01:34:10 --> 404 Page Not Found: 403shtml/index
ERROR - 2021-02-03 04:37:44 --> 404 Page Not Found: Env/index
ERROR - 2021-02-03 04:37:51 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-02-03 08:28:18 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2021-02-03 17:02:54 --> 404 Page Not Found: Google06ee0fde9864ffdfhtml/index
