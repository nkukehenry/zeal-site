<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-12 09:13:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-02-12 16:08:05 --> 404 Page Not Found: Robotstxt/index
