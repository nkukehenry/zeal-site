<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-21 01:51:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-21 08:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-21 13:22:42 --> 404 Page Not Found: Robotstxt/index
