<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-15 08:47:33 --> 404 Page Not Found: Theme/assets
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-15 08:47:33 --> 404 Page Not Found: Theme/assets
ERROR - 2021-04-15 09:42:22 --> 404 Page Not Found: Theme/assets
ERROR - 2021-04-15 17:18:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-15 17:19:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-15 17:24:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-15 17:34:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-15 17:34:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-15 17:34:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-04-15 20:46:11 --> 404 Page Not Found: Public/home
ERROR - 2021-04-15 22:44:38 --> 404 Page Not Found: Assets/plugins
