<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-15 08:08:21 --> 404 Page Not Found: Public/uploads
ERROR - 2022-02-15 08:08:24 --> 404 Page Not Found: Public/uploads
ERROR - 2022-02-15 09:57:38 --> 404 Page Not Found: Public/uploads
ERROR - 2022-02-15 09:57:41 --> 404 Page Not Found: Public/uploads
