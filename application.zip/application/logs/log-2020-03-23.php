<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-23 03:27:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-23 07:20:47 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-03-23 07:20:48 --> 404 Page Not Found: Ftpconfig/index
ERROR - 2020-03-23 07:20:49 --> 404 Page Not Found: Remote_syncjson/index
ERROR - 2020-03-23 07:20:50 --> 404 Page Not Found: Vscode/ftp_sync.json
ERROR - 2020-03-23 07:20:50 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2020-03-23 07:20:51 --> 404 Page Not Found: Deployment_configjson/index
ERROR - 2020-03-23 07:20:52 --> 404 Page Not Found: Ftpsyncsettings/index
ERROR - 2020-03-23 09:25:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-23 13:23:47 --> 404 Page Not Found: Robotstxt/index
