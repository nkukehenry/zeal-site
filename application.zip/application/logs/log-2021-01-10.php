<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-10 10:49:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-01-10 11:12:37 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-01-10 11:12:57 --> 404 Page Not Found: Wp_includes/fonts
ERROR - 2021-01-10 11:19:19 --> 404 Page Not Found: Sites/all
ERROR - 2021-01-10 20:58:56 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-01-10 23:26:44 --> 404 Page Not Found: Configbakphp/index
