<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-01 10:31:03 --> 404 Page Not Found: Faviconico/index
