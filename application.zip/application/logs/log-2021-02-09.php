<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-09 04:51:32 --> 404 Page Not Found: 403shtml/index
ERROR - 2021-02-09 05:55:16 --> 404 Page Not Found: Git/config
ERROR - 2021-02-09 11:43:22 --> 404 Page Not Found: Old/wp_admin
