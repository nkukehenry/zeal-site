<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-16 01:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-16 02:09:12 --> 404 Page Not Found: 403shtml/index
ERROR - 2020-03-16 10:24:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-03-16 21:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-16 21:59:47 --> 404 Page Not Found: Wp/wp_login.php
ERROR - 2020-03-16 22:22:38 --> 404 Page Not Found: Robotstxt/index
