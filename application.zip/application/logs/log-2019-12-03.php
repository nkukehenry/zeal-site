<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-03 08:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-12-03 23:49:07 --> 404 Page Not Found: Robotstxt/index
