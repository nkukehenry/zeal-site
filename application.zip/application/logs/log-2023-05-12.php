<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-12 16:34:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-12 16:34:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-12 16:34:53 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-12 17:28:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-12 17:28:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-12 17:28:29 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-12 17:28:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-12 17:28:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-12 17:28:33 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-12 17:29:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-12 17:29:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-12 17:29:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-12 18:27:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-12 18:27:07 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-12 18:27:07 --> 404 Page Not Found: Assets/site
