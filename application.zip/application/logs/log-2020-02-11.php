<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-11 23:32:40 --> 404 Page Not Found: Wp/wp_includes
ERROR - 2020-02-11 23:33:27 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2020-02-11 23:34:19 --> 404 Page Not Found: Site/wp_includes
ERROR - 2020-02-11 23:34:23 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2020-02-11 23:35:02 --> 404 Page Not Found: Test/wp_includes
ERROR - 2020-02-11 23:35:19 --> 404 Page Not Found: Backup/wp_includes
ERROR - 2020-02-11 23:35:35 --> 404 Page Not Found: New/wp_includes
ERROR - 2020-02-11 23:36:15 --> 404 Page Not Found: En/wp_includes
ERROR - 2020-02-11 23:36:31 --> 404 Page Not Found: Demo/wp_includes
ERROR - 2020-02-11 23:36:52 --> 404 Page Not Found: Web/wp_includes
ERROR - 2020-02-11 23:37:39 --> 404 Page Not Found: Home/wp_includes
ERROR - 2020-02-11 23:38:10 --> 404 Page Not Found: Www/wp_includes
ERROR - 2020-02-11 23:38:41 --> 404 Page Not Found: Beta/wp_includes
ERROR - 2020-02-11 23:39:06 --> 404 Page Not Found: Shop/wp_includes
ERROR - 2020-02-11 23:39:47 --> 404 Page Not Found: Main/wp_includes
ERROR - 2020-02-11 23:40:37 --> 404 Page Not Found: Newsite/wp_includes
ERROR - 2020-02-11 23:40:38 --> 404 Page Not Found: Newsite/wp_includes
ERROR - 2020-02-11 23:40:58 --> 404 Page Not Found: Oldsite/wp_includes
ERROR - 2020-02-11 23:41:19 --> 404 Page Not Found: Website/wp_includes
ERROR - 2020-02-11 23:42:02 --> 404 Page Not Found: Portal/wp_includes
ERROR - 2020-02-11 23:43:17 --> 404 Page Not Found: 2019/wp_includes
ERROR - 2020-02-11 23:43:59 --> 404 Page Not Found: 1/wp_includes
ERROR - 2020-02-11 23:45:05 --> 404 Page Not Found: Wp2/wp_includes
ERROR - 2020-02-11 23:45:21 --> 404 Page Not Found: Blogs/wp_includes
