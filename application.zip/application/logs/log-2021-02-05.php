<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-05 01:33:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-05 01:33:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-05 06:29:14 --> 404 Page Not Found: 403shtml/index
