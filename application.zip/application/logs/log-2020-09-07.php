<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-07 13:13:47 --> 404 Page Not Found: Adminerphp/index
