<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-25 12:46:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-25 12:46:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-25 12:46:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-25 12:48:23 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-25 12:48:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-25 12:48:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-25 12:48:26 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-25 16:57:57 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-25 16:58:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-25 16:58:06 --> 404 Page Not Found: Assets/site
ERROR - 2023-05-25 16:58:06 --> 404 Page Not Found: Assets/site
