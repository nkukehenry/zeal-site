<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-26 13:27:24 --> 404 Page Not Found: Wp_content/plugins
