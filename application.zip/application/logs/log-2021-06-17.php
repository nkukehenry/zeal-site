<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-17 17:57:08 --> 404 Page Not Found: Cf_scripts/scripts
