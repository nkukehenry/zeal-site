<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-09 01:15:22 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-06-09 06:37:11 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-06-09 06:37:13 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-06-09 14:17:27 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-06-09 14:17:28 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-06-09 14:17:29 --> 404 Page Not Found: Pma/index
ERROR - 2021-06-09 14:17:30 --> 404 Page Not Found: Myadmin/index
ERROR - 2021-06-09 14:17:31 --> 404 Page Not Found: Sql/index
ERROR - 2021-06-09 14:17:32 --> 404 Page Not Found: Mysql/index
ERROR - 2021-06-09 14:17:33 --> 404 Page Not Found: Mysqladmin/index
ERROR - 2021-06-09 14:17:34 --> 404 Page Not Found: Db/index
ERROR - 2021-06-09 14:17:35 --> 404 Page Not Found: Database/index
ERROR - 2021-06-09 14:17:36 --> 404 Page Not Found: Adminerphp/index
ERROR - 2021-06-09 14:17:37 --> 404 Page Not Found: Sqlphp/index
