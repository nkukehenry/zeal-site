<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-31 05:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-31 05:08:30 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-03-31 07:45:37 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-03-31 11:26:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-31 12:21:11 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-03-31 12:57:22 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-03-31 17:06:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-31 18:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-31 18:55:04 --> 404 Page Not Found: Robotstxt/index
