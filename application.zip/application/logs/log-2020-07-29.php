<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-29 04:44:50 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2020-07-29 20:02:43 --> 404 Page Not Found: Well_known/assetlinks.json
