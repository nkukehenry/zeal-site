<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-22 01:50:41 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-09-22 01:50:42 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-09-22 22:57:17 --> 404 Page Not Found: Wp_loginphp/index
