<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-14 04:11:18 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-02-14 12:40:40 --> 404 Page Not Found: Backup/wp_admin
ERROR - 2021-02-14 19:26:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-14 22:37:18 --> 404 Page Not Found: Wp_loginphp/index
