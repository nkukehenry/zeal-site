<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-26 15:13:28 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2021-01-26 19:55:51 --> 404 Page Not Found: Env/index
ERROR - 2021-01-26 21:57:57 --> 404 Page Not Found: Sitemaptxt/index
