<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-02 02:20:04 --> 404 Page Not Found: 2019/wp_login.php
ERROR - 2020-02-02 14:17:04 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-02-02 14:33:26 --> 404 Page Not Found: Wp_loginphp/index
