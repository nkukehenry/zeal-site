<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-07 07:59:33 --> 404 Page Not Found: Wp_loginphp/index
