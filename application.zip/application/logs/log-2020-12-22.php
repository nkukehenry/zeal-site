<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-22 17:56:03 --> 404 Page Not Found: Backup/wp_admin
ERROR - 2020-12-22 22:35:02 --> 404 Page Not Found: Env/index
