<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-09 15:18:57 --> 404 Page Not Found: 1/license.txt
ERROR - 2020-03-09 21:40:21 --> 404 Page Not Found: Robotstxt/index
