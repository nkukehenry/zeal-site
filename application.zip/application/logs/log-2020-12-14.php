<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-14 05:26:00 --> 404 Page Not Found: OLD/wp_admin
ERROR - 2020-12-14 10:20:14 --> 404 Page Not Found: Env/index
