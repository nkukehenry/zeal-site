<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-04 14:08:41 --> 404 Page Not Found: App_adstxt/index
ERROR - 2022-04-04 14:08:41 --> 404 Page Not Found: Adstxt/index
