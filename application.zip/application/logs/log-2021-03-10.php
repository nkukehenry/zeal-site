<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-10 04:27:31 --> 404 Page Not Found: Env/index
ERROR - 2021-03-10 17:26:46 --> 404 Page Not Found: Faviconico/index
