<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-05 08:10:36 --> 404 Page Not Found: Wp_includes/css
ERROR - 2021-01-05 08:10:49 --> 404 Page Not Found: Wp_includes/fonts
ERROR - 2021-01-05 08:35:28 --> 404 Page Not Found: Adminerphp/index
ERROR - 2021-01-05 09:12:12 --> 404 Page Not Found: Atomxml/index
ERROR - 2021-01-05 21:37:26 --> 404 Page Not Found: Env/index
