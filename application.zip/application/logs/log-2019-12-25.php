<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-25 17:06:57 --> 404 Page Not Found: Backup/wp_login.php
ERROR - 2019-12-25 19:14:38 --> 404 Page Not Found: Site/wp_login.php
ERROR - 2019-12-25 21:11:58 --> 404 Page Not Found: Web/wp_login.php
ERROR - 2019-12-25 23:04:57 --> 404 Page Not Found: Test/wp_login.php
