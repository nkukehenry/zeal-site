<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-30 01:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-30 11:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-30 20:52:55 --> 404 Page Not Found: Robotstxt/index
