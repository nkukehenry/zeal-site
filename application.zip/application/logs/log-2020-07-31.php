<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-31 22:34:40 --> 404 Page Not Found: Well_known/assetlinks.json
