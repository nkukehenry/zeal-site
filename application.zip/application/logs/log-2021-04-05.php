<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-05 05:15:06 --> 404 Page Not Found: Env/index
ERROR - 2021-04-05 05:15:06 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-04-05 06:18:18 --> 404 Page Not Found: Public/assets
ERROR - 2021-04-05 10:27:32 --> 404 Page Not Found: Theme/assets
