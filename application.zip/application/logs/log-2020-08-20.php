<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-20 22:22:27 --> 404 Page Not Found: Well_known/assetlinks.json
