<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-28 22:20:57 --> 404 Page Not Found: Assets/plugins
