<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-10 01:54:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-04-10 07:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-10 11:16:30 --> 404 Page Not Found: Robotstxt/index
