<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-12 06:04:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-12 07:00:41 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-12 07:00:50 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-12 07:00:50 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-12 07:00:51 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-12 07:01:55 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-12 07:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-12 07:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-07-12 08:30:50 --> 404 Page Not Found: Wordpress/wp_admin
ERROR - 2020-07-12 08:30:53 --> 404 Page Not Found: Wp_admin/install.php
ERROR - 2020-07-12 20:25:31 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
ERROR - 2020-07-12 21:18:07 --> 404 Page Not Found: Microsoft_Server_ActiveSync/index
