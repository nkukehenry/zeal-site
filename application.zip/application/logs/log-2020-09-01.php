<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-01 01:30:07 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-09-01 01:30:08 --> 404 Page Not Found: Adstxt/index
