<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-18 02:16:15 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-02-18 05:40:41 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-02-18 10:44:40 --> 404 Page Not Found: Robotstxt/index
