<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-25 01:40:28 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-09-25 19:10:29 --> 404 Page Not Found: Wp_content/plugins
