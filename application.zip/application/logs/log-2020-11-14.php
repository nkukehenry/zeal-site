<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-14 00:11:28 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-11-14 03:44:42 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-11-14 08:03:45 --> 404 Page Not Found: Wp_content/plugins
ERROR - 2020-11-14 14:40:17 --> 404 Page Not Found: Wp_includes/wlwmanifest.xml
ERROR - 2020-11-14 14:40:17 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2020-11-14 14:40:18 --> 404 Page Not Found: Blog/wp_includes
ERROR - 2020-11-14 14:40:18 --> 404 Page Not Found: Web/wp_includes
ERROR - 2020-11-14 14:40:19 --> 404 Page Not Found: Wordpress/wp_includes
ERROR - 2020-11-14 14:40:19 --> 404 Page Not Found: Website/wp_includes
ERROR - 2020-11-14 14:40:19 --> 404 Page Not Found: Wp/wp_includes
ERROR - 2020-11-14 14:40:19 --> 404 Page Not Found: News/wp_includes
ERROR - 2020-11-14 14:40:20 --> 404 Page Not Found: 2018/wp_includes
ERROR - 2020-11-14 14:40:20 --> 404 Page Not Found: 2019/wp_includes
ERROR - 2020-11-14 14:40:20 --> 404 Page Not Found: Shop/wp_includes
ERROR - 2020-11-14 14:40:20 --> 404 Page Not Found: Wp1/wp_includes
ERROR - 2020-11-14 14:40:21 --> 404 Page Not Found: Test/wp_includes
ERROR - 2020-11-14 14:40:21 --> 404 Page Not Found: Media/wp_includes
ERROR - 2020-11-14 14:40:21 --> 404 Page Not Found: Wp2/wp_includes
ERROR - 2020-11-14 14:40:21 --> 404 Page Not Found: Site/wp_includes
ERROR - 2020-11-14 14:40:22 --> 404 Page Not Found: Cms/wp_includes
ERROR - 2020-11-14 14:40:22 --> 404 Page Not Found: Sito/wp_includes
