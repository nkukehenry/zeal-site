<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-06-23 16:32:04 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:32:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:32:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:32:05 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:32:50 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:32:51 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:32:51 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:32:51 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:49:43 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:49:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:49:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:49:44 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:50:41 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:50:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:50:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:50:47 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:51:16 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:51:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:51:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:51:19 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:52:00 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:52:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:52:03 --> 404 Page Not Found: Assets/site
ERROR - 2023-06-23 16:52:03 --> 404 Page Not Found: Assets/site
